import { PGlite } from '@electric-sql/pglite';
import fs from 'node:fs';
import path from 'node:path';
import { randomUUID as uuid } from 'node:crypto';
import { afterAll, beforeAll, describe, expect, it } from 'vitest';
import {
  BUYER_FORM, VENDOR_FORM, OBSERVATION_FORM, EVALUATION_FORM, buildRow, defaultAnswers, firstInvalidStep,
  orderedOptions, orderingString, validateStep, visibleQuestions, type Answers, type FormDef,
} from '@/lib/forms';
import { supabaseTransportForTests } from './helpers/pg-transport';

// Test « contrat » : les fiches fabriquées par les formulaires de l'application
// sont envoyées dans la VRAIE structure SQL (script 001), avec les vraies règles d'accès.

const db = new PGlite();
const USER = uuid();
const ADMIN = uuid();
let missionId = '';
let zoneId = '';
// la base n'autorise qu'une évaluation par zone et par enquêteur : une zone neuve pour chaque fiche d'évaluation
const evalZones: string[] = [];

async function as(uid: string, sql: string, params: unknown[] = []): Promise<{ rows: any[] }> {
  await db.exec(`set role authenticated; select set_config('request.jwt.claim.sub', '${uid}', false);`);
  try { return await db.query<any>(sql, params); }
  finally { await db.exec(`reset role; select set_config('request.jwt.claim.sub', '', false);`); }
}

beforeAll(async () => {
  await db.exec(`
    create role anon nologin; create role authenticated nologin; create role service_role nologin bypassrls;
    create schema auth;
    create table auth.users (id uuid primary key default gen_random_uuid(), email text, raw_user_meta_data jsonb default '{}'::jsonb);
    create function auth.uid() returns uuid language sql stable as $$ select nullif(current_setting('request.jwt.claim.sub', true), '')::uuid $$;
    grant usage on schema public, auth to anon, authenticated;
    alter default privileges in schema public grant all on tables to anon, authenticated, service_role;
  `);
  await db.exec(fs.readFileSync(path.resolve(process.cwd(), 'supabase/migrations/001_schema.sql'), 'utf8'));
  await db.query(`insert into auth.users (id, email) values ($1,'u@t.bj'), ($2,'a@t.bj')`, [USER, ADMIN]);
  await db.query(`update public.profiles set active=true where id=$1`, [USER]);
  await db.query(`update public.profiles set active=true, role='ADMINISTRATEUR' where id=$1`, [ADMIN]);
  missionId = (await as(ADMIN, `insert into public.missions (name) values ('M') returning id`)).rows[0].id;
  zoneId = (await as(ADMIN, `insert into public.zones (mission_id, code) values ($1,'Z01') returning id`, [missionId])).rows[0].id;
  for (let i = 0; i < 40; i++) {
    evalZones.push((await as(ADMIN, `insert into public.zones (mission_id, code) values ($1,$2) returning id`, [missionId, `E${String(i).padStart(2, '0')}`])).rows[0].id);
  }
});
afterAll(async () => { await db.close(); });

/** Remplit un formulaire comme le ferait un enquêteur : première option de chaque question. */
let slot = 0; // chaque observation de test reçoit son propre créneau (la base refuse deux fois le même)
function nextSlot() {
  const n = slot++;
  const startMin = 8 * 60 + (n % 40) * 20; // 40 créneaux de 20 min par jour (8 h -> 21 h), puis jour suivant
  const fmt = (m: number) => `${String(Math.floor(m / 60)).padStart(2, '0')}:${String(m % 60).padStart(2, '0')}`;
  const day = new Date(Date.UTC(2026, 10, 2 + Math.floor(n / 40))).toISOString().slice(0, 10);
  return { start_time: fmt(startMin), end_time: fmt(startMin + 15), observed_on: day };
}

function fill(def: FormDef, pick: (q: any, a: Answers) => unknown = () => undefined): Answers {
  const a: Answers = { ...defaultAnswers(def), ...nextSlot() };
  for (const step of def.steps) {
    for (const q of visibleQuestions(step, a)) {
      const custom = pick(q, a);
      if (custom !== undefined) { a[q.key] = custom; continue; }
      if (a[q.key] !== undefined) continue;
      if (q.type === 'zone') a[q.key] = q.zoneFilter === 'candidate' ? evalZones.shift()! : zoneId;
      else if (q.type === 'rating') a[q.key] = 4;
      else if (q.type === 'single') a[q.key] = q.options![0].value;
      else if (q.type === 'multi') a[q.key] = [q.options![0].value];
      else if (q.type === 'number') a[q.key] = '7';
      else if (q.type === 'text' || q.type === 'longtext') a[q.key] = q.required ? 'ok' : undefined;
    }
  }
  return a;
}

const ctx = (ordering: 'ASC' | 'DESC' = 'ASC') => ({
  id: uuid(), missionId, userId: USER, createdAt: new Date().toISOString(),
  startedAt: '2026-11-02T09:00:00Z', endedAt: '2026-11-02T09:10:00Z', ordering,
});

async function send(def: FormDef, row: Record<string, unknown>) {
  const t = supabaseTransportForTests((sql, params) => as(USER, sql, params));
  return t.insertIgnoreDuplicates(def.table, row);
}

describe.each([[BUYER_FORM], [VENDOR_FORM], [OBSERVATION_FORM], [EVALUATION_FORM]])('Formulaire %o', (def) => {
  it('un formulaire rempli passe la validation de l\'application ET est accepté par la base', async () => {
    const answers = fill(def);
    expect(firstInvalidStep(def, answers).index).toBe(-1);
    const row = buildRow(def, answers, ctx());
    const res = await send(def, row);
    expect(res).toEqual({ ok: true });
    const stored = await as(ADMIN, `select status, version from public.${def.table} where id=$1`, [row.id as string]);
    expect(stored.rows[0]).toMatchObject({ status: 'SOUMIS', version: 1 });
  });

  it('un formulaire vide est refusé par l\'application (étape 1 en erreur)', () => {
    const v = firstInvalidStep(def, defaultAnswers(def));
    expect(v.index).toBeGreaterThanOrEqual(0);
    expect(Object.keys(v.errors).length).toBeGreaterThan(0);
  });

  it('renvoyer la même fiche deux fois n\'en crée qu\'une', async () => {
    const row = buildRow(def, fill(def), ctx());
    expect(await send(def, row)).toEqual({ ok: true });
    expect(await send(def, row)).toEqual({ ok: true });
    const n = await as(ADMIN, `select count(*)::int n from public.${def.table} where id=$1`, [row.id as string]);
    expect(n.rows[0].n).toBe(1);
  });

  it('chaque champ obligatoire manquant est signalé par l\'application avant l\'envoi', () => {
    // les questions conditionnelles (showIf) sont testées dans leurs cas particuliers plus bas
    const required = def.steps.flatMap((s) => s.questions).filter((q) => q.required && !q.showIf);
    for (const q of required) {
      const a = fill(def);
      delete a[q.key];
      const v = firstInvalidStep(def, a);
      expect(v.index, `champ ${q.key}`).toBeGreaterThanOrEqual(0);
      expect(v.errors[q.key], `champ ${q.key}`).toBeDefined();
    }
  });
});

describe('Questionnaire acheteur : cas particuliers', () => {
  it('« Autre montant » : le montant devient obligatoire, puis la fiche est acceptée', async () => {
    const a = fill(BUYER_FORM, (q) => (q.key === 'q10_prix' ? 'AUTRE_MONTANT' : undefined));
    const step = BUYER_FORM.steps.find((s) => s.questions.some((q) => q.key === 'q10_prix'))!;
    expect(validateStep(step, a).q10_montant_fcfa).toBeDefined();
    a.q10_montant_fcfa = '150';
    expect(validateStep(step, a)).toEqual({});
    const row = buildRow(BUYER_FORM, a, ctx());
    expect(row.q10_montant_fcfa).toBe(150);
    expect(await send(BUYER_FORM, row)).toEqual({ ok: true });
  });

  it('« Autre montant » de 0 FCFA est refusé (une personne qui ne paierait rien choisit « Je ne paierais pas »)', () => {
    const a = fill(BUYER_FORM, (q) => (q.key === 'q10_prix' ? 'AUTRE_MONTANT' : undefined));
    const step = BUYER_FORM.steps.find((s) => s.questions.some((q) => q.key === 'q10_prix'))!;
    expect(validateStep(step, { ...a, q10_montant_fcfa: '0' }).q10_montant_fcfa).toBeDefined();
    expect(validateStep(step, { ...a, q10_montant_fcfa: '1' })).toEqual({});
  });

  it('le montant n\'est PAS envoyé si le prix choisi n\'est pas « Autre montant » (pas de valeur fantôme)', () => {
    const a = fill(BUYER_FORM);
    a.q10_montant_fcfa = '999'; // laissé par une saisie précédente puis changement de choix
    const row = buildRow(BUYER_FORM, a, ctx());
    expect(row.q10_montant_fcfa).toBeUndefined();
  });

  it('difficulté « Autre » : le texte est obligatoire', () => {
    const a = fill(BUYER_FORM, (q) => (q.key === 'q3_difficultes' ? ['AUTRE'] : undefined));
    const step = BUYER_FORM.steps.find((s) => s.questions.some((q) => q.key === 'q3_difficultes'))!;
    expect(validateStep(step, a).q3_difficultes).toBeDefined();
    a.q3_autre = 'Escaliers';
    expect(validateStep(step, a)).toEqual({});
  });

  it('un texte « Autre » resté en mémoire après un changement de choix n\'est pas envoyé', () => {
    const a = fill(BUYER_FORM);
    a.q4_autre = 'texte oublié';
    expect(buildRow(BUYER_FORM, a, ctx()).q4_autre).toBeUndefined();
  });

  it('aucune donnée personnelle n\'existe dans le formulaire (pas de nom ni de téléphone)', () => {
    const keys = BUYER_FORM.steps.flatMap((s) => s.questions.map((q) => q.key.toLowerCase()));
    expect(keys.filter((k) => /nom|name|phone|tel|email|photo/.test(k))).toEqual([]);
  });

  it('l\'ordre des prix alterne : l\'ordre inversé garde « Autre » et « Je ne paierais pas » en fin de liste', () => {
    const q = BUYER_FORM.steps.flatMap((s) => s.questions).find((x) => x.key === 'q10_prix')!;
    expect(orderedOptions(q, 'ASC').map((o) => o.value)).toEqual(['100', '200', '300', 'AUTRE_MONTANT', 'NE_PAIERAIT_PAS']);
    expect(orderedOptions(q, 'DESC').map((o) => o.value)).toEqual(['300', '200', '100', 'AUTRE_MONTANT', 'NE_PAIERAIT_PAS']);
  });

  it('l\'ordre présenté est enregistré avec la réponse', async () => {
    const rowAsc = buildRow(BUYER_FORM, fill(BUYER_FORM), ctx('ASC'));
    const rowDesc = buildRow(BUYER_FORM, fill(BUYER_FORM), ctx('DESC'));
    expect(rowAsc.q10_ordre_options).toBe('100-200-300');
    expect(rowDesc.q10_ordre_options).toBe('300-200-100');
    expect(orderingString(VENDOR_FORM, 'ASC')).toBeNull();
    expect(await send(BUYER_FORM, rowDesc)).toEqual({ ok: true });
  });

  it('la ligne envoyée n\'a ni version, ni date de synchronisation (c\'est le serveur qui les fixe)', () => {
    const row = buildRow(BUYER_FORM, fill(BUYER_FORM), ctx());
    expect(row).not.toHaveProperty('version');
    expect(row).not.toHaveProperty('synced_at');
    expect(row).not.toHaveProperty('submitted_at');
    expect(row.status).toBe('SOUMIS');
    expect(row.consent).toBe(true);
  });
});

describe('Questionnaire commerçante : cas particuliers', () => {
  it('« Aucun » risque ne se combine pas avec un autre risque (côté application)', () => {
    const q = VENDOR_FORM.steps.flatMap((s) => s.questions).find((x) => x.key === 'q6_risques')!;
    expect(q.exclusive).toBe('AUCUN');
  });
  it('le code de zone facultatif (Q4) peut rester vide', async () => {
    const a = fill(VENDOR_FORM);
    delete a.q4_zone_id;
    const row = buildRow(VENDOR_FORM, a, ctx());
    expect(row.q4_zone_id).toBeUndefined();
    expect(await send(VENDOR_FORM, row)).toEqual({ ok: true });
  });
});

describe('Observation : cas particuliers', () => {
  it('heure de fin avant l\'heure de début : refusée par l\'application', () => {
    const a = fill(OBSERVATION_FORM);
    a.start_time = '10:00';
    a.end_time = '09:00';
    const v = firstInvalidStep(OBSERVATION_FORM, a);
    expect(v.errors.end_time).toMatch(/après l’heure de début/);
  });
  it('« Aucun » obstacle seul est accepté', async () => {
    const a = fill(OBSERVATION_FORM, (q) => (q.key === 'obstacles' ? ['AUCUN'] : undefined));
    expect(await send(OBSERVATION_FORM, buildRow(OBSERVATION_FORM, a, ctx()))).toEqual({ ok: true });
  });
  it('un nombre négatif ou décimal est refusé', () => {
    const step = OBSERVATION_FORM.steps[1];
    const base = fill(OBSERVATION_FORM);
    expect(validateStep(step, { ...base, people_count: '-3' }).people_count).toBeDefined();
    expect(validateStep(step, { ...base, people_count: '4.5' }).people_count).toBeDefined();
    expect(validateStep(step, { ...base, people_count: '120' })).toEqual({});
  });
  it('le formulaire ne contient aucune demande de photo', () => {
    const keys = OBSERVATION_FORM.steps.flatMap((s) => s.questions.map((q) => q.key));
    expect(keys.filter((k) => /photo|image|picture/.test(k))).toEqual([]);
  });
});

describe('Évaluation des emplacements (Module E) : cas particuliers', () => {
  it('seules les zones candidates sont proposées', async () => {
    const { zonesForQuestion } = await import('@/lib/forms');
    const q = EVALUATION_FORM.steps[0].questions[0];
    const zones = [
      { id: 'a', is_candidate: true }, { id: 'b', is_candidate: false }, { id: 'c', is_candidate: true },
    ];
    expect(zonesForQuestion(q, zones).map((z) => z.id)).toEqual(['a', 'c']);
    // les autres formulaires voient toutes les zones
    const q2 = BUYER_FORM.steps[0].questions[0];
    expect(zonesForQuestion(q2, zones)).toHaveLength(3);
  });

  it('une note hors 1 à 5 (0, 6, 3,5) est refusée par l\'application', () => {
    const step = EVALUATION_FORM.steps[1];
    const base = fill(EVALUATION_FORM);
    for (const bad of [0, 6, 3.5, -1, 'abc']) {
      expect(validateStep(step, { ...base, score_flux: bad }).score_flux, String(bad)).toBeDefined();
    }
    for (const good of [1, 2, 3, 4, 5, '3']) {
      expect(validateStep(step, { ...base, score_flux: good }).score_flux, String(good)).toBeUndefined();
    }
  });

  it('les sept notes sont envoyées sous forme de nombres', () => {
    const row = buildRow(EVALUATION_FORM, fill(EVALUATION_FORM), ctx());
    for (const k of ['score_flux', 'score_zones_lourdes', 'score_acces_sortie', 'score_passage', 'score_retour_chariots', 'score_surveillance', 'score_faible_encombrement']) {
      expect(typeof row[k], k).toBe('number');
    }
    expect(row).not.toHaveProperty('consent');
  });

  it('évaluer deux fois la même zone : la 2e fiche est refusée (doublon), message explicite', async () => {
    const a = fill(EVALUATION_FORM);
    expect(await send(EVALUATION_FORM, buildRow(EVALUATION_FORM, a, ctx()))).toEqual({ ok: true });
    const again = await send(EVALUATION_FORM, buildRow(EVALUATION_FORM, a, ctx())); // autre identifiant, même zone et même enquêteur
    expect(again).toMatchObject({ ok: false, kind: 'rejected', code: '23505' });
    const { explainRejection } = await import('@/lib/sync');
    expect(explainRejection('23505')).toMatch(/zone déjà évaluée/);
  });

  it('le formulaire rappelle que le score ne vaut pas autorisation', () => {
    expect(EVALUATION_FORM.note).toMatch(/ne vaut pas autorisation/);
    expect(EVALUATION_FORM.note).toMatch(/gestionnaire/);
  });
});

describe('Rejet par la base : message d\'erreur compris par l\'application', () => {
  it('une zone inconnue est classée « refusée » (et non « réseau »), donc visible en Erreur', async () => {
    const row = buildRow(BUYER_FORM, fill(BUYER_FORM, (q) => (q.type === 'zone' && q.key === 'zone_id' ? uuid() : undefined)), ctx());
    const res = await send(BUYER_FORM, row);
    expect(res).toMatchObject({ ok: false, kind: 'rejected', code: '23503' });
  });
});
