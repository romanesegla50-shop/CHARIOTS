// Tests de la base de données (script 001) sur un vrai moteur PostgreSQL local (PGlite).
// Ils vérifient les règles d'accès, l'anti-doublon, les conflits, l'audit et les statistiques.
// Ils NE testent PAS : l'interface, le hors ligne sur téléphone, ni un vrai projet Supabase.
import { PGlite } from '@electric-sql/pglite';
import fs from 'node:fs';
import path from 'node:path';
import { randomUUID as uuid } from 'node:crypto';
import { fileURLToPath } from 'node:url';

const here = path.dirname(fileURLToPath(import.meta.url));
const migration = fs.readFileSync(path.join(here, '../supabase/migrations/001_schema.sql'), 'utf8');
const db = new PGlite();
const results = [];
let section = '';

const sec = (s) => { section = s; console.log(`\n## ${s}`); };
function rec(name, ok, detail = '') {
  results.push({ section, name, ok, detail });
  console.log(`${ok ? 'OK  ' : 'ÉCHEC'}  ${name}${ok ? '' : '  -> ' + detail}`);
}
// Comparaison indépendante de l'ordre des clés (PostgreSQL range les clés JSON à sa façon)
const canon = (v) => Array.isArray(v) ? v.map(canon)
  : v && typeof v === 'object' ? Object.fromEntries(Object.keys(v).sort().map(k => [k, canon(v[k])])) : v;
const eq = (a, b) => JSON.stringify(canon(a)) === JSON.stringify(canon(b));

async function as(uid, sql, params = []) {
  await db.exec(`set role authenticated; select set_config('request.jwt.claim.sub', '${uid ?? ''}', false);`);
  try { return await db.query(sql, params); }
  finally { await db.exec(`reset role; select set_config('request.jwt.claim.sub', '', false);`); }
}
async function asAnon(sql, params = []) {
  await db.exec(`set role anon; select set_config('request.jwt.claim.sub', '', false);`);
  try { return await db.query(sql, params); }
  finally { await db.exec(`reset role`); }
}
async function test(name, fn) {
  try { const r = await fn(); rec(name, r !== false, r === false ? 'condition fausse' : ''); }
  catch (e) { rec(name, false, `exception inattendue : ${e.message}`); }
}
async function expectErr(name, fn, { code, msg } = {}) {
  try { await fn(); rec(name, false, 'aucune erreur levée alors qu\'un refus était attendu'); }
  catch (e) {
    const okCode = !code || e.code === code;
    const okMsg = !msg || new RegExp(msg, 'i').test(e.message);
    rec(name, okCode && okMsg, `code=${e.code} message=${e.message}`);
  }
}
async function ins(uid, table, row, suffix = '') {
  const keys = Object.keys(row);
  const sql = `insert into public.${table} (${keys.join(',')}) values (${keys.map((_, i) => `$${i + 1}`).join(',')}) ${suffix} returning id`;
  return as(uid, sql, Object.values(row));
}
const count = async (uid, table, where = 'true') => Number((await as(uid, `select count(*)::int n from public.${table} where ${where}`)).rows[0].n);

// ---------------------------------------------------------------- mise en place
// Imite ce que Supabase fournit déjà (rôles, schéma auth, fonction auth.uid()).
await db.exec(`
  create role anon nologin; create role authenticated nologin; create role service_role nologin bypassrls;
  create schema auth;
  create table auth.users (id uuid primary key default gen_random_uuid(), email text, raw_user_meta_data jsonb default '{}'::jsonb);
  create function auth.uid() returns uuid language sql stable as $$ select nullif(current_setting('request.jwt.claim.sub', true), '')::uuid $$;
  grant usage on schema public, auth to anon, authenticated;
  alter default privileges in schema public grant all on tables to anon, authenticated, service_role;
  create publication supabase_realtime;
`);

sec('0. Installation du script');
await test('Le script 001 s\'exécute sans erreur sur une base vide', async () => { await db.exec(migration); });
await test('Le script 001 peut être relancé une 2e fois sans erreur (idempotent)', async () => { await db.exec(migration); });

const [ADMIN, S1, S2, S3, STRANGER] = [uuid(), uuid(), uuid(), uuid(), uuid()];
for (const [id, email, name] of [[ADMIN, 'admin@test.bj', 'Admin'], [S1, 's1@test.bj', 'Awa'], [S2, 's2@test.bj', 'Koffi'], [S3, 's3@test.bj', 'Inactif']]) {
  await db.query(`insert into auth.users (id, email, raw_user_meta_data) values ($1, $2, $3)`, [id, email, JSON.stringify({ full_name: name })]);
}
await test('Un nouveau compte reçoit un profil INACTIF par défaut', async () => {
  const r = await db.query(`select count(*)::int n from public.profiles where active = false`);
  return r.rows[0].n === 4;
});
await db.query(`update public.profiles set role='ADMINISTRATEUR', active=true where id=$1`, [ADMIN]);
await db.query(`update public.profiles set active=true where id in ($1,$2)`, [S1, S2]); // S3 reste inactif

// mission et zones créées PAR l'administrateur (teste aussi ses droits)
const M = (await as(ADMIN, `insert into public.missions (name, status) values ('Mission test', 'EN_COURS') returning id`)).rows[0].id;
const Z = {};
for (const c of ['Z01', 'Z02', 'Z03', 'Z04']) Z[c] = (await as(ADMIN, `insert into public.zones (mission_id, code) values ($1, $2) returning id`, [M, c])).rows[0].id;

const buyer = (o = {}) => ({
  id: uuid(), mission_id: M, zone_id: Z.Z01, surveyor_id: S1, status: 'SOUMIS', consent: true,
  q1_transporte: 'OUI', q2_frequence: 'SOUVENT', q3_difficultes: ['CHARGES_LOURDES'], q4_mode_transport: 'A_LA_MAIN',
  q5_nb_trajets: '2', q6_utilisation: 'PROBABLEMENT', q7_trajet_utile: 'ETALS_SORTIE', q8_moment_utile: 'APRES_ACHATS',
  q9_paiement: 'PRIX_FIXE', q10_prix: '200', q11_caution: 'NON', q12_inquietude: 'PRIX', ...o,
});
const vendor = (o = {}) => ({
  id: uuid(), mission_id: M, zone_id: Z.Z01, surveyor_id: S1, status: 'SOUMIS', consent: true,
  q1_difficultes_clients: 'SOUVENT', q2_produits: ['PRODUITS_LOURDS'], q3_comportement: 'PLUSIEURS_TRAJETS',
  q5_moment: 'MATIN', q6_risques: ['ENCOMBREMENT'], q7_utiliseraient: 'OUI', ...o,
});
const obs = (o = {}) => ({
  id: uuid(), mission_id: M, zone_id: Z.Z01, surveyor_id: S1, status: 'SOUMIS', observed_on: '2026-11-02',
  start_time: '09:00', end_time: '09:15', people_count: 100, heavy_load_count: 20, flow_level: 'FORT',
  obstacles: ['MARCHES'], trolley_access: 'DIFFICILE', congestion_risk: 'MOYEN', ...o,
});

// ---------------------------------------------------------------- 1-3 saisie
sec('1. Un enquêteur crée et soumet (scénarios 1, 2, 3)');
const b1 = buyer();
await test('S1 soumet un questionnaire acheteur', async () => (await ins(S1, 'buyer_responses', b1)).rows.length === 1);
await test('S1 soumet un questionnaire commerçante', async () => (await ins(S1, 'vendor_responses', vendor())).rows.length === 1);
await test('S1 enregistre une observation', async () => (await ins(S1, 'observation_sessions', obs())).rows.length === 1);
await test('L\'administrateur voit la réponse de S1 dans la base commune (scénario 4)', async () => await count(ADMIN, 'buyer_responses', `id='${b1.id}'`) === 1);
await test('S1 retrouve sa propre réponse', async () => await count(S1, 'buyer_responses', `id='${b1.id}'`) === 1);
await test('S2 ne voit PAS la réponse de S1', async () => await count(S2, 'buyer_responses') === 0);
await test('Le serveur renseigne version=1, submitted_at et synced_at', async () => {
  const r = (await as(ADMIN, `select version, submitted_at is not null s, synced_at is not null y from public.buyer_responses where id=$1`, [b1.id])).rows[0];
  return r.version === 1 && r.s && r.y;
});

// ---------------------------------------------------------------- doublons
sec('2. Anti-doublon à la synchronisation (scénario 7, côté serveur)');
await test('Renvoyer 3 fois la même réponse (même id) ne crée aucun doublon et aucune erreur', async () => {
  for (let i = 0; i < 3; i++) await ins(S1, 'buyer_responses', b1, 'on conflict (id) do nothing');
  return await count(ADMIN, 'buyer_responses', `id='${b1.id}'`) === 1;
});
const sameSlot = obs({ id: uuid() });
await expectErr('Saisir deux fois la même session d\'observation (autre id, même créneau) est refusé',
  () => ins(S1, 'observation_sessions', obs({ id: uuid() })), { code: '23505' });

// ---------------------------------------------------------------- validation
sec('3. Champs obligatoires et consentement (scénario 9)');
await expectErr('Soumettre un acheteur incomplet (Q12 manquante) est refusé par la base',
  () => ins(S1, 'buyer_responses', buyer({ q12_inquietude: null })), { code: '23514' });
await expectErr('Soumettre sans code de zone est refusé', () => ins(S1, 'buyer_responses', buyer({ zone_id: null })), { code: '23514' });
await expectErr('Un acheteur sans consentement ne peut PAS être enregistré', () => ins(S1, 'buyer_responses', buyer({ consent: false })), { code: '23514' });
await expectErr('« Autre montant » sans montant est refusé', () => ins(S1, 'buyer_responses', buyer({ q10_prix: 'AUTRE_MONTANT' })), { code: '23514' });
await expectErr('Difficulté « Autre » sans texte est refusée', () => ins(S1, 'buyer_responses', buyer({ q3_difficultes: ['AUTRE'] })), { code: '23514' });
await expectErr('Valeur hors liste (q2 = "BOF") refusée côté serveur', () => ins(S1, 'buyer_responses', buyer({ q2_frequence: 'BOF' })), { code: '23514' });
await test('Un brouillon incomplet est accepté', async () => (await ins(S1, 'buyer_responses', { id: uuid(), mission_id: M, status: 'BROUILLON', consent: true, q1_transporte: 'OUI' })).rows.length === 1);
await test('Un refus ne crée qu\'une ligne de compteur, sans réponse', async () => {
  const before = await count(ADMIN, 'buyer_responses');
  await ins(S1, 'refusals', { id: uuid(), mission_id: M, zone_id: Z.Z01, form_type: 'ACHETEUR' });
  return await count(ADMIN, 'refusals') === 1 && await count(ADMIN, 'buyer_responses') === before;
});
await test('S2 ne voit pas les refus de S1', async () => await count(S2, 'refusals') === 0);
await expectErr('Observation : heure de fin avant l\'heure de début refusée',
  () => ins(S1, 'observation_sessions', obs({ id: uuid(), start_time: '10:00', end_time: '09:00' })), { code: '23514' });
await expectErr('Observation : « Aucun » obstacle combiné à « Marches » refusé',
  () => ins(S1, 'observation_sessions', obs({ id: uuid(), start_time: '11:00', end_time: '11:15', obstacles: ['AUCUN', 'MARCHES'] })), { code: '23514' });
await expectErr('Évaluation de zone : note 6 refusée',
  () => ins(S1, 'zone_evaluations', { id: uuid(), mission_id: M, zone_id: Z.Z01, status: 'BROUILLON', score_flux: 6 }), { code: '23514' });
await test('Évaluation de zone complète acceptée (notes 1 à 5)', async () => (await ins(S1, 'zone_evaluations', {
  id: uuid(), mission_id: M, zone_id: Z.Z01, status: 'SOUMIS', score_flux: 5, score_zones_lourdes: 4, score_acces_sortie: 3,
  score_passage: 3, score_retour_chariots: 2, score_surveillance: 4, score_faible_encombrement: 1 })).rows.length === 1);
await expectErr('Une zone d\'une autre mission est refusée (cohérence mission/zone)', async () => {
  const M2x = (await as(ADMIN, `insert into public.missions (name) values ('Autre') returning id`)).rows[0].id;
  const Zx = (await as(ADMIN, `insert into public.zones (mission_id, code) values ($1,'X01') returning id`, [M2x])).rows[0].id;
  await ins(S1, 'buyer_responses', buyer({ zone_id: Zx }));
}, { code: '23503' });

// ---------------------------------------------------------------- sécurité
sec('4. Accès non autorisés (scénario 6)');
await expectErr('Un visiteur non connecté ne peut pas lire les réponses', () => asAnon(`select * from public.buyer_responses`), { code: '42501' });
await expectErr('Un visiteur non connecté ne peut pas appeler les fonctions de synthèse', () => asAnon(`select public.survey_summary($1)`, [M]), { code: '42501' });
await expectErr('Un visiteur non connecté ne peut pas écrire', () => asAnon(`insert into public.refusals (id, mission_id, surveyor_id, form_type) values (gen_random_uuid(), $1, $2, 'ACHETEUR')`, [M, S1]), { code: '42501' });
await expectErr('Un compte INACTIF ne peut pas écrire', () => ins(S3, 'buyer_responses', buyer({ surveyor_id: S3 })), { code: '42501' });
await test('Un compte INACTIF ne voit aucune donnée (missions, zones, réponses)', async () =>
  await count(S3, 'missions') === 0 && await count(S3, 'zones') === 0 && await count(S3, 'buyer_responses') === 0);
await expectErr('Un utilisateur sans profil ne peut pas écrire', () => ins(STRANGER, 'buyer_responses', buyer({ surveyor_id: STRANGER })), { code: '42501' });
await expectErr('S1 ne peut pas saisir une réponse au nom de S2', () => ins(S1, 'buyer_responses', buyer({ surveyor_id: S2 })), { code: '42501' });
await expectErr('S1 ne peut pas créer une réponse directement au statut EXCLU', () => ins(S1, 'buyer_responses', buyer({ status: 'EXCLU' })), { code: '42501' });
await test('S1 ne peut pas modifier une réponse déjà SOUMISE (0 ligne modifiée)', async () =>
  (await as(S1, `update public.buyer_responses set q2_frequence='JAMAIS' where id=$1 returning id`, [b1.id])).rows.length === 0
  && (await as(ADMIN, `select q2_frequence from public.buyer_responses where id=$1`, [b1.id])).rows[0].q2_frequence === 'SOUVENT');
await test('S1 ne peut pas supprimer une réponse soumise', async () =>
  (await as(S1, `delete from public.buyer_responses where id=$1 returning id`, [b1.id])).rows.length === 0);
await test('S2 ne peut ni modifier ni supprimer la réponse de S1', async () =>
  (await as(S2, `update public.buyer_responses set q12_inquietude='AUCUNE' where id=$1 returning id`, [b1.id])).rows.length === 0
  && (await as(S2, `delete from public.buyer_responses where id=$1 returning id`, [b1.id])).rows.length === 0);
await test('S1 ne peut pas lire le journal d\'audit', async () => await count(S1, 'audit_log') === 0);
await expectErr('S1 ne peut pas écrire dans le journal d\'audit', () => as(S1, `insert into public.audit_log (table_name, action) values ('x','x')`), { code: '42501' });
await expectErr('S1 ne peut pas vider une table (TRUNCATE)', () => as(S1, `truncate public.buyer_responses`), { code: '42501' });
await test('S1 ne voit que son propre profil', async () => await count(S1, 'profiles') === 1);
await test('S1 ne peut pas se donner le rôle administrateur', async () => {
  const r = await as(S1, `update public.profiles set role='ADMINISTRATEUR', active=true where id=$1 returning id`, [S1]);
  const role = (await db.query(`select role from public.profiles where id=$1`, [S1])).rows[0].role;
  return r.rows.length === 0 && role === 'ENQUETEUR';
});
await test('S1 ne peut pas activer le compte inactif S3', async () => (await as(S1, `update public.profiles set active=true where id=$1 returning id`, [S3])).rows.length === 0);
await expectErr('S1 ne peut pas créer de zone', () => as(S1, `insert into public.zones (mission_id, code) values ($1,'Z99')`, [M]), { code: '42501' });
await test('S1 ne peut pas modifier la mission', async () => (await as(S1, `update public.missions set name='piraté' where id=$1 returning id`, [M])).rows.length === 0);
await expectErr('S1 ne peut pas appeler la synthèse (réservée à l\'administrateur)', () => as(S1, `select public.survey_summary($1)`, [M]), { code: '42501' });
await test('L\'administrateur ne peut pas se retirer ses propres droits', async () => {
  try { await as(ADMIN, `update public.profiles set role='ENQUETEUR' where id=$1`, [ADMIN]); return false; }
  catch (e) { return e.code === '42501'; }
});

// ---------------------------------------------------------------- brouillons et conflits
sec('5. Brouillons, versions et conflits');
const d1 = { id: uuid(), mission_id: M, zone_id: Z.Z02, status: 'BROUILLON', consent: true, q1_transporte: 'OUI' };
await ins(S1, 'buyer_responses', d1);
await test('S1 modifie son brouillon : la version passe à 2', async () => {
  const r = await as(S1, `update public.buyer_responses set q2_frequence='SOUVENT', version=1 where id=$1 returning version`, [d1.id]);
  return r.rows[0]?.version === 2;
});
await expectErr('Modification avec une version périmée : CONFLIT explicite (HTTP 409), pas d\'écrasement',
  () => as(S1, `update public.buyer_responses set q2_frequence='JAMAIS', version=1 where id=$1`, [d1.id]), { code: 'PT409', msg: 'CONFLIT_VERSION' });
await test('Après le conflit, la valeur serveur est intacte', async () =>
  (await as(S1, `select q2_frequence from public.buyer_responses where id=$1`, [d1.id])).rows[0].q2_frequence === 'SOUVENT');
await expectErr('S1 ne peut pas changer l\'auteur d\'un brouillon',
  () => as(S1, `update public.buyer_responses set surveyor_id=$2, version=2 where id=$1`, [d1.id, S2]), { code: '42501' });
await test('S1 soumet son brouillon complété (version 2 -> 3)', async () => {
  const r = await as(S1, `update public.buyer_responses set status='SOUMIS', q3_difficultes=ARRAY['PLUSIEURS_SACS'], q4_mode_transport='A_LA_MAIN',
    q5_nb_trajets='1', q6_utilisation='PAS_SUR', q7_trajet_utile='ENTRE_ETALS', q8_moment_utile='TOUTE_VISITE', q9_paiement='AUCUN',
    q10_prix='NE_PAIERAIT_PAS', q11_caution='NE_SAIT_PAS', q12_inquietude='AUCUNE', version=2 where id=$1 returning version, submitted_at`, [d1.id]);
  return r.rows[0]?.version === 3 && r.rows[0].submitted_at !== null;
});
await test('Brouillon renvoyé après soumission : 0 ligne modifiée (le téléphone reconnaît via client_rev)', async () =>
  (await as(S1, `update public.buyer_responses set q1_transporte='NON', version=2 where id=$1 returning id`, [d1.id])).rows.length === 0);
await test('S1 peut supprimer son propre brouillon', async () => {
  const d = { id: uuid(), mission_id: M, status: 'BROUILLON', consent: true };
  await ins(S1, 'buyer_responses', d);
  return (await as(S1, `delete from public.buyer_responses where id=$1 returning id`, [d.id])).rows.length === 1;
});

// ---------------------------------------------------------------- admin + audit
sec('6. Correction par l\'administrateur et traçabilité');
await test('L\'administrateur corrige une réponse soumise (avec la bonne version)', async () =>
  (await as(ADMIN, `update public.buyer_responses set q2_frequence='PARFOIS', version=1 where id=$1 returning version`, [b1.id])).rows[0]?.version === 2);
await test('La correction est tracée dans audit_log (avant ET après, auteur = administrateur)', async () => {
  const a = (await as(ADMIN, `select actor_id, actor_role, old_data->>'q2_frequence' o, new_data->>'q2_frequence' n
    from public.audit_log where table_name='buyer_responses' and record_id=$1 and action='UPDATE'`, [b1.id])).rows;
  return a.length === 1 && a[0].actor_id === ADMIN && a[0].actor_role === 'ADMINISTRATEUR' && a[0].o === 'SOUVENT' && a[0].n === 'PARFOIS';
});
await expectErr('Deux administrateurs : la 2e correction avec une version périmée est refusée (conflit)',
  () => as(ADMIN, `update public.buyer_responses set q2_frequence='JAMAIS', version=1 where id=$1`, [b1.id]), { code: 'PT409' });
await test('Les sauvegardes successives d\'un BROUILLON ne polluent pas l\'audit', async () => {
  const n = await count(ADMIN, 'audit_log', `table_name='buyer_responses' and record_id='${d1.id}' and new_data->>'status'='BROUILLON' and old_data->>'status'='BROUILLON'`);
  return n === 0;
});
await test('L\'administrateur exclut une réponse (statut EXCLU)', async () => {
  const e = buyer({ id: uuid() }); await ins(S1, 'buyer_responses', e);
  return (await as(ADMIN, `update public.buyer_responses set status='EXCLU', version=1 where id=$1 returning status`, [e.id])).rows[0]?.status === 'EXCLU';
});
await test('La suppression par l\'administrateur est tracée (contenu supprimé conservé dans l\'audit)', async () => {
  const x = buyer({ id: uuid() }); await ins(S2, 'buyer_responses', { ...x, surveyor_id: S2 });
  await as(ADMIN, `delete from public.buyer_responses where id=$1`, [x.id]);
  const a = (await as(ADMIN, `select action, old_data->>'surveyor_id' s from public.audit_log where record_id=$1 and action='DELETE'`, [x.id])).rows;
  return a.length === 1 && a[0].s === S2 && await count(ADMIN, 'buyer_responses', `id='${x.id}'`) === 0;
});

// ---------------------------------------------------------------- zones
sec('7. Zones et emplacements candidats (Module E)');
await test('Le code de zone est normalisé en majuscules (z05 -> Z05)', async () =>
  (await as(ADMIN, `insert into public.zones (mission_id, code) values ($1,'z05') returning code`, [M])).rows[0].code === 'Z05');
await expectErr('Code de zone en double refusé', () => as(ADMIN, `insert into public.zones (mission_id, code) values ($1,'Z01')`, [M]), { code: '23505' });
for (const c of ['Z01', 'Z02', 'Z03']) await as(ADMIN, `update public.zones set is_candidate=true where id=$1`, [Z[c]]);
await expectErr('Plus de 3 zones candidates refusé', () => as(ADMIN, `update public.zones set is_candidate=true where id=$1`, [Z.Z04]), { code: '23514' });
await expectErr('Une zone non candidate ne peut pas être « validée »', () => as(ADMIN, `update public.zones set approval_status='VALIDE' where id=$1`, [Z.Z04]), { code: '23514' });
await test('Une zone n\'est jamais « validée » par défaut', async () => (await as(S1, `select approval_status from public.zones where id=$1`, [Z.Z01])).rows[0].approval_status === 'NON_VALIDE');
await test('S1 ne peut pas valider une zone', async () => (await as(S1, `update public.zones set approval_status='VALIDE' where id=$1 returning id`, [Z.Z01])).rows.length === 0);
await test('L\'administrateur valide une zone : validé par + date enregistrés automatiquement', async () => {
  const r = (await as(ADMIN, `update public.zones set approval_status='VALIDE' where id=$1 returning approved_by, approved_at`, [Z.Z01])).rows[0];
  return r.approved_by === ADMIN && r.approved_at !== null;
});
await test('Repasser une zone à « non validée » efface la validation', async () => {
  const r = (await as(ADMIN, `update public.zones set approval_status='NON_VALIDE' where id=$1 returning approved_by, approved_at`, [Z.Z01])).rows[0];
  return r.approved_by === null && r.approved_at === null;
});

// ---------------------------------------------------------------- statistiques
sec('8. Synthèse automatique (scénario 5) : comparée à un calcul indépendant en JavaScript');
const M2 = (await as(ADMIN, `insert into public.missions (name) values ('Mission stats') returning id`)).rows[0].id;
const Y = {};
for (const c of ['Y01', 'Y02']) Y[c] = (await as(ADMIN, `insert into public.zones (mission_id, code) values ($1,$2) returning id`, [M2, c])).rows[0].id;
const spec = [
  ['Y01', S1, 'SOUVENT', '2', 'CERTAINEMENT', '200', ['CHARGES_LOURDES', 'PLUSIEURS_TRAJETS'], 'PRIX'],
  ['Y01', S1, 'PRESQUE_CHAQUE_VISITE', '3_OU_PLUS', 'PROBABLEMENT', '100', ['CHARGES_LOURDES'], 'DISPONIBILITE'],
  ['Y01', S1, 'PARFOIS', '1', 'PAS_SUR', 'NE_PAIERAIT_PAS', ['PLUSIEURS_SACS'], 'PRIX'],
  ['Y02', S2, 'JAMAIS', 'VARIABLE', 'CERTAINEMENT_PAS', 'AUTRE_MONTANT', ['AUTRE'], 'AUCUNE'],
  ['Y02', S2, 'SOUVENT', '2', 'PROBABLEMENT', '300', ['DISTANCE', 'MAINS_OCCUPEES'], 'SECURITE'],
  ['Y02', S2, 'RAREMENT', 'NE_SAIT_PAS', 'PROBABLEMENT_PAS', '200', ['VOLUMINEUX'], 'OU_RENDRE'],
  ['Y02', S2, 'PARFOIS', '2', 'CERTAINEMENT', '200', ['CHARGES_LOURDES'], 'PRIX'],
];
const rows = spec.map(([z, s, q2, q5, q6, q10, q3, q12]) => ({
  zone: z, s, q2, q5, q6, q10, q3, q12,
  row: buyer({ id: uuid(), mission_id: M2, zone_id: Y[z], surveyor_id: s, q2_frequence: q2, q5_nb_trajets: q5, q6_utilisation: q6, q10_prix: q10,
    q10_montant_fcfa: q10 === 'AUTRE_MONTANT' ? 150 : null, q3_difficultes: q3, q3_autre: q3.includes('AUTRE') ? 'autre' : null, q12_inquietude: q12 }),
}));
for (const r of rows) await ins(r.s, 'buyer_responses', r.row);
await ins(S1, 'buyer_responses', { id: uuid(), mission_id: M2, zone_id: Y.Y01, status: 'BROUILLON', consent: true });           // brouillon : ne compte pas
const ex = buyer({ id: uuid(), mission_id: M2, zone_id: Y.Y01 }); await ins(S1, 'buyer_responses', ex);
await as(ADMIN, `update public.buyer_responses set status='EXCLU', version=1 where id=$1`, [ex.id]);                              // exclue : ne compte pas
const vspec = [['Y01', S1, 'SOUVENT', 'OUI'], ['Y01', S1, 'TRES_SOUVENT', 'OUI'], ['Y02', S2, 'PARFOIS', 'NON']];
for (const [z, s, q1, q7] of vspec) await ins(s, 'vendor_responses', vendor({ id: uuid(), mission_id: M2, zone_id: Y[z], surveyor_id: s, q1_difficultes_clients: q1, q7_utiliseraient: q7 }));
const ospec = [['Y01', S1, 'FORT', 120, 30, '09:00'], ['Y01', S1, 'MOYEN', 80, 10, '10:00'], ['Y02', S2, 'FAIBLE', 40, 2, '09:00']];
for (const [z, s, fl, p, h, st] of ospec) await ins(s, 'observation_sessions', obs({ id: uuid(), mission_id: M2, zone_id: Y[z], surveyor_id: s, flow_level: fl, people_count: p, heavy_load_count: h, start_time: st, end_time: st.replace(':00', ':15') }));
await ins(S1, 'observation_sessions', { id: uuid(), mission_id: M2, zone_id: Y.Y02, status: 'BROUILLON', observed_on: '2026-11-02' }); // brouillon

const sum = (await as(ADMIN, `select public.survey_summary($1) s`, [M2])).rows[0].s;
const N = rows.length;
const exp = (f) => rows.filter(f).length;
await test(`Acheteurs valides : ${N} (brouillon et exclue non comptés)`, () => sum.buyers_total === N);
await test('Commerçantes valides : 3', () => sum.vendors_total === 3);
await test('Sessions d\'observation : 3 (brouillon non compté)', () => sum.observations_total === 3);
await test('Zones étudiées : 2', () => sum.zones_studied === 2);
await test('Difficultés souvent/presque toujours : n et d exacts', () => eq(sum.buyers_often_difficulty, { n: exp(r => ['SOUVENT', 'PRESQUE_CHAQUE_VISITE'].includes(r.q2)), d: N }));
await test('Intérêt (certainement/probablement) : n et d exacts', () => eq(sum.buyers_interested, { n: exp(r => ['CERTAINEMENT', 'PROBABLEMENT'].includes(r.q6)), d: N }));
await test('Deux trajets ou plus : n et d exacts', () => eq(sum.buyers_two_trips_or_more, { n: exp(r => ['2', '3_OU_PLUS'].includes(r.q5)), d: N }));
await test('Répartition des prix exacte', () => {
  const e = {}; rows.forEach(r => e[r.q10] = (e[r.q10] || 0) + 1);
  return eq(Object.fromEntries(Object.entries(sum.price_distribution).sort()), Object.fromEntries(Object.entries(e).sort()));
});
await test('« Autre montant » : 150 FCFA relevé', () => eq(sum.price_other_amounts_fcfa, [150]));
await test('Difficultés les plus fréquentes : comptes exacts', () => {
  const e = {}; rows.forEach(r => r.q3.forEach(d => e[d] = (e[d] || 0) + 1));
  return eq(Object.fromEntries(Object.entries(sum.difficulties).sort()), Object.fromEntries(Object.entries(e).sort()));
});
await test('Inquiétudes les plus fréquentes : comptes exacts', () => {
  const e = {}; rows.forEach(r => e[r.q12] = (e[r.q12] || 0) + 1);
  return eq(Object.fromEntries(Object.entries(sum.concerns).sort()), Object.fromEntries(Object.entries(e).sort()));
});
await test('Commerçantes : clients en difficulté souvent 2/3, utiliseraient 2/3', () =>
  eq(sum.vendors_clients_often_difficulty, { n: 2, d: 3 }) && eq(sum.vendors_clients_would_use, { n: 2, d: 3 }));
await test('Brouillons et exclues comptés à part (1 brouillon + 1 exclue acheteur, 1 brouillon observation)', () =>
  sum.drafts.buyers === 1 && sum.excluded.buyers === 1 && sum.drafts.observations === 1);
await test('Détail par zone Y01 : 3 acheteurs, 2 en difficulté fréquente, 2 intéressés, 200 personnes observées, 40 charges lourdes', () => {
  const z = sum.zones.find(x => x.zone_code === 'Y01');
  return z.buyers === 3 && z.buyers_often_difficulty === 2 && z.buyers_interested === 2 && z.observations === 2
    && z.observed_people_total === 200 && z.observed_heavy_loads_total === 40 && z.observed_strong_flow_sessions === 1;
});
await test('Filtre par zone Y02 : seulement les 4 acheteurs de Y02', async () => {
  const s = (await as(ADMIN, `select public.survey_summary($1, null, null, null, $2) s`, [M2, Y.Y02])).rows[0].s;
  return s.buyers_total === exp(r => r.zone === 'Y02');
});
await test('Filtre par enquêteur S1 : seulement ses 3 acheteurs', async () => {
  const s = (await as(ADMIN, `select public.survey_summary($1, null, null, $2, null) s`, [M2, S1])).rows[0].s;
  return s.buyers_total === exp(r => r.s === S1);
});
await test('Filtre par dates (futur lointain) : aucun résultat, pas de faux chiffres', async () => {
  const s = (await as(ADMIN, `select public.survey_summary($1, '2030-01-01'::date, null, null, null) s`, [M2])).rows[0].s;
  return s.buyers_total === 0 && s.observations_total === 0;
});
await test('Mission sans aucune donnée : tous les compteurs à 0 (état vide, rien de fictif)', async () => {
  const E = (await as(ADMIN, `insert into public.missions (name) values ('Vide') returning id`)).rows[0].id;
  const s = (await as(ADMIN, `select public.survey_summary($1) s`, [E])).rows[0].s;
  return s.buyers_total === 0 && s.vendors_total === 0 && s.observations_total === 0 && s.buyers_often_difficulty.d === 0 && s.first_date === null;
});

sec('9. Progression d\'équipe (compteurs seulement)');
await test('S1 voit les compteurs de chaque enquêteur actif, sans contenu', async () => {
  const r = (await as(S1, `select * from public.team_progress($1)`, [M2])).rows;
  const byName = Object.fromEntries(r.map(x => [x.surveyor_name, x]));
  return Number(byName['Awa'].buyers) === 3 && Number(byName['Koffi'].buyers) === 4 && !r.some(x => x.surveyor_name === 'Inactif');
});
await test('S1 voit l\'aperçu de mission (totaux et objectifs 30 / 15)', async () => {
  const o = (await as(S1, `select public.mission_overview($1) o`, [M2])).rows[0].o;
  return o.buyers === N && o.vendors === 3 && o.target_buyers === 30 && o.target_vendors === 15;
});
await test('Un compte inactif n\'obtient ni progression ni aperçu', async () =>
  (await as(S3, `select * from public.team_progress($1)`, [M2])).rows.length === 0
  && (await as(S3, `select public.mission_overview($1) o`, [M2])).rows[0].o === null);

// ---------------------------------------------------------------- rapport
const failed = results.filter(r => !r.ok);
console.log(`\n=== ${results.length - failed.length} réussis / ${failed.length} échecs sur ${results.length} tests ===`);
let md = `# Résultats des tests de la base de données\n\nExécutés le ${new Date().toISOString()} sur PostgreSQL local (PGlite), script 001_schema.sql.\n\n`;
md += `**${results.length - failed.length} réussis, ${failed.length} échecs, ${results.length} au total.**\n\n`;
md += `> Ces tests couvrent la base de données (règles d'accès, validation, doublons, conflits, audit, statistiques).\n> Ils ne remplacent pas le test sur un vrai projet Supabase avec deux téléphones (voir le guide).\n\n`;
let cur = '';
for (const r of results) {
  if (r.section !== cur) { cur = r.section; md += `\n## ${cur}\n\n`; }
  md += `- ${r.ok ? '✅' : '❌'} ${r.name}${r.ok ? '' : ` — ${r.detail}`}\n`;
}
fs.writeFileSync(path.join(here, 'results.md'), md);
process.exit(failed.length ? 1 : 0);
