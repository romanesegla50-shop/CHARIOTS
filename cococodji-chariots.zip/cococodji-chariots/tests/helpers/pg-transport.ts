import type { Transport, TransportResult } from '@/lib/sync';
import { classifyError } from '@/lib/supabase';

type Query = (sql: string, params: unknown[]) => Promise<{ rows: any[] }>;

/**
 * Faux « client Supabase » branché sur la vraie base PostgreSQL de test.
 * Il envoie la même chose que le vrai transport : INSERT ... ON CONFLICT (id) DO NOTHING
 * (c'est ce que fait upsert(..., { onConflict: 'id', ignoreDuplicates: true })),
 * et range les erreurs avec la MÊME fonction classifyError que l'application.
 */
export function supabaseTransportForTests(query: Query): Transport {
  return {
    async insertIgnoreDuplicates(table: string, row: Record<string, unknown>): Promise<TransportResult> {
      const keys = Object.keys(row);
      const cols = keys.map((k) => `"${k}"`).join(', ');
      const ph = keys.map((_, i) => `$${i + 1}`).join(', ');
      try {
        await query(
          `insert into public.${table} (${cols}) values (${ph}) on conflict (id) do nothing`,
          keys.map((k) => row[k]),
        );
        return { ok: true };
      } catch (e: any) {
        // PostgREST répond 4xx pour les refus de la base
        return classifyError({ code: e.code, message: e.message }, 400);
      }
    },
  };
}
