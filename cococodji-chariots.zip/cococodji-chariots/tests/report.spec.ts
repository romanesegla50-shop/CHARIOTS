import { PGlite } from '@electric-sql/pglite';
import { afterAll, beforeAll, describe, expect, it } from 'vitest';
import { randomUUID as uuid } from 'node:crypto';
import { spawnSync } from 'node:child_process';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import type { FullZone, ServerRow, Summary } from '@/lib/admin';
import { buildReport, type ReportModel } from '@/lib/report';
import { renderReportPdf, pdfSafe } from '@/lib/pdf';
import { DISCLAIMER, NOT_AUTHORIZED } from '@/lib/stats';

// Chaîne complète : vraies données -> vraie fonction SQL survey_summary -> modèle du rapport -> PDF -> relecture du PDF.

const db = new PGlite();
const ADMIN = uuid();
const S1 = uuid();
const S2 = uuid();
let M = '';
const Z: Record<string, string> = {};
let summary: Summary;
let zones: FullZone[] = [];
let evaluations: ServerRow[] = [];
let mission: any;

async function as(uid: string, sql: string, params: unknown[] = []): Promise<{ rows: any[] }> {
  await db.exec(`set role authenticated; select set_config('request.jwt.claim.sub', '${uid}', false);`);
  try { return await db.query<any>(sql, params); }
  finally { await db.exec(`reset role; select set_config('request.jwt.claim.sub', '', false);`); }
}
async function ins(uid: string, table: string, row: Record<string, unknown>) {
  const keys = Object.keys(row);
  await as(uid, `insert into public.${table} (${keys.join(',')}) values (${keys.map((_, i) => `$${i + 1}`).join(',')})`, Object.values(row));
}

const buyer = (zone: string, s: string, q2: string, q5: string, q6: string, q10: string, q3: string[], q12: string) => ({
  id: uuid(), mission_id: M, zone_id: Z[zone], surveyor_id: s, status: 'SOUMIS', consent: true,
  started_at: '2026-11-02T08:15:00Z', ended_at: '2026-11-02T08:25:00Z',
  q1_transporte: 'OUI', q2_frequence: q2, q3_difficultes: q3, q3_autre: q3.includes('AUTRE') ? 'x' : null, q4_mode_transport: 'A_LA_MAIN',
  q5_nb_trajets: q5, q6_utilisation: q6, q7_trajet_utile: 'ETALS_SORTIE', q8_moment_utile: 'APRES_ACHATS', q9_paiement: 'PRIX_FIXE',
  q10_prix: q10, q10_montant_fcfa: q10 === 'AUTRE_MONTANT' ? 150 : null, q11_caution: 'NON', q12_inquietude: q12,
});

beforeAll(async () => {
  await db.exec(`
    create role anon nologin; create role authenticated nologin; create role service_role nologin bypassrls;
    create schema auth;
    create table auth.users (id uuid primary key default gen_random_uuid(), email text, raw_user_meta_data jsonb default '{}'::jsonb);
    create function auth.uid() returns uuid language sql stable as $$ select nullif(current_setting('request.jwt.claim.sub', true), '')::uuid $$;
    grant usage on schema public, auth to anon, authenticated;
    alter default privileges in schema public grant all on tables to anon, authenticated, service_role;
  `);
  await db.exec(fs.readFileSync(path.resolve(process.cwd(), 'supabase/migrations/001_schema.sql'), 'utf8'));
  for (const [id, e, n] of [[ADMIN, 'a@t.bj', 'Admin'], [S1, 's1@t.bj', 'Awa'], [S2, 's2@t.bj', 'Koffi']]) {
    await db.query(`insert into auth.users (id, email, raw_user_meta_data) values ($1,$2,$3)`, [id, e, JSON.stringify({ full_name: n })]);
  }
  await db.query(`update public.profiles set active=true where id in ($1,$2)`, [S1, S2]);
  await db.query(`update public.profiles set active=true, role='ADMINISTRATEUR' where id=$1`, [ADMIN]);
  M = (await as(ADMIN, `insert into public.missions (name, status, start_date, end_date, target_buyers, target_vendors, target_observations)
    values ('Mission pilote Cococodji','EN_COURS','2026-11-02','2026-11-08',30,15,6) returning id`)).rows[0].id;
  for (const c of ['Y01', 'Y02', 'Y03']) Z[c] = (await as(ADMIN, `insert into public.zones (mission_id, code, label) values ($1,$2,$3) returning id`, [M, c, c === 'Y01' ? 'Entrée nord' : null])).rows[0].id;
  await as(ADMIN, `update public.zones set is_candidate=true where id in ($1,$2)`, [Z.Y01, Z.Y02]);
  await as(ADMIN, `update public.zones set approval_status='VALIDE', manager_checks=$2::jsonb where id=$1`, [Z.Y01, JSON.stringify({ espace: { done: true, note: '' }, horaires: { done: true, note: '' } })]);

  const rows = [
    buyer('Y01', S1, 'SOUVENT', '2', 'CERTAINEMENT', '200', ['CHARGES_LOURDES', 'PLUSIEURS_TRAJETS'], 'PRIX'),
    buyer('Y01', S1, 'PRESQUE_CHAQUE_VISITE', '3_OU_PLUS', 'PROBABLEMENT', '100', ['CHARGES_LOURDES'], 'DISPONIBILITE'),
    buyer('Y01', S1, 'PARFOIS', '1', 'PAS_SUR', 'NE_PAIERAIT_PAS', ['PLUSIEURS_SACS'], 'PRIX'),
    buyer('Y02', S2, 'JAMAIS', 'VARIABLE', 'CERTAINEMENT_PAS', 'AUTRE_MONTANT', ['AUTRE'], 'AUCUNE'),
    buyer('Y02', S2, 'SOUVENT', '2', 'PROBABLEMENT', '300', ['DISTANCE', 'MAINS_OCCUPEES'], 'SECURITE'),
    buyer('Y02', S2, 'RAREMENT', 'NE_SAIT_PAS', 'PROBABLEMENT_PAS', '200', ['VOLUMINEUX'], 'OU_RENDRE'),
    buyer('Y02', S2, 'PARFOIS', '2', 'CERTAINEMENT', '200', ['CHARGES_LOURDES'], 'PRIX'),
  ];
  for (const r of rows) await ins(r.surveyor_id, 'buyer_responses', r);
  for (const [z, s, q1, q7] of [['Y01', S1, 'SOUVENT', 'OUI'], ['Y01', S1, 'TRES_SOUVENT', 'OUI'], ['Y02', S2, 'PARFOIS', 'NON']] as const) {
    await ins(s, 'vendor_responses', {
      id: uuid(), mission_id: M, zone_id: Z[z], surveyor_id: s, status: 'SOUMIS', consent: true, started_at: '2026-11-02T09:00:00Z', q1_difficultes_clients: q1,
      q2_produits: ['PRODUITS_LOURDS'], q3_comportement: 'PLUSIEURS_TRAJETS', q5_moment: 'MATIN', q6_risques: ['ENCOMBREMENT', 'VOL_PERTE'], q7_utiliseraient: q7,
    });
  }
  for (const [z, s, fl, p, h, st] of [['Y01', S1, 'FORT', 120, 30, '09:00'], ['Y01', S1, 'MOYEN', 80, 10, '10:00'], ['Y02', S2, 'FAIBLE', 40, 2, '09:00']] as const) {
    await ins(s, 'observation_sessions', {
      id: uuid(), mission_id: M, zone_id: Z[z], surveyor_id: s, status: 'SOUMIS', observed_on: '2026-11-02', start_time: st, end_time: st.replace(':00', ':15'),
      people_count: p, heavy_load_count: h, flow_level: fl, obstacles: ['MARCHES'], trolley_access: 'DIFFICILE', congestion_risk: 'MOYEN',
    });
  }
  for (const [s, sc] of [[S1, [5, 4, 3, 3, 2, 4, 1]], [S2, [3, 4, 5, 3, 4, 4, 3]]] as const) {
    await ins(s, 'zone_evaluations', {
      id: uuid(), mission_id: M, zone_id: Z.Y01, surveyor_id: s, status: 'SOUMIS',
      score_flux: sc[0], score_zones_lourdes: sc[1], score_acces_sortie: sc[2], score_passage: sc[3], score_retour_chariots: sc[4], score_surveillance: sc[5], score_faible_encombrement: sc[6],
    });
  }
  await ins(S1, 'refusals', { id: uuid(), mission_id: M, zone_id: Z.Y01, form_type: 'ACHETEUR' });
  await ins(S1, 'refusals', { id: uuid(), mission_id: M, zone_id: Z.Y01, form_type: 'ACHETEUR' });

  summary = (await as(ADMIN, `select public.survey_summary($1) s`, [M])).rows[0].s;
  // l'interface REST de Supabase renvoie du JSON : on reproduit ce passage (les dates deviennent des chaînes)
  const viaJson = <T,>(v: T): T => JSON.parse(JSON.stringify(v));
  zones = viaJson((await as(ADMIN, `select * from public.zones where mission_id=$1 order by code`, [M])).rows);
  evaluations = viaJson((await as(ADMIN, `select * from public.zone_evaluations where mission_id=$1`, [M])).rows);
  mission = viaJson((await as(ADMIN, `select * from public.missions where id=$1`, [M])).rows[0]);
});
afterAll(async () => { await db.close(); });

const section = (m: ReportModel, start: string) => m.sections.find((s) => s.title.startsWith(start))!;
const tables = (m: ReportModel, start: string) => section(m, start).blocks.filter((b) => b.type === 'table') as Extract<ReportModel['sections'][0]['blocks'][0], { type: 'table' }>[];

function pdfText(buf: Buffer): { text: string; pages: number } {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'pdf-'));
  const f = path.join(dir, 'r.pdf');
  fs.writeFileSync(f, buf);
  const t = spawnSync('pdftotext', ['-layout', f, '-'], { encoding: 'utf8' });
  const i = spawnSync('pdfinfo', [f], { encoding: 'utf8' });
  return { text: t.stdout, pages: Number(/Pages:\s+(\d+)/.exec(i.stdout)?.[1] ?? 0) };
}
const flat = (s: string) => s.replace(/\s+/g, ' ');

describe('Modèle du rapport (chiffres issus de la vraie base)', () => {
  const m = () => buildReport({ mission, summary, zones, evaluations, generatedAt: '2026-11-09T10:00:00Z' });

  it('porte l\'avertissement « enquête exploratoire » et la mention « ni autorisé ni lancé »', () => {
    expect(m().notices).toEqual([NOT_AUTHORIZED, DISCLAIMER]);
    expect(DISCLAIMER).toMatch(/enquête exploratoire/);
    expect(NOT_AUTHORIZED).toMatch(/ni autorisé ni lancé/);
  });

  it('échantillon : effectifs réalisés et objectifs, période de collecte', () => {
    const t = tables(m(), '1.')[0];
    expect(t.rows[0]).toEqual(['Acheteurs interrogés (réponses valides)', '7', '30']);
    expect(t.rows[1]).toEqual(['Commerçantes interrogées (réponses valides)', '3', '15']);
    expect(t.rows[2]).toEqual(['Sessions d\'observation', '3', '6']);
    expect(t.rows[3][1]).toBe('2');
    const bullets = section(m(), '1.').blocks.find((b) => b.type === 'bullets') as any;
    expect(bullets.items[0]).toBe('Période des réponses : du 02/11/2026 au 02/11/2026.');
    expect(bullets.items.join(' ')).toContain('Refus de répondre comptés (anonymes) : 2');
  });

  it('acheteurs : chaque pourcentage a son numérateur et son dénominateur (3/7, 4/7, 6/7, 4/7)', () => {
    const rows = tables(m(), '3.')[0].rows;
    expect(rows[0]).toEqual(['Difficultés « souvent » ou « presque à chaque visite »', '3', '7', '43 %']);
    expect(rows[1]).toEqual(['Intérêt déclaré (« certainement » ou « probablement »)', '4', '7', '57 %']);
    expect(rows[2]).toEqual(['Volonté déclarée de payer (un prix a été choisi)', '6', '7', '86 %']);
    expect(rows[3]).toEqual(['Deux trajets ou plus pour une visite typique', '4', '7', '57 %']);
  });

  it('prix : libellés français et base visible ; « Autre montant » signalé', () => {
    const price = tables(m(), '3.').find((t) => t.caption?.startsWith('Prix'))!;
    expect(price.rows).toContainEqual(['200 FCFA', '3', '7', '43 %']);
    expect(price.rows).toContainEqual(['Je ne paierais pas', '1', '7', '14 %']);
    expect(price.rows).toContainEqual(['Autre montant', '1', '7', '14 %']);
    const para = section(m(), '3.').blocks.find((b) => b.type === 'para' && /Autres montants/.test(b.text)) as any;
    expect(para.text).toContain('150');
  });

  it('le rapport distingue intérêt déclaré, volonté de payer, utilisation réelle et rentabilité', () => {
    const warn = section(m(), '3.').blocks.find((b) => b.type === 'para' && b.style === 'warning') as any;
    expect(warn.text).toMatch(/intérêt déclaré/i);
    expect(warn.text).toMatch(/utilisation réelle/i);
    expect(warn.text).toMatch(/rentabilité/i);
  });

  it('commerçantes et zones : n sur d exacts', () => {
    expect(tables(m(), '4.')[0].rows[0].slice(1)).toEqual(['2', '3', '67 %']);
    const z = tables(m(), '5.')[0];
    const y01 = z.rows.find((r) => r[0] === 'Y01')!;
    expect(y01[1]).toBe('3'); // acheteurs
    expect(y01[2]).toBe('2 sur 3'); // difficultés fréquentes
    expect(y01[6]).toBe('200'); // personnes observées 120 + 80
    expect(y01[7]).toBe('40'); // charges lourdes 30 + 10
  });

  it('emplacements candidats : moyennes sur les évaluations, validation explicite, points à confirmer', () => {
    const [scores, checks] = tables(m(), '6.');
    const y01 = scores.rows.find((r) => r[0] === 'Y01')!;
    expect(y01[1]).toBe('2');
    expect(y01[2]).toBe('4'); // flux (5+3)/2
    expect(y01[y01.length - 2]).toBe('24'); // total
    expect(y01[y01.length - 1]).toMatch(/^Validée le \d{2}\/\d{2}\/\d{4}$/);
    const y02 = scores.rows.find((r) => r[0] === 'Y02')!;
    expect(y02[1]).toBe('0');
    expect(y02[2]).toBe('-'); // aucune note inventée
    expect(y02[y02.length - 1]).toBe('Non validée');
    expect(checks.rows.find((r) => r[0] === 'Y01')!.slice(1)).toEqual(['Confirmé', 'À confirmer', 'À confirmer', 'Confirmé', 'À confirmer', 'À confirmer']);
    expect(scores.rows.map((r) => r[0])).toEqual(['Y01', 'Y02']); // Y03 non candidate absente
  });

  it('méthode et limites : anonymat, petits échantillons, déclaratif', () => {
    const items = (section(m(), '7.').blocks[0] as any).items.join(' ');
    expect(items).toMatch(/anonyme/);
    expect(items).toMatch(/petits et non aléatoires/);
    expect(items).toMatch(/déclaratives/);
  });
});

describe('Rapport sans aucune donnée (rien de fictif)', () => {
  it('affiche « aucun résultat » et aucun pourcentage', async () => {
    const E = (await as(ADMIN, `insert into public.missions (name) values ('Vide') returning id`)).rows[0].id;
    const empty: Summary = (await as(ADMIN, `select public.survey_summary($1) s`, [E])).rows[0].s;
    const m = buildReport({ mission: { ...mission, target_observations: 0 }, summary: empty, zones: [], evaluations: [], generatedAt: '2026-11-09T10:00:00Z' });
    expect(JSON.stringify(m.sections)).not.toMatch(/\d+ %/);
    expect((section(m, '3.').blocks[0] as any).text).toMatch(/Aucun questionnaire acheteur valide/);
    expect((section(m, '6.').blocks[0] as any).text).toMatch(/Aucune zone candidate/);
    const { text } = pdfText(Buffer.from(await (await renderReportPdf(m)).arrayBuffer()));
    expect(flat(text)).toContain('Aucun questionnaire acheteur valide');
    expect(flat(text)).toContain(flat(pdfSafe(DISCLAIMER)));
  });
});

describe('PDF (relu avec pdftotext)', () => {
  let text = '';
  let pages = 0;
  beforeAll(async () => {
    const model = buildReport({ mission, summary, zones, evaluations, generatedAt: '2026-11-09T10:00:00Z' });
    const buf = Buffer.from(await (await renderReportPdf(model)).arrayBuffer());
    expect(buf.subarray(0, 5).toString()).toBe('%PDF-');
    ({ text, pages } = pdfText(buf));
    fs.mkdirSync(path.resolve(process.cwd(), 'tests/screenshots'), { recursive: true });
    fs.writeFileSync(path.resolve(process.cwd(), 'tests/sample-report.pdf'), buf);
  });

  it('contient les chiffres calculés, l\'échantillon et les avertissements', () => {
    const t = flat(text);
    expect(pages).toBeGreaterThanOrEqual(2);
    expect(t).toContain('Rapport de synthèse de l\'enquête terrain');
    expect(t).toContain('Mission pilote Cococodji');
    expect(t).toContain(flat(pdfSafe(NOT_AUTHORIZED)));
    expect(t).toContain(flat(pdfSafe(DISCLAIMER)));
    expect(t).toMatch(/Acheteurs interrogés \(réponses valides\)\s+7\s+30/);
    expect(t).toMatch(/Intérêt déclaré \(« certainement » ou « probablement »\)\s+4\s+7\s+57 %/);
    expect(t).toMatch(/Volonté déclarée de payer.*\s6\s+7\s+86 %/);
    expect(t).toContain('du 02/11/2026 au 02/11/2026');
    expect(t).toMatch(/Y01\s+3\s+2 sur 3/);
    expect(t).toMatch(/Validée le \d{2}\/\d{2}\/\d{4}/);
    expect(t).toContain('Non validée');
    expect(t).toContain('Ce score est un outil de comparaison interne');
    expect(t).toContain('ne vaut pas autorisation');
  });

  it('les accents et guillemets français s\'affichent correctement (pas de caractères cassés)', () => {
    expect(text).toContain('Évaluation des emplacements candidats');
    expect(text).toContain('Commerçantes');
    expect(text).not.toMatch(/[�]|Ã©|â€/);
  });

  it('chaque page porte le pied de page « enquête exploratoire »', () => {
    const n = (text.match(/Enquête exploratoire - projet à l'étude, ni autorisé ni lancé/g) ?? []).length;
    expect(n).toBe(pages);
  });
});
