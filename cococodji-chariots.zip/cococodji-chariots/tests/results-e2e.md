# Résultats du test dans un navigateur (téléphone simulé)

Exécuté le 2026-10-28T21:24:35.553Z : Chromium 360×640, application compilée, **faux serveur Supabase**.

**55 réussis, 0 échecs, 55 au total.**

> Ce test ne remplace pas l'essai avec un vrai projet Supabase et de vrais téléphones (voir le guide).

## 1. Connexion et tableau de bord

- ✅ Petit écran 360 px : pas de défilement horizontal (connexion)
- ✅ Un mauvais mot de passe affiche un message clair en français
- ✅ Un compte non activé voit un écran d'attente (aucun accès aux données)
- ✅ L'enquêteur voit la mission, chargée depuis le serveur
- ✅ L'avertissement « projet à l'étude / non autorisé » est affiché
- ✅ État vide clair quand l'enquête n'a pas commencé
- ✅ Statut de mission affiché (« En cours »)
- ✅ Pastille de synchronisation : « Synchronisé »
- ✅ Petit écran 360 px : pas de défilement horizontal (tableau de bord)

## 2. Ouverture et saisie SANS réseau (scénario 7)

- ✅ Le service worker contrôle la page (mode hors ligne prêt)
- ✅ L'application se rouvre SANS réseau (page en cache, session conservée)
- ✅ Indicateur « Hors ligne » visible
- ✅ Hors ligne : « Fiche enregistrée sur ce téléphone »
- ✅ Hors ligne : état « En attente de synchronisation »
- ✅ Petit écran 360 px : pas de défilement horizontal (fin de saisie)
- ✅ La fiche est bien stockée dans le téléphone (IndexedDB) avec un identifiant unique
- ✅ Rien n'est arrivé sur le serveur tant que le téléphone est hors ligne
- ✅ Pastille : « Hors ligne · 1 en attente »

## 3. Retour du réseau : synchronisation automatique sans doublon

- ✅ Le réseau revient : la pastille passe d'elle-même à « Synchronisé »
- ✅ Le serveur a reçu exactement 1 fiche acheteur
- ✅ La fiche du serveur porte l'identifiant créé sur le téléphone
- ✅ Contenu exact reçu (consentement, fréquence, prix, enquêteur, zone)
- ✅ Aucun nom, téléphone ni donnée personnelle dans la fiche envoyée
- ✅ L'envoi utilise bien « ignorer les doublons sur l'identifiant »
- ✅ Localement, la fiche est passée à « Synchronisé »
- ✅ Le tableau de bord se met à jour : « 1 sur 30 » acheteurs (objectif 30)
- ✅ Progression des enquêteurs affichée

## 4. Réponse perdue : le serveur a reçu mais le téléphone ne le sait pas

- ✅ Le serveur a bien reçu l'observation (1 fiche)
- ✅ Mais le téléphone, sans confirmation, la garde « en attente » (rien d'effacé)
- ✅ Le renvoi n'a créé AUCUN doublon : toujours 1 seule observation sur le serveur
- ✅ Le serveur a bien reçu l'envoi 2 fois (preuve que le renvoi a eu lieu)
- ✅ Le téléphone affiche enfin « Synchronisé »
- ✅ Les nombres saisis arrivent exacts (120 personnes, 30 charges)

## 5. Refus du serveur : erreur visible puis « Réessayer »

- ✅ Refus de consentement : message « aucune réponse enregistrée »
- ✅ Pastille rouge : « Erreur de synchronisation (1) »
- ✅ Message d'erreur clair dans « Mes envois »
- ✅ Après « Réessayer » : le refus est compté une seule fois sur le serveur
- ✅ Le refus n'a créé AUCUNE réponse de questionnaire

## 6. Brouillons : sauvegarde automatique, reprise, suppression avec confirmation

- ✅ En quittant en plein remplissage, un brouillon est conservé sur le téléphone
- ✅ La reprise du brouillon retombe sur la bonne étape (2 sur 4)
- ✅ Les réponses déjà saisies sont conservées (« Souvent » coché)
- ✅ Champs obligatoires : message d'erreur et passage bloqué
- ✅ Suppression du brouillon : une confirmation est demandée
- ✅ Le brouillon est supprimé après confirmation

## 7. Un autre compte sur le même téléphone

- ✅ Awa ne voit pas les fiches de l'administrateur enregistrées sur ce même téléphone
- ✅ Awa voit pourtant les totaux d'équipe (compteurs seulement)

## 8. Petit écran de téléphone (scénario 10)

- ✅ Petit écran 360 px : pas de défilement horizontal (tableau de bord)
- ✅ Petit écran 360 px : pas de défilement horizontal (nouvelle réponse)
- ✅ Petit écran 360 px : pas de défilement horizontal (mes envois)
- ✅ Petit écran 360 px : pas de défilement horizontal (consentement)
- ✅ Petit écran 360 px : pas de défilement horizontal (étape 1)
- ✅ Petit écran 360 px : pas de défilement horizontal (étape 2)
- ✅ Boutons et champs suffisamment grands pour le soleil et une main (≥ 44 px)
- ✅ Texte de base lisible (≥ 18 px)

## 9. Santé du navigateur

- ✅ Aucune erreur JavaScript non gérée pendant tout le parcours

## Test « deux téléphones » (tests/e2e/two-phones.e2e.mjs) — 15/15
Serveur simulé type PostgREST branché sur le vrai schéma SQL (RLS réelle). Vérifie : saisie hors ligne sur A, arrivée sans doublon, enquêteur refusé sur l'administration, admin sur B voit la fiche, résultats avec bases de calcul, CSV/XLSX/PDF relus indépendamment, suppression des données d'essai tracée au journal. Non exécuté contre un vrai Supabase.
