// Test dans un vrai navigateur (Chromium, format téléphone) contre un FAUX serveur Supabase.
// Il vérifie : connexion, ouverture sans réseau, saisie hors ligne, synchronisation sans doublon,
// réponse perdue, refus du serveur, brouillons, refus de consentement, petit écran.
// Il ne prouve PAS le fonctionnement avec un vrai projet Supabase ni avec de vrais téléphones.
import { createRequire } from 'node:module';
import { spawn, spawnSync } from 'node:child_process';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { startMock } from './mock-supabase.mjs';

const require = createRequire(import.meta.url);
const { chromium } = require('playwright');
const here = path.dirname(fileURLToPath(import.meta.url));
const root = path.resolve(here, '../..');
const SHOTS = path.resolve(here, '../screenshots');
fs.mkdirSync(SHOTS, { recursive: true });

const APP_PORT = 3100;
const MOCK_PORT = 54321;
const APP = `http://localhost:${APP_PORT}`;

const results = [];
let section = '';
const sec = (s) => { section = s; console.log(`\n## ${s}`); };
function check(name, ok, detail = '') {
  results.push({ section, name, ok: !!ok, detail });
  console.log(`${ok ? 'OK  ' : 'ÉCHEC'}  ${name}${ok ? '' : '  -> ' + detail}`);
}
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

// ------------------------------------------------------------------ build + serveurs
if (process.env.SKIP_BUILD !== '1') {
  console.log('Compilation de l\'application (variables pointant vers le faux serveur)…');
  const b = spawnSync('npx', ['next', 'build'], {
    cwd: root, encoding: 'utf8',
    env: { ...process.env, NEXT_PUBLIC_SUPABASE_URL: `http://localhost:${MOCK_PORT}`, NEXT_PUBLIC_SUPABASE_ANON_KEY: 'test-anon-key', NEXT_TELEMETRY_DISABLED: '1' },
  });
  if (b.status !== 0) { console.error(b.stdout, b.stderr); process.exit(2); }
}
// Refuse de démarrer si un ancien serveur occupe encore le port (il servirait une ancienne version)
try { await fetch(APP); console.error(`Le port ${APP_PORT} est déjà utilisé : arrêtez l'ancien serveur avant de relancer.`); process.exit(3); } catch {}
const mock = await startMock(MOCK_PORT);
// groupe de processus à part : on peut tout arrêter proprement à la fin
const next = spawn(process.execPath, [path.join(root, 'node_modules/next/dist/bin/next'), 'start', '-p', String(APP_PORT)], {
  cwd: root, stdio: 'ignore', detached: true, env: { ...process.env, NEXT_TELEMETRY_DISABLED: '1' },
});
const stopNext = () => { try { process.kill(-next.pid, 'SIGTERM'); } catch {} };
process.on('exit', stopNext);
for (let i = 0; i < 60; i++) {
  try { if ((await fetch(APP)).ok) break; } catch {}
  await sleep(500);
}

const admin = (p, body) => fetch(`http://localhost:${MOCK_PORT}/__admin/${p}`, body ? { method: 'POST', body: JSON.stringify(body) } : {}).then((r) => r.json());
const serverState = () => admin('state');

const browser = await chromium.launch();
const context = await browser.newContext({
  viewport: { width: 360, height: 640 }, locale: 'fr-FR', timezoneId: 'Africa/Porto-Novo',
  deviceScaleFactor: 2, isMobile: true, hasTouch: true,
});
const page = await context.newPage();
const pageErrors = [];
page.on('pageerror', (e) => pageErrors.push(e.message));

// ------------------------------------------------------------------ aides
const btn = (name) => page.getByRole('button', { name, exact: true });
const text = (t) => page.getByText(t, { exact: false }).first();
const pill = () => page.getByTestId('netpill');
async function waitText(t, timeout = 15000) { await page.getByText(t, { exact: false }).first().waitFor({ timeout }); }
async function noHorizontalScroll(label) {
  const ok = await page.evaluate(() => document.documentElement.scrollWidth <= window.innerWidth + 1);
  check(`Petit écran 360 px : pas de défilement horizontal (${label})`, ok);
}
async function shot(name) { await page.screenshot({ path: path.join(SHOTS, `${name}.png`) }); }
async function idbRecords() {
  return page.evaluate(() => new Promise((resolve, reject) => {
    const open = indexedDB.open('cococodji-chariots');
    open.onerror = () => reject(open.error);
    open.onsuccess = () => {
      const tx = open.result.transaction('records', 'readonly');
      const all = tx.objectStore('records').getAll();
      all.onsuccess = () => resolve(all.result);
    };
  }));
}
async function login(email, password = 'motdepasse1') {
  await page.locator('#email').fill(email);
  await page.locator('#password').fill(password);
  await btn('Se connecter').click();
}
async function selectZone(code) {
  const sel = page.locator('select[id^="f-"]').first();
  const opt = await sel.locator('option', { hasText: code }).first().getAttribute('value');
  await sel.selectOption(opt);
}
const next_ = () => btn('Suivant').click();
const radio = (label) => page.getByLabel(label, { exact: true }).check();
const radioIn = (group, label) => page.getByRole('group', { name: group }).getByLabel(label, { exact: true }).check();

async function fillBuyerAndSubmit(zoneCode = 'Z01') {
  await page.getByRole('button', { name: 'Questionnaire acheteur ou acheteuse' }).click();
  await btn('Oui, accepte de répondre').click();
  await selectZone(zoneCode); await next_();
  await radio('Oui'); await radio('Souvent'); await radio('Charges lourdes'); await radio('À la main'); await radio('2'); await next_();
  await radio('Probablement'); await radio('Des étals à la sortie'); await radio('Après les achats'); await next_();
  await radio('Prix fixe par utilisation'); await radio('200 FCFA'); await radio('Non'); await next_();
  await radio('Prix');
  await btn('Récapitulatif').click();
  await btn('Enregistrer et envoyer').click();
}
async function fillObservationAndSubmit(zoneCode = 'Z01', start = '09:00', end = '09:15') {
  await page.getByRole('button', { name: 'Observation des flux (15 minutes)' }).click();
  await selectZone(zoneCode);
  await page.locator('#f-start_time').fill(start);
  await page.locator('#f-end_time').fill(end);
  await page.locator('#f-observed_on').fill('2026-11-02');
  await next_();
  await page.locator('#f-people_count').fill('120');
  await page.locator('#f-heavy_load_count').fill('30');
  await next_();
  await radioIn('Niveau de flux piéton', 'Fort'); await radio('Marches'); await radio('Difficile'); await radioIn('Risque potentiel d’encombrement', 'Moyen'); await next_();
  await btn('Récapitulatif').click();
  await btn('Enregistrer et envoyer').click();
}
const goNew = () => page.getByRole('button', { name: /Nouvelle réponse/ }).last().click();
const goHome = () => page.getByRole('button', { name: /Tableau de bord/ }).click();
const goOutbox = () => page.getByRole('button', { name: /Mes envois/ }).click();

try {
  // ================================================================== 1. Connexion
  sec('1. Connexion et tableau de bord');
  await page.goto(APP);
  await waitText('Connexion');
  await noHorizontalScroll('connexion');
  await shot('01-connexion');
  await login('admin@test.bj', 'mauvais');
  await waitText('E-mail ou mot de passe incorrect');
  check('Un mauvais mot de passe affiche un message clair en français', true);

  await login('inactif@test.bj');
  await waitText('Compte en attente d’activation');
  check('Un compte non activé voit un écran d\'attente (aucun accès aux données)', true);
  await btn('Se déconnecter').click();
  await waitText('Connexion');

  await login('admin@test.bj');
  await waitText('Mission pilote Cococodji');
  check('L\'enquêteur voit la mission, chargée depuis le serveur', true);
  check('L\'avertissement « projet à l\'étude / non autorisé » est affiché', await text('Le service de chariots n’est ni autorisé ni lancé').isVisible());
  check('État vide clair quand l\'enquête n\'a pas commencé', await text('L’enquête n’a pas encore commencé').isVisible());
  check('Statut de mission affiché (« En cours »)', await text('En cours').isVisible());
  check('Pastille de synchronisation : « Synchronisé »', (await pill().innerText()).includes('Synchronisé'));
  await noHorizontalScroll('tableau de bord');
  await shot('02-tableau-de-bord');

  // ================================================================== 2. Hors ligne
  sec('2. Ouverture et saisie SANS réseau (scénario 7)');
  await page.evaluate(() => navigator.serviceWorker.ready);
  await page.reload();
  await page.waitForFunction(() => navigator.serviceWorker.controller !== null, null, { timeout: 15000 });
  check('Le service worker contrôle la page (mode hors ligne prêt)', true);
  await waitText('Mission pilote Cococodji');

  await context.setOffline(true);
  await page.reload();
  await waitText('Mission pilote Cococodji', 20000);
  check('L\'application se rouvre SANS réseau (page en cache, session conservée)', true);
  await page.waitForFunction(() => document.querySelector('[data-testid="netpill"]')?.textContent?.includes('Hors ligne'));
  check('Indicateur « Hors ligne » visible', true);
  await shot('03-hors-ligne');

  await goNew();
  await fillBuyerAndSubmit('Z01');
  await waitText('Fiche enregistrée sur ce téléphone');
  check('Hors ligne : « Fiche enregistrée sur ce téléphone »', true);
  await waitText('En attente de synchronisation');
  check('Hors ligne : état « En attente de synchronisation »', true);
  await noHorizontalScroll('fin de saisie');
  await shot('04-enregistre-hors-ligne');
  let recs = await idbRecords();
  const pendingBuyer = recs.find((r) => r.kind === 'acheteur');
  check('La fiche est bien stockée dans le téléphone (IndexedDB) avec un identifiant unique', pendingBuyer?.state === 'PENDING' && /^[0-9a-f-]{36}$/.test(pendingBuyer.id), JSON.stringify(pendingBuyer?.state));
  let st = await serverState();
  check('Rien n\'est arrivé sur le serveur tant que le téléphone est hors ligne', st.rows.buyer_responses.length === 0);
  check('Pastille : « Hors ligne · 1 en attente »', (await pill().innerText()).includes('1 en attente'));

  // ================================================================== 3. Retour du réseau
  sec('3. Retour du réseau : synchronisation automatique sans doublon');
  await context.setOffline(false);
  await page.waitForFunction(() => document.querySelector('[data-testid="netpill"]')?.textContent?.trim() === 'Synchronisé', null, { timeout: 30000 });
  check('Le réseau revient : la pastille passe d\'elle-même à « Synchronisé »', true);
  st = await serverState();
  check('Le serveur a reçu exactement 1 fiche acheteur', st.rows.buyer_responses.length === 1, String(st.rows.buyer_responses.length));
  const srvBuyer = st.rows.buyer_responses[0];
  check('La fiche du serveur porte l\'identifiant créé sur le téléphone', srvBuyer?.id === pendingBuyer.id);
  check('Contenu exact reçu (consentement, fréquence, prix, enquêteur, zone)',
    srvBuyer?.consent === true && srvBuyer.q2_frequence === 'SOUVENT' && srvBuyer.q10_prix === '200' && srvBuyer.q5_nb_trajets === '2'
    && srvBuyer.surveyor_id === st.ids.admin && srvBuyer.zone_id === st.ids.z1 && srvBuyer.status === 'SOUMIS' && srvBuyer.mission_id === st.ids.mission);
  check('Aucun nom, téléphone ni donnée personnelle dans la fiche envoyée',
    !Object.keys(srvBuyer).some((k) => /nom$|name|phone|tel|email|photo/i.test(k)));
  check('L\'envoi utilise bien « ignorer les doublons sur l\'identifiant »', st.log.every((l) => l.ignoreDup));
  recs = await idbRecords();
  check('Localement, la fiche est passée à « Synchronisé »', recs.find((r) => r.id === pendingBuyer.id)?.state === 'SYNCED');
  await goHome();
  await waitText('1 sur 30');
  check('Le tableau de bord se met à jour : « 1 sur 30 » acheteurs (objectif 30)', true);
  check('Progression des enquêteurs affichée', await text('1 acheteur').isVisible());
  await shot('05-tableau-apres-sync');

  // ================================================================== 4. Réponse perdue
  sec('4. Réponse perdue : le serveur a reçu mais le téléphone ne le sait pas');
  // Le serveur reçoit et enregistre la fiche, mais la réponse n'arrive jamais au téléphone (coupure réseau)
  let loseNext = true;
  await context.route('**/rest/v1/observation_sessions*', async (route) => {
    if (route.request().method() === 'POST' && loseNext) {
      loseNext = false;
      await route.fetch();
      await route.abort('connectionreset');
    } else {
      await route.continue();
    }
  });
  await goNew();
  await fillObservationAndSubmit('Z02', '10:00', '10:15');
  await waitText('Fiche enregistrée sur ce téléphone');
  await page.waitForFunction(async () => {
    const o = await new Promise((res) => { const q = indexedDB.open('cococodji-chariots'); q.onsuccess = () => { const a = q.result.transaction('records').objectStore('records').getAll(); a.onsuccess = () => res(a.result); }; });
    return o.some((r) => r.kind === 'observation' && r.attempts >= 1);
  }, null, { timeout: 15000 });
  st = await serverState();
  check('Le serveur a bien reçu l\'observation (1 fiche)', st.rows.observation_sessions.length === 1);
  recs = await idbRecords();
  check('Mais le téléphone, sans confirmation, la garde « en attente » (rien d\'effacé)', recs.find((r) => r.kind === 'observation')?.state === 'PENDING');
  await goOutbox();
  await btn('Synchroniser maintenant').click().catch(() => {});
  await page.waitForFunction(() => document.querySelector('[data-testid="netpill"]')?.textContent?.trim() === 'Synchronisé', null, { timeout: 40000 });
  st = await serverState();
  check('Le renvoi n\'a créé AUCUN doublon : toujours 1 seule observation sur le serveur', st.rows.observation_sessions.length === 1, String(st.rows.observation_sessions.length));
  check('Le serveur a bien reçu l\'envoi 2 fois (preuve que le renvoi a eu lieu)', st.log.filter((l) => l.table === 'observation_sessions').length >= 2);
  recs = await idbRecords();
  check('Le téléphone affiche enfin « Synchronisé »', recs.find((r) => r.kind === 'observation')?.state === 'SYNCED');
  check('Les nombres saisis arrivent exacts (120 personnes, 30 charges)', st.rows.observation_sessions[0].people_count === 120 && st.rows.observation_sessions[0].heavy_load_count === 30);

  // ================================================================== 5. Refus du serveur
  sec('5. Refus du serveur : erreur visible puis « Réessayer »');
  await admin('mode', { kind: 'reject', count: 1 });
  await goNew();
  await page.getByRole('button', { name: 'Questionnaire acheteur ou acheteuse' }).click();
  await btn('Non, refuse de répondre').click();
  await waitText('Aucune réponse n’est enregistrée');
  check('Refus de consentement : message « aucune réponse enregistrée »', true);
  await btn('Compter ce refus').click();
  await waitText('Refus compté (anonyme)');
  await page.waitForFunction(() => document.querySelector('[data-testid="netpill"]')?.textContent?.includes('Erreur de synchronisation'), null, { timeout: 15000 });
  check('Pastille rouge : « Erreur de synchronisation (1) »', true);
  await goOutbox();
  await waitText('Le serveur a refusé la fiche');
  check('Message d\'erreur clair dans « Mes envois »', true);
  await shot('06-erreur-synchro');
  await btn('Réessayer').click();
  await page.waitForFunction(() => document.querySelector('[data-testid="netpill"]')?.textContent?.trim() === 'Synchronisé', null, { timeout: 20000 });
  st = await serverState();
  check('Après « Réessayer » : le refus est compté une seule fois sur le serveur', st.rows.refusals.length === 1);
  check('Le refus n\'a créé AUCUNE réponse de questionnaire', st.rows.buyer_responses.length === 1);

  // ================================================================== 6. Brouillons
  sec('6. Brouillons : sauvegarde automatique, reprise, suppression avec confirmation');
  await goNew();
  await page.getByRole('button', { name: 'Questionnaire vendeuse ou commerçante' }).click();
  await btn('Oui, accepte de répondre').click();
  await selectZone('Z02'); await next_();
  await radio('Souvent');
  await sleep(700); // laisse la sauvegarde automatique s'exécuter
  await goHome(); // on quitte en plein remplissage
  recs = await idbRecords();
  const draft = recs.find((r) => r.kind === 'commercante');
  check('En quittant en plein remplissage, un brouillon est conservé sur le téléphone', draft?.state === 'LOCAL' && draft.draft.answers.q1_difficultes_clients === 'SOUVENT');
  await waitText('1');
  await goNew();
  await waitText('Brouillons à reprendre');
  await page.getByRole('button', { name: /Commerçante · zone Z02/ }).click();
  await waitText('Étape 2 sur 4');
  check('La reprise du brouillon retombe sur la bonne étape (2 sur 4)', true);
  check('Les réponses déjà saisies sont conservées (« Souvent » coché)', await page.getByLabel('Souvent', { exact: true }).isChecked());
  // validation des champs obligatoires
  await next_();
  await waitText('Cette réponse est obligatoire');
  check('Champs obligatoires : message d\'erreur et passage bloqué', true);
  await goOutbox();
  await page.getByRole('button', { name: 'Supprimer le brouillon' }).click();
  check('Suppression du brouillon : une confirmation est demandée', await btn('Oui, supprimer').isVisible());
  await btn('Oui, supprimer').click();
  await sleep(400);
  recs = await idbRecords();
  check('Le brouillon est supprimé après confirmation', !recs.some((r) => r.kind === 'commercante'));

  // ================================================================== 7. Comptes
  sec('7. Un autre compte sur le même téléphone');
  await page.getByRole('button', { name: 'Se déconnecter' }).click();
  await waitText('Connexion');
  await login('awa@test.bj');
  await waitText('Mission pilote Cococodji');
  await goOutbox();
  await waitText('Aucune fiche sur ce téléphone');
  check('Awa ne voit pas les fiches de l\'administrateur enregistrées sur ce même téléphone', true);
  await goHome();
  await waitText('1 sur 30');
  check('Awa voit pourtant les totaux d\'équipe (compteurs seulement)', true);

  // ================================================================== 8. Petit écran
  sec('8. Petit écran de téléphone (scénario 10)');
  for (const [label, action] of [
    ['tableau de bord', goHome],
    ['nouvelle réponse', goNew],
    ['mes envois', goOutbox],
  ]) { await action(); await sleep(250); await noHorizontalScroll(label); }
  await goNew();
  await page.getByRole('button', { name: 'Questionnaire acheteur ou acheteuse' }).click();
  await noHorizontalScroll('consentement');
  await shot('07-consentement');
  await btn('Oui, accepte de répondre').click();
  await noHorizontalScroll('étape 1');
  await selectZone('Z01'); await next_();
  await noHorizontalScroll('étape 2');
  await shot('08-formulaire-etape-2');
  const tooSmall = await page.evaluate(() => [...document.querySelectorAll('.choice, .btn, .input')].filter((el) => el.getBoundingClientRect().height < 44).length);
  check('Boutons et champs suffisamment grands pour le soleil et une main (≥ 44 px)', tooSmall === 0, `${tooSmall} éléments trop petits`);
  const fs18 = await page.evaluate(() => parseFloat(getComputedStyle(document.body).fontSize));
  check('Texte de base lisible (≥ 18 px)', fs18 >= 18, String(fs18));
  await page.goto(APP + '/#/'); // sort proprement

  // ================================================================== 9. Erreurs navigateur
  sec('9. Santé du navigateur');
  check('Aucune erreur JavaScript non gérée pendant tout le parcours', pageErrors.length === 0, pageErrors.join(' | '));
} catch (e) {
  check('Déroulement du test sans exception', false, e.message.split('\n')[0]);
  try { await shot('zz-echec'); } catch {}
  console.error(e);
}

await browser.close();
stopNext();
await mock.close();

const failed = results.filter((r) => !r.ok);
console.log(`\n=== ${results.length - failed.length} réussis / ${failed.length} échecs sur ${results.length} vérifications ===`);
let md = `# Résultats du test dans un navigateur (téléphone simulé)\n\nExécuté le ${new Date().toISOString()} : Chromium 360×640, application compilée, **faux serveur Supabase**.\n\n`;
md += `**${results.length - failed.length} réussis, ${failed.length} échecs, ${results.length} au total.**\n\n`;
md += `> Ce test ne remplace pas l'essai avec un vrai projet Supabase et de vrais téléphones (voir le guide).\n`;
let cur = '';
for (const r of results) {
  if (r.section !== cur) { cur = r.section; md += `\n## ${cur}\n\n`; }
  md += `- ${r.ok ? '✅' : '❌'} ${r.name}${r.ok ? '' : ` — ${r.detail}`}\n`;
}
fs.writeFileSync(path.resolve(here, '../results-e2e.md'), md);
process.exit(failed.length ? 1 : 0);
