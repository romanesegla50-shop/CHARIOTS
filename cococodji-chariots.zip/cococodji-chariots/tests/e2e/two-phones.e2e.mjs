// Test « deux téléphones » : un enquêteur saisit (hors ligne puis en ligne), l'administrateur lit sur un autre appareil.
// Le serveur est un traducteur PostgREST simulé branché sur le VRAI schéma SQL (règles d'accès incluses). Ce n'est pas Supabase.
import { createRequire } from 'node:module';
import { spawn, spawnSync } from 'node:child_process';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { startShim } from './pg-rest-shim.mjs';

const require = createRequire(import.meta.url);
const { chromium } = require('playwright');
const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '../..');
const OUT = path.resolve(root, 'tests/screenshots'); fs.mkdirSync(OUT, { recursive: true });
const APP_PORT = 3100, API_PORT = 54321, APP = `http://localhost:${APP_PORT}`;
const results = [];
const check = (name, ok, d = '') => { results.push({ name, ok: !!ok }); console.log(`${ok ? 'OK  ' : 'ÉCHEC'}  ${name}${ok ? '' : '  -> ' + d}`); };
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

if (process.env.SKIP_BUILD !== '1') {
  const b = spawnSync('npx', ['next', 'build'], { cwd: root, encoding: 'utf8', env: { ...process.env, NEXT_PUBLIC_SUPABASE_URL: `http://localhost:${API_PORT}`, NEXT_PUBLIC_SUPABASE_ANON_KEY: 'test-anon-key', NEXT_TELEMETRY_DISABLED: '1' } });
  if (b.status !== 0) { console.error(b.stdout, b.stderr); process.exit(2); }
}
try { await fetch(APP); console.error('port occupé'); process.exit(3); } catch {}
const api = await startShim(API_PORT);
const ADMIN = await api.addUser('admin@test.bj', 'Yobiyo', 'motdepasse1', { role: 'ADMINISTRATEUR' });
const AWA = await api.addUser('awa@test.bj', 'Awa', 'motdepasse1');
const [{ id: MID }] = await api.sql(`insert into public.missions (name,status,start_date,end_date,target_buyers,target_vendors,target_observations,created_by) values ('Mission pilote Cococodji','EN_COURS','2026-11-02','2026-11-08',30,15,6,$1) returning id`, [ADMIN]);
for (const c of ['Z01', 'Z02']) await api.sql(`insert into public.zones (mission_id, code, label) values ($1,$2,$3)`, [MID, c, c === 'Z01' ? 'Entrée nord' : 'Allée centrale']);

const next = spawn(process.execPath, [path.join(root, 'node_modules/next/dist/bin/next'), 'start', '-p', String(APP_PORT)], { cwd: root, stdio: 'ignore', detached: true });
const stopNext = () => { try { process.kill(-next.pid, 'SIGTERM'); } catch {} };
process.on('exit', stopNext);
for (let i = 0; i < 60; i++) { try { if ((await fetch(APP)).ok) break; } catch {} await sleep(500); }

const browser = await chromium.launch();
const mk = async (vp) => { const c = await browser.newContext({ viewport: vp, locale: 'fr-FR', timezoneId: 'Africa/Porto-Novo', acceptDownloads: true }); const p = await c.newPage(); p.errs = []; p.on('pageerror', (e) => p.errs.push(e.message)); return [c, p]; };
const [ctxA, A] = await mk({ width: 360, height: 640 });
const [ctxB, B] = await mk({ width: 390, height: 800 });
const login = async (p, email) => { await p.goto(APP); await p.locator('#email').fill(email); await p.locator('#password').fill('motdepasse1'); await p.getByRole('button', { name: 'Se connecter', exact: true }).click(); await p.getByText('Mission pilote Cococodji').first().waitFor({ timeout: 20000 }); };
const btn = (p, n) => p.getByRole('button', { name: n, exact: true });
const radio = (p, l) => p.getByLabel(l, { exact: true }).check();
async function buyer(p, zone) {
  await p.getByRole('button', { name: /Nouvelle réponse/ }).last().click();
  await p.getByRole('button', { name: 'Questionnaire acheteur ou acheteuse' }).click();
  await btn(p, 'Oui, accepte de répondre').click();
  const sel = p.locator('select[id^="f-"]').first();
  await sel.selectOption(await sel.locator('option', { hasText: zone }).first().getAttribute('value'));
  await btn(p, 'Suivant').click();
  await radio(p, 'Oui'); await radio(p, 'Souvent'); await radio(p, 'Charges lourdes'); await radio(p, 'À la main'); await radio(p, '2'); await btn(p, 'Suivant').click();
  await radio(p, 'Probablement'); await radio(p, 'Des étals à la sortie'); await radio(p, 'Après les achats'); await btn(p, 'Suivant').click();
  await radio(p, 'Prix fixe par utilisation'); await radio(p, '200 FCFA'); await radio(p, 'Non'); await btn(p, 'Suivant').click();
  await radio(p, 'Prix');
  await btn(p, 'Récapitulatif').click(); await btn(p, 'Enregistrer et envoyer').click();
}
const goPlus = (p) => p.getByRole('button', { name: /Plus/ }).last().click();
try {
  // Téléphone A (Awa) : saisie hors ligne puis retour du réseau
  await login(A, 'awa@test.bj');
  await A.evaluate(() => navigator.serviceWorker.ready);
  await ctxA.setOffline(true);
  await buyer(A, 'Z01');
  await A.getByText('En attente de synchronisation').first().waitFor();
  check('A (hors ligne) : fiche en attente sur le téléphone', true);
  check('Base : rien reçu tant que A est hors ligne', (await api.sql(`select count(*)::int n from public.buyer_responses`))[0].n === 0);
  await ctxA.setOffline(false);
  await A.waitForFunction(() => document.querySelector('[data-testid="netpill"]')?.textContent?.trim() === 'Synchronisé', null, { timeout: 30000 });
  const rows = await api.sql(`select surveyor_id, status, q10_prix, consent from public.buyer_responses`);
  check('Base : exactement 1 fiche, au nom d\'Awa, soumise, consentement oui', rows.length === 1 && rows[0].surveyor_id === AWA && rows[0].status === 'SOUMIS' && rows[0].consent === true, JSON.stringify(rows));
  // Awa n'a pas accès à l'administration
  await goPlus(A);
  check('A (enquêteur) : pas de menu Administration', (await A.getByText('Administration').count()) === 0);
  await A.goto(APP + '/#/admin/resultats'); await A.reload();
  await A.getByText('réservé à l’administrateur').first().waitFor({ timeout: 15000 });
  check('A (enquêteur) : l\'écran Résultats est refusé', true);

  // Téléphone B (admin) : voit la fiche d'Awa
  await login(B, 'admin@test.bj');
  await goPlus(B);
  await B.getByText('Administration').first().waitFor();
  await B.goto(APP + '/#/admin/reponses'); await B.reload();
  await B.getByTestId('response-row').first().waitFor({ timeout: 20000 });
  check('B (admin) : voit la fiche saisie par Awa sur un autre appareil', (await B.getByTestId('response-row').count()) === 1 && (await B.getByTestId('response-row').first().innerText()).includes('Awa'));
  await B.screenshot({ path: path.join(OUT, '10-admin-reponses.png') });

  await B.goto(APP + '/#/admin/resultats'); await B.reload();
  await B.getByTestId('n-buyers').waitFor({ timeout: 20000 });
  check('B : Résultats — 1 acheteur', (await B.getByTestId('n-buyers').innerText()) === '1');
  const kpis = await B.getByTestId('kpi').allInnerTexts();
  check('B : indicateurs avec base de calcul (« sur 1 »)', kpis.length === 4 && kpis.every((k) => /sur 1 /.test(k)), kpis.join(' | '));
  check('B : avertissement obligatoire présent', (await B.getByTestId('disclaimer').innerText()).includes('exploratoire'));
  await B.screenshot({ path: path.join(OUT, '11-admin-resultats.png'), fullPage: true });

  // Exports
  await B.goto(APP + '/#/admin/export'); await B.reload();
  await B.getByTestId('csv-buyers').waitFor({ timeout: 20000 });
  const dl = async (id) => { const [d] = await Promise.all([B.waitForEvent('download', { timeout: 30000 }), B.getByTestId(id).click()]); const f = path.join(OUT, d.suggestedFilename()); await d.saveAs(f); return f; };
  const csv = fs.readFileSync(await dl('csv-buyers'), 'utf8');
  check('CSV acheteurs : BOM, séparateur « ; », 1 ligne de données', csv.charCodeAt(0) === 0xFEFF && csv.includes(';') && csv.trim().split(/\r\n/).length === 2, csv.slice(0, 200));
  const xl = await dl('xlsx');
  const py = spawnSync('python3', ['-I', '-c', 'import openpyxl,sys;wb=openpyxl.load_workbook(sys.argv[1]);print("|".join(wb.sheetnames))', xl], { encoding: 'utf8' });
  check('XLSX : feuilles Synthèse + questionnaires', /Synth/.test(py.stdout) && /Acheteurs/.test(py.stdout), py.stdout + py.stderr);
  const pdf = await dl('pdf');
  const txt = spawnSync('pdftotext', [pdf, '-'], { encoding: 'utf8' }).stdout;
  check('PDF : contient l\'avertissement et le chiffre 1', txt.includes('enquête exploratoire') && /1/.test(txt));

  // Nettoyage des données de test par l'administrateur
  await B.goto(APP + '/#/admin/reponses'); await B.reload();
  await B.getByTestId('response-row').first().waitFor({ timeout: 20000 });
  await B.getByRole('button', { name: 'Supprimer', exact: true }).click();
  await B.getByRole('button', { name: 'Oui, supprimer définitivement' }).click();
  await B.getByText('Aucune fiche de ce type').waitFor({ timeout: 15000 });
  check('B : suppression des données de test → base vide', (await api.sql(`select count(*)::int n from public.buyer_responses`))[0].n === 0);
  check('Journal : la suppression est tracée', (await api.sql(`select count(*)::int n from public.audit_log where action='DELETE'`))[0].n >= 1);
  check('Aucune erreur JavaScript (A et B)', A.errs.length + B.errs.length === 0, [...A.errs, ...B.errs].join(' / '));
} catch (e) { check('Exception du test : ' + e.message.split('\n')[0], false); await B.screenshot({ path: path.join(OUT, 'echec-B.png') }).catch(() => {}); await A.screenshot({ path: path.join(OUT, 'echec-A.png') }).catch(() => {}); }
await browser.close(); stopNext(); await api.close();
const ko = results.filter((r) => !r.ok).length;
console.log(`\n=== ${results.length - ko} réussis / ${ko} échecs sur ${results.length} ===`);
process.exit(ko ? 1 : 0);
