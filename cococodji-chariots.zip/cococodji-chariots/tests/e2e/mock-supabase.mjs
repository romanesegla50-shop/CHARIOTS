// Faux serveur Supabase pour tester l'application dans un vrai navigateur.
// Il imite : connexion, lecture (profil, mission, zones, statistiques) et envoi « upsert ... ignore-duplicates ».
// ATTENTION : ce n'est PAS un vrai Supabase. Les règles d'accès réelles sont testées par tests/db.test.mjs.
import http from 'node:http';
import { randomUUID } from 'node:crypto';

const b64 = (o) => Buffer.from(JSON.stringify(o)).toString('base64url');
const jwt = (sub, email) =>
  `${b64({ alg: 'HS256', typ: 'JWT' })}.${b64({ sub, email, role: 'authenticated', aud: 'authenticated', exp: Math.floor(Date.now() / 1000) + 3600 })}.sig`;

export function startMock(port) {
  const ids = { admin: randomUUID(), awa: randomUUID(), inactif: randomUUID(), mission: randomUUID(), z1: randomUUID(), z2: randomUUID() };
  const users = {
    'admin@test.bj': { id: ids.admin, password: 'motdepasse1', profile: { id: ids.admin, email: 'admin@test.bj', full_name: 'Yobiyo', role: 'ADMINISTRATEUR', active: true } },
    'awa@test.bj': { id: ids.awa, password: 'motdepasse1', profile: { id: ids.awa, email: 'awa@test.bj', full_name: 'Awa', role: 'ENQUETEUR', active: true } },
    'inactif@test.bj': { id: ids.inactif, password: 'motdepasse1', profile: { id: ids.inactif, email: 'inactif@test.bj', full_name: 'Inactif', role: 'ENQUETEUR', active: false } },
  };
  const mission = {
    id: ids.mission, name: 'Mission pilote Cococodji', status: 'EN_COURS', start_date: '2026-11-02', end_date: '2026-11-08',
    instructions: 'Interroger sans insister.\nNe noter aucune donnée personnelle.', target_buyers: 30, target_vendors: 15, target_observations: 6,
    created_at: '2026-10-26T08:00:00Z',
  };
  const zones = [
    { id: ids.z1, code: 'Z01', label: 'Entrée nord', description: null, sector: null, is_candidate: false, approval_status: 'NON_VALIDE' },
    { id: ids.z2, code: 'Z02', label: 'Allée centrale', description: null, sector: null, is_candidate: false, approval_status: 'NON_VALIDE' },
  ];
  const tables = { buyer_responses: new Map(), vendor_responses: new Map(), observation_sessions: new Map(), refusals: new Map() };
  const log = []; // chaque envoi reçu
  const mode = { kind: null, count: 0 }; // pannes simulées

  const cors = (req, res) => {
    res.setHeader('Access-Control-Allow-Origin', '*');
    res.setHeader('Access-Control-Allow-Headers', req.headers['access-control-request-headers'] || '*');
    res.setHeader('Access-Control-Allow-Methods', 'GET,POST,PATCH,DELETE,OPTIONS');
    res.setHeader('Access-Control-Expose-Headers', '*');
  };
  const json = (req, res, status, body) => {
    cors(req, res);
    res.statusCode = status;
    res.setHeader('Content-Type', 'application/json');
    res.end(body === undefined ? '' : JSON.stringify(body));
  };
  const readBody = (req) => new Promise((resolve) => {
    let d = '';
    req.on('data', (c) => (d += c));
    req.on('end', () => { try { resolve(d ? JSON.parse(d) : {}); } catch { resolve({}); } });
  });
  const session = (email) => {
    const u = users[email];
    return {
      access_token: jwt(u.id, email), token_type: 'bearer', expires_in: 3600, expires_at: Math.floor(Date.now() / 1000) + 3600,
      refresh_token: 'rt-' + u.id,
      user: { id: u.id, aud: 'authenticated', role: 'authenticated', email, app_metadata: {}, user_metadata: {}, created_at: '2026-10-01T00:00:00Z' },
    };
  };
  const subOf = (req) => {
    try { return JSON.parse(Buffer.from((req.headers.authorization || '').replace('Bearer ', '').split('.')[1], 'base64url').toString()).sub; } catch { return null; }
  };
  const submitted = (m) => [...m.values()].filter((r) => r.status === 'SOUMIS');

  const server = http.createServer(async (req, res) => {
    const url = new URL(req.url, `http://localhost:${port}`);
    const p = url.pathname;
    if (req.method === 'OPTIONS') { cors(req, res); res.statusCode = 204; return res.end(); }

    // ---- outils de test
    if (p === '/__admin/state') {
      return json(req, res, 200, { rows: Object.fromEntries(Object.entries(tables).map(([k, m]) => [k, [...m.values()]])), log, ids });
    }
    if (p === '/__admin/mode') {
      const b = await readBody(req); mode.kind = b.kind; mode.count = b.count ?? 1; return json(req, res, 200, mode);
    }
    if (p === '/__admin/reset') { Object.values(tables).forEach((m) => m.clear()); log.length = 0; return json(req, res, 200, {}); }

    // ---- authentification
    if (p === '/auth/v1/token') {
      const b = await readBody(req);
      if (url.searchParams.get('grant_type') === 'refresh_token') {
        const u = Object.entries(users).find(([, v]) => 'rt-' + v.id === b.refresh_token);
        return u ? json(req, res, 200, session(u[0])) : json(req, res, 400, { error: 'invalid_grant' });
      }
      const u = users[(b.email || '').toLowerCase()];
      if (!u || u.password !== b.password) return json(req, res, 400, { error: 'invalid_grant', error_description: 'Invalid login credentials', code: 400, msg: 'Invalid login credentials' });
      return json(req, res, 200, session(b.email.toLowerCase()));
    }
    if (p === '/auth/v1/logout') return json(req, res, 204);
    if (p === '/auth/v1/user') {
      const sub = subOf(req); const e = Object.entries(users).find(([, v]) => v.id === sub);
      return e ? json(req, res, 200, session(e[0]).user) : json(req, res, 401, { message: 'invalid JWT' });
    }

    // ---- lecture
    const wantsObject = /pgrst\.object/.test(req.headers.accept || '');
    if (req.method === 'GET' && p === '/rest/v1/profiles') {
      const id = (url.searchParams.get('id') || '').replace('eq.', '');
      const u = Object.values(users).find((x) => x.id === id);
      return u ? json(req, res, 200, wantsObject ? u.profile : [u.profile]) : json(req, res, wantsObject ? 406 : 200, wantsObject ? { code: 'PGRST116', message: 'no rows' } : []);
    }
    if (req.method === 'GET' && p === '/rest/v1/missions') return json(req, res, 200, [mission]);
    if (req.method === 'GET' && p === '/rest/v1/zones') return json(req, res, 200, zones);
    if (p === '/rest/v1/rpc/mission_overview') {
      const t = tables;
      return json(req, res, 200, {
        buyers: submitted(t.buyer_responses).length, vendors: submitted(t.vendor_responses).length,
        observations: submitted(t.observation_sessions).length,
        zones_observed: new Set(submitted(t.observation_sessions).map((r) => r.zone_id)).size,
        refusals: t.refusals.size, target_buyers: 30, target_vendors: 15, target_observations: 6,
      });
    }
    if (p === '/rest/v1/rpc/team_progress') {
      const t = tables;
      const rows = Object.values(users).filter((u) => u.profile.active).map((u) => ({
        surveyor_id: u.id, surveyor_name: u.profile.full_name,
        buyers: submitted(t.buyer_responses).filter((r) => r.surveyor_id === u.id).length,
        vendors: submitted(t.vendor_responses).filter((r) => r.surveyor_id === u.id).length,
        observations: submitted(t.observation_sessions).filter((r) => r.surveyor_id === u.id).length,
        evaluations: 0,
      }));
      return json(req, res, 200, rows);
    }

    // ---- envoi des fiches : upsert avec ignore-duplicates
    const m = p.match(/^\/rest\/v1\/(buyer_responses|vendor_responses|observation_sessions|refusals)$/);
    if (m && req.method === 'POST') {
      const table = m[1];
      const row = await readBody(req);
      const prefer = req.headers.prefer || '';
      const ignoreDup = /resolution=ignore-duplicates/.test(prefer) && url.searchParams.get('on_conflict') === 'id';
      log.push({ table, id: row.id, ignoreDup, at: Date.now() });

      if (mode.kind === 'reject' && mode.count > 0) {
        mode.count--;
        return json(req, res, 400, { code: '23514', message: 'new row violates check constraint', details: null, hint: null });
      }
      if (mode.kind === 'server500' && mode.count > 0) { mode.count--; return json(req, res, 503, { message: 'Service Unavailable' }); }

      const exists = tables[table].has(row.id);
      if (exists && !ignoreDup) return json(req, res, 409, { code: '23505', message: 'duplicate key value violates unique constraint' });
      if (!exists) tables[table].set(row.id, { ...row, version: 1, synced_at: new Date().toISOString() });

      if (mode.kind === 'lose-response' && mode.count > 0) {
        mode.count--; // le serveur A reçu la fiche, mais la réponse n'arrive jamais au téléphone
        req.socket.destroy();
        return;
      }
      return json(req, res, 201);
    }
    json(req, res, 404, { message: 'not found: ' + p });
  });
  return new Promise((resolve) => server.listen(port, () => resolve({ server, ids, mission, tables, log, close: () => new Promise((r) => server.close(r)) })));
}
