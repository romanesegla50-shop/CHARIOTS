// Serveur de test « type PostgREST » branché sur une VRAIE base PostgreSQL (PGlite) qui exécute
// le script supabase/migrations/001_schema.sql (+ ses règles RLS). Chaque requête est exécutée avec
// le rôle « authenticated » et l'identifiant de l'utilisateur du jeton, comme le fait Supabase.
// Ce n'est PAS Supabase : le routage HTTP, l'authentification et le traducteur de requêtes sont simulés ici.
import http from 'node:http';
import fs from 'node:fs';
import path from 'node:path';
import { randomUUID } from 'node:crypto';
import { fileURLToPath } from 'node:url';
import { PGlite } from '@electric-sql/pglite';

const here = path.dirname(fileURLToPath(import.meta.url));
const b64 = (o) => Buffer.from(JSON.stringify(o)).toString('base64url');
const jwt = (sub, email) =>
  `${b64({ alg: 'HS256', typ: 'JWT' })}.${b64({ sub, email, role: 'authenticated', aud: 'authenticated', exp: Math.floor(Date.now() / 1000) + 3600 })}.sig`;
const ident = (s) => { if (!/^[a-z_][a-z0-9_]*$/i.test(s)) throw Object.assign(new Error('identifiant invalide: ' + s), { http: 400 }); return `"${s}"`; };
const TABLES = new Set(['profiles', 'missions', 'mission_members', 'zones', 'buyer_responses', 'vendor_responses', 'observation_sessions', 'zone_evaluations', 'refusals', 'audit_log']);
const FUNCS = new Set(['team_progress', 'mission_overview', 'survey_summary']);

export async function startShim(port) {
  const db = new PGlite();
  await db.exec(`
    create role anon nologin; create role authenticated nologin; create role service_role nologin bypassrls;
    create schema auth;
    create table auth.users (id uuid primary key default gen_random_uuid(), email text, raw_user_meta_data jsonb default '{}'::jsonb);
    create function auth.uid() returns uuid language sql stable as $$ select nullif(current_setting('request.jwt.claim.sub', true), '')::uuid $$;
    grant usage on schema auth to anon, authenticated;
  `);
  await db.exec(fs.readFileSync(path.join(here, '../../supabase/migrations/001_schema.sql'), 'utf8'));

  // Supabase accorde ces droits par défaut ; les règles RLS du script restreignent ensuite l'accès ligne par ligne
  await db.exec(`grant usage on schema public to anon, authenticated; grant all on all tables in schema public to authenticated; grant execute on all functions in schema public to authenticated;`);
  const passwords = new Map(); // email -> {id, password}
  async function addUser(email, name, password, { role = 'ENQUETEUR', active = true } = {}) {
    const id = randomUUID();
    await db.query(`insert into auth.users (id, email, raw_user_meta_data) values ($1,$2,$3)`, [id, email, JSON.stringify({ full_name: name })]);
    await db.query(`update public.profiles set role=$2, active=$3 where id=$1`, [id, role, active]);
    passwords.set(email.toLowerCase(), { id, password });
    return id;
  }

  // une seule connexion PGlite : on sérialise les requêtes
  let chain = Promise.resolve();
  const exclusive = (fn) => { const r = chain.then(fn, fn); chain = r.catch(() => {}); return r; };
  const asUser = (sub, fn) => exclusive(async () => {
    await db.exec('begin');
    try {
      await db.exec(`set local role authenticated`);
      await db.query(`select set_config('request.jwt.claim.sub', $1, true)`, [sub || '']);
      const out = await fn();
      await db.exec('commit');
      return out;
    } catch (e) { await db.exec('rollback').catch(() => {}); throw e; }
  });

  const subOf = (req) => {
    try { return JSON.parse(Buffer.from((req.headers.authorization || '').replace('Bearer ', '').split('.')[1], 'base64url').toString()).sub; } catch { return null; }
  };

  // ------------------------------------------------------------ traducteur PostgREST -> SQL
  const RESERVED = new Set(['select', 'order', 'limit', 'offset', 'on_conflict', 'columns']);
  function where(params, args) {
    const parts = [];
    for (const [k, v] of params) {
      if (RESERVED.has(k)) continue;
      const m = v.match(/^(eq|neq|gt|gte|lt|lte|in|is)\.(.*)$/s);
      if (!m) throw Object.assign(new Error('filtre non géré: ' + k + '=' + v), { http: 400 });
      const [, op, val] = m;
      const col = ident(k);
      if (op === 'is') parts.push(`${col} is ${val === 'null' ? 'null' : val === 'true' ? 'true' : 'false'}`);
      else if (op === 'in') {
        const vals = val.replace(/^\(|\)$/g, '').split(',').map((x) => x.replace(/^"|"$/g, ''));
        parts.push(`${col} in (${vals.map((x) => { args.push(x); return `$${args.length}`; }).join(',')})`);
      } else {
        args.push(val);
        parts.push(`${col} ${{ eq: '=', neq: '<>', gt: '>', gte: '>=', lt: '<', lte: '<=' }[op]} $${args.length}`);
      }
    }
    return parts.length ? ' where ' + parts.join(' and ') : '';
  }
  const selectList = (s) => (!s || s === '*' ? '*' : s.split(',').map((c) => ident(c.trim())).join(', '));
  const orderBy = (params) => {
    const o = params.get('order');
    if (!o) return '';
    return ' order by ' + o.split(',').map((x) => { const [c, d] = x.split('.'); return `${ident(c)} ${d === 'desc' ? 'desc' : 'asc'}`; }).join(', ');
  };
  const asJson = (sql, args) => db.query(`select coalesce(json_agg(t), '[]'::json) as j from (${sql}) t`, args).then((r) => r.rows[0].j);

  async function rest(req, table, body, params) {
    const prefer = req.headers.prefer || '';
    const wantRows = /return=representation/.test(prefer);
    const t = `public.${ident(table)}`;
    const args = [];
    if (req.method === 'GET') {
      const w = where(params, args);
      const lim = params.get('limit') ? ` limit ${parseInt(params.get('limit'), 10)}` : '';
      const off = params.get('offset') ? ` offset ${parseInt(params.get('offset'), 10)}` : '';
      return { status: 200, rows: await asJson(`select ${selectList(params.get('select'))} from ${t}${w}${orderBy(params)}${lim}${off}`, args) };
    }
    if (req.method === 'POST') {
      const rows = Array.isArray(body) ? body : [body];
      const cols = [...new Set(rows.flatMap((r) => Object.keys(r)))];
      const cl = cols.map(ident).join(', ');
      args.push(JSON.stringify(rows));
      let conflict = '';
      const oc = params.get('on_conflict');
      if (oc) {
        const keys = oc.split(',').map(ident).join(', ');
        if (/resolution=ignore-duplicates/.test(prefer)) conflict = ` on conflict (${keys}) do nothing`;
        else if (/resolution=merge-duplicates/.test(prefer)) conflict = ` on conflict (${keys}) do update set ${cols.map((c) => `${ident(c)} = excluded.${ident(c)}`).join(', ')}`;
      }
      const ins = `insert into ${t} (${cl}) select ${cl} from json_populate_recordset(null::${t}, $1::json)${conflict} returning *`;
      const out = await db.query(`with ins as (${ins}) select coalesce(json_agg(ins), '[]'::json) as j from ins`, args);
      return { status: 201, rows: wantRows ? out.rows[0].j : null };
    }
    if (req.method === 'PATCH') {
      const cols = Object.keys(body);
      args.push(JSON.stringify(body));
      const set = `(${cols.map(ident).join(', ')}) = (select ${cols.map(ident).join(', ')} from json_populate_record(null::${t}, $1::json))`;
      const w = where(params, args);
      const out = await db.query(`with u as (update ${t} set ${set}${w} returning *) select coalesce(json_agg(u), '[]'::json) as j from u`, args);
      return { status: wantRows || params.get('select') ? 200 : 204, rows: wantRows || params.get('select') ? out.rows[0].j : null };
    }
    if (req.method === 'DELETE') {
      const w = where(params, args);
      const out = await db.query(`with d as (delete from ${t}${w} returning *) select coalesce(json_agg(d), '[]'::json) as j from d`, args);
      return { status: wantRows || params.get('select') ? 200 : 204, rows: wantRows || params.get('select') ? out.rows[0].j : null };
    }
    throw Object.assign(new Error('méthode non gérée'), { http: 405 });
  }

  async function rpc(fn, body) {
    if (!FUNCS.has(fn)) throw Object.assign(new Error('fonction inconnue'), { http: 404 });
    const keys = Object.keys(body || {});
    const args = keys.map((k) => body[k]);
    const call = `select * from public.${fn}(${keys.map((k, i) => `${ident(k)} => $${i + 1}`).join(', ')})`;
    const r = await db.query(call, args);
    if (r.rows.length === 1 && Object.keys(r.rows[0]).length === 1 && Object.keys(r.rows[0])[0] === fn) return r.rows[0][fn];
    return r.rows;
  }

  // ------------------------------------------------------------ HTTP
  const cors = (req, res) => {
    res.setHeader('Access-Control-Allow-Origin', '*');
    res.setHeader('Access-Control-Allow-Headers', req.headers['access-control-request-headers'] || '*');
    res.setHeader('Access-Control-Allow-Methods', 'GET,POST,PATCH,DELETE,OPTIONS');
    res.setHeader('Access-Control-Expose-Headers', '*');
  };
  const send = (req, res, status, body) => {
    cors(req, res); res.statusCode = status; res.setHeader('Content-Type', 'application/json');
    res.end(body === undefined || body === null ? '' : JSON.stringify(body));
  };
  const readBody = (req) => new Promise((resolve) => { let d = ''; req.on('data', (c) => (d += c)); req.on('end', () => { try { resolve(d ? JSON.parse(d) : {}); } catch { resolve({}); } }); });
  const session = (email) => {
    const u = passwords.get(email);
    return {
      access_token: jwt(u.id, email), token_type: 'bearer', expires_in: 3600, expires_at: Math.floor(Date.now() / 1000) + 3600, refresh_token: 'rt-' + u.id,
      user: { id: u.id, aud: 'authenticated', role: 'authenticated', email, app_metadata: {}, user_metadata: {}, created_at: '2026-10-01T00:00:00Z' },
    };
  };
  const statusOf = (e) => (e.http ? e.http : e.code === 'PT409' || e.code === '23505' ? 409 : e.code === '42501' ? 403 : 400);

  const server = http.createServer(async (req, res) => {
    const url = new URL(req.url, `http://localhost:${port}`);
    const p = url.pathname;
    try {
      if (req.method === 'OPTIONS') { cors(req, res); res.statusCode = 204; return res.end(); }
      if (p === '/__admin/sql') { // outil de test : requête en super-utilisateur
        const b = await readBody(req);
        const r = await exclusive(() => db.query(b.sql, b.params || []));
        return send(req, res, 200, r.rows);
      }
      if (p === '/auth/v1/token') {
        const b = await readBody(req);
        if (url.searchParams.get('grant_type') === 'refresh_token') {
          const e = [...passwords.entries()].find(([, v]) => 'rt-' + v.id === b.refresh_token);
          return e ? send(req, res, 200, session(e[0])) : send(req, res, 400, { error: 'invalid_grant' });
        }
        const u = passwords.get((b.email || '').toLowerCase());
        if (!u || u.password !== b.password) return send(req, res, 400, { error: 'invalid_grant', error_description: 'Invalid login credentials', code: 400, msg: 'Invalid login credentials' });
        return send(req, res, 200, session(b.email.toLowerCase()));
      }
      if (p === '/auth/v1/logout') return send(req, res, 204);
      if (p === '/auth/v1/user') {
        const sub = subOf(req); const e = [...passwords.entries()].find(([, v]) => v.id === sub);
        return e ? send(req, res, 200, session(e[0]).user) : send(req, res, 401, { message: 'invalid JWT' });
      }
      let m = p.match(/^\/rest\/v1\/rpc\/([a-z_]+)$/);
      if (m) {
        const body = await readBody(req);
        const out = await asUser(subOf(req), () => rpc(m[1], body));
        return send(req, res, 200, out);
      }
      m = p.match(/^\/rest\/v1\/([a-z_]+)$/);
      if (m && TABLES.has(m[1])) {
        const body = req.method === 'POST' || req.method === 'PATCH' ? await readBody(req) : null;
        const out = await asUser(subOf(req), () => rest(req, m[1], body, url.searchParams));
        const single = /pgrst\.object/.test(req.headers.accept || '');
        if (single && out.rows) {
          if (out.rows.length !== 1) return send(req, res, 406, { code: 'PGRST116', message: 'JSON object requested, multiple (or no) rows returned', details: `The result contains ${out.rows.length} rows` });
          return send(req, res, out.status, out.rows[0]);
        }
        return send(req, res, out.status, out.rows);
      }
      send(req, res, 404, { message: 'not found: ' + p });
    } catch (e) {
      send(req, res, statusOf(e), { code: e.code || 'PGRST000', message: e.message, details: null, hint: null });
    }
  });
  await new Promise((r) => server.listen(port, r));
  const sql = async (q, params = []) => (await exclusive(() => db.query(q, params))).rows;
  return { addUser, sql, db, close: () => new Promise((r) => server.close(r)) };
}
