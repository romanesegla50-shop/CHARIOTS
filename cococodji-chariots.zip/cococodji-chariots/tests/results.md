# Résultats des tests de la base de données

Exécutés le 2026-10-28T21:23:45.709Z sur PostgreSQL local (PGlite), script 001_schema.sql.

**89 réussis, 0 échecs, 89 au total.**

> Ces tests couvrent la base de données (règles d'accès, validation, doublons, conflits, audit, statistiques).
> Ils ne remplacent pas le test sur un vrai projet Supabase avec deux téléphones (voir le guide).


## 0. Installation du script

- ✅ Le script 001 s'exécute sans erreur sur une base vide
- ✅ Le script 001 peut être relancé une 2e fois sans erreur (idempotent)
- ✅ Un nouveau compte reçoit un profil INACTIF par défaut

## 1. Un enquêteur crée et soumet (scénarios 1, 2, 3)

- ✅ S1 soumet un questionnaire acheteur
- ✅ S1 soumet un questionnaire commerçante
- ✅ S1 enregistre une observation
- ✅ L'administrateur voit la réponse de S1 dans la base commune (scénario 4)
- ✅ S1 retrouve sa propre réponse
- ✅ S2 ne voit PAS la réponse de S1
- ✅ Le serveur renseigne version=1, submitted_at et synced_at

## 2. Anti-doublon à la synchronisation (scénario 7, côté serveur)

- ✅ Renvoyer 3 fois la même réponse (même id) ne crée aucun doublon et aucune erreur
- ✅ Saisir deux fois la même session d'observation (autre id, même créneau) est refusé

## 3. Champs obligatoires et consentement (scénario 9)

- ✅ Soumettre un acheteur incomplet (Q12 manquante) est refusé par la base
- ✅ Soumettre sans code de zone est refusé
- ✅ Un acheteur sans consentement ne peut PAS être enregistré
- ✅ « Autre montant » sans montant est refusé
- ✅ Difficulté « Autre » sans texte est refusée
- ✅ Valeur hors liste (q2 = "BOF") refusée côté serveur
- ✅ Un brouillon incomplet est accepté
- ✅ Un refus ne crée qu'une ligne de compteur, sans réponse
- ✅ S2 ne voit pas les refus de S1
- ✅ Observation : heure de fin avant l'heure de début refusée
- ✅ Observation : « Aucun » obstacle combiné à « Marches » refusé
- ✅ Évaluation de zone : note 6 refusée
- ✅ Évaluation de zone complète acceptée (notes 1 à 5)
- ✅ Une zone d'une autre mission est refusée (cohérence mission/zone)

## 4. Accès non autorisés (scénario 6)

- ✅ Un visiteur non connecté ne peut pas lire les réponses
- ✅ Un visiteur non connecté ne peut pas appeler les fonctions de synthèse
- ✅ Un visiteur non connecté ne peut pas écrire
- ✅ Un compte INACTIF ne peut pas écrire
- ✅ Un compte INACTIF ne voit aucune donnée (missions, zones, réponses)
- ✅ Un utilisateur sans profil ne peut pas écrire
- ✅ S1 ne peut pas saisir une réponse au nom de S2
- ✅ S1 ne peut pas créer une réponse directement au statut EXCLU
- ✅ S1 ne peut pas modifier une réponse déjà SOUMISE (0 ligne modifiée)
- ✅ S1 ne peut pas supprimer une réponse soumise
- ✅ S2 ne peut ni modifier ni supprimer la réponse de S1
- ✅ S1 ne peut pas lire le journal d'audit
- ✅ S1 ne peut pas écrire dans le journal d'audit
- ✅ S1 ne peut pas vider une table (TRUNCATE)
- ✅ S1 ne voit que son propre profil
- ✅ S1 ne peut pas se donner le rôle administrateur
- ✅ S1 ne peut pas activer le compte inactif S3
- ✅ S1 ne peut pas créer de zone
- ✅ S1 ne peut pas modifier la mission
- ✅ S1 ne peut pas appeler la synthèse (réservée à l'administrateur)
- ✅ L'administrateur ne peut pas se retirer ses propres droits

## 5. Brouillons, versions et conflits

- ✅ S1 modifie son brouillon : la version passe à 2
- ✅ Modification avec une version périmée : CONFLIT explicite (HTTP 409), pas d'écrasement
- ✅ Après le conflit, la valeur serveur est intacte
- ✅ S1 ne peut pas changer l'auteur d'un brouillon
- ✅ S1 soumet son brouillon complété (version 2 -> 3)
- ✅ Brouillon renvoyé après soumission : 0 ligne modifiée (le téléphone reconnaît via client_rev)
- ✅ S1 peut supprimer son propre brouillon

## 6. Correction par l'administrateur et traçabilité

- ✅ L'administrateur corrige une réponse soumise (avec la bonne version)
- ✅ La correction est tracée dans audit_log (avant ET après, auteur = administrateur)
- ✅ Deux administrateurs : la 2e correction avec une version périmée est refusée (conflit)
- ✅ Les sauvegardes successives d'un BROUILLON ne polluent pas l'audit
- ✅ L'administrateur exclut une réponse (statut EXCLU)
- ✅ La suppression par l'administrateur est tracée (contenu supprimé conservé dans l'audit)

## 7. Zones et emplacements candidats (Module E)

- ✅ Le code de zone est normalisé en majuscules (z05 -> Z05)
- ✅ Code de zone en double refusé
- ✅ Plus de 3 zones candidates refusé
- ✅ Une zone non candidate ne peut pas être « validée »
- ✅ Une zone n'est jamais « validée » par défaut
- ✅ S1 ne peut pas valider une zone
- ✅ L'administrateur valide une zone : validé par + date enregistrés automatiquement
- ✅ Repasser une zone à « non validée » efface la validation

## 8. Synthèse automatique (scénario 5) : comparée à un calcul indépendant en JavaScript

- ✅ Acheteurs valides : 7 (brouillon et exclue non comptés)
- ✅ Commerçantes valides : 3
- ✅ Sessions d'observation : 3 (brouillon non compté)
- ✅ Zones étudiées : 2
- ✅ Difficultés souvent/presque toujours : n et d exacts
- ✅ Intérêt (certainement/probablement) : n et d exacts
- ✅ Deux trajets ou plus : n et d exacts
- ✅ Répartition des prix exacte
- ✅ « Autre montant » : 150 FCFA relevé
- ✅ Difficultés les plus fréquentes : comptes exacts
- ✅ Inquiétudes les plus fréquentes : comptes exacts
- ✅ Commerçantes : clients en difficulté souvent 2/3, utiliseraient 2/3
- ✅ Brouillons et exclues comptés à part (1 brouillon + 1 exclue acheteur, 1 brouillon observation)
- ✅ Détail par zone Y01 : 3 acheteurs, 2 en difficulté fréquente, 2 intéressés, 200 personnes observées, 40 charges lourdes
- ✅ Filtre par zone Y02 : seulement les 4 acheteurs de Y02
- ✅ Filtre par enquêteur S1 : seulement ses 3 acheteurs
- ✅ Filtre par dates (futur lointain) : aucun résultat, pas de faux chiffres
- ✅ Mission sans aucune donnée : tous les compteurs à 0 (état vide, rien de fictif)

## 9. Progression d'équipe (compteurs seulement)

- ✅ S1 voit les compteurs de chaque enquêteur actif, sans contenu
- ✅ S1 voit l'aperçu de mission (totaux et objectifs 30 / 15)
- ✅ Un compte inactif n'obtient ni progression ni aperçu
