import 'fake-indexeddb/auto';
import { beforeEach, describe, expect, it } from 'vitest';
import { listRecords, putRecord, resetLocalDb, getRecord, countRecords } from '@/lib/localdb';
import { queueForSync, retryRecord, syncAll, type Transport, type TransportResult } from '@/lib/sync';
import type { LocalRecord } from '@/lib/types';
import { randomUUID as uuid } from 'node:crypto';

const USER = 'user-1';

/** Faux serveur : garde les lignes par identifiant, et peut simuler les pannes. */
class FakeServer implements Transport {
  rows = new Map<string, Record<string, unknown>>();
  calls = 0;
  online = true;
  /** simule « le serveur a bien reçu, mais la réponse s'est perdue en route » */
  loseResponses = false;
  reject: { code: string; message: string } | null = null;
  authExpired = false;

  async insertIgnoreDuplicates(_table: string, row: Record<string, unknown>): Promise<TransportResult> {
    this.calls++;
    if (!this.online) return { ok: false, kind: 'network', message: 'Failed to fetch' };
    if (this.authExpired) return { ok: false, kind: 'auth', message: 'Session expirée' };
    if (this.reject) return { ok: false, kind: 'rejected', ...this.reject };
    if (!this.rows.has(row.id as string)) this.rows.set(row.id as string, row); // ON CONFLICT DO NOTHING
    if (this.loseResponses) return { ok: false, kind: 'network', message: 'Failed to fetch' };
    return { ok: true };
  }
}

function pendingRecord(over: Partial<LocalRecord> = {}): LocalRecord {
  const id = over.id ?? uuid();
  const now = new Date().toISOString();
  return {
    id, userId: USER, kind: 'acheteur', table: 'buyer_responses', state: 'PENDING',
    clientRev: uuid(), attempts: 0, row: { id, status: 'SOUMIS' }, createdAt: now, updatedAt: now, ...over,
  };
}

beforeEach(async () => {
  await resetLocalDb();
});

describe('Synchronisation hors ligne', () => {
  it('sans réseau : la fiche reste « en attente », rien n\'est perdu', async () => {
    const server = new FakeServer();
    server.online = false;
    await putRecord(pendingRecord());
    const report = await syncAll(server, USER);
    const [rec] = await listRecords(USER);
    expect(report.stoppedBy).toBe('network');
    expect(rec.state).toBe('PENDING');
    expect(rec.row).toBeDefined();
    expect(rec.attempts).toBe(1);
    expect(server.rows.size).toBe(0);
  });

  it('le réseau revient : la fiche part et passe à « Synchronisé »', async () => {
    const server = new FakeServer();
    server.online = false;
    const rec = pendingRecord();
    await putRecord(rec);
    await syncAll(server, USER);
    server.online = true;
    const report = await syncAll(server, USER);
    expect(report.sent).toBe(1);
    expect((await getRecord(rec.id))?.state).toBe('SYNCED');
    expect(server.rows.size).toBe(1);
  });

  it('plusieurs fiches saisies hors ligne partent toutes, dans l\'ordre de saisie', async () => {
    const server = new FakeServer();
    const base = Date.now();
    for (let i = 0; i < 5; i++) {
      await putRecord(pendingRecord({ createdAt: new Date(base + i * 1000).toISOString() }));
    }
    const report = await syncAll(server, USER);
    expect(report.sent).toBe(5);
    expect(server.rows.size).toBe(5);
    expect(countRecords(await listRecords(USER)).synced).toBe(5);
  });

  it('réponse perdue : le serveur a reçu, le téléphone réessaie, AUCUN doublon', async () => {
    const server = new FakeServer();
    server.loseResponses = true;
    const rec = pendingRecord();
    await putRecord(rec);
    await syncAll(server, USER); // 1re tentative : reçue par le serveur mais le téléphone croit à un échec
    expect((await getRecord(rec.id))?.state).toBe('PENDING');
    server.loseResponses = false;
    await syncAll(server, USER); // 2e tentative
    await syncAll(server, USER); // 3e tentative (rien à envoyer)
    expect(server.rows.size).toBe(1);
    expect((await getRecord(rec.id))?.state).toBe('SYNCED');
  });

  it('une fiche déjà synchronisée n\'est jamais renvoyée', async () => {
    const server = new FakeServer();
    await putRecord(pendingRecord());
    await syncAll(server, USER);
    const callsAfterFirst = server.calls;
    await syncAll(server, USER);
    await syncAll(server, USER);
    expect(server.calls).toBe(callsAfterFirst);
  });

  it('deux synchronisations lancées en même temps n\'envoient qu\'une fois', async () => {
    const server = new FakeServer();
    await putRecord(pendingRecord());
    const [a, b] = await Promise.all([syncAll(server, USER), syncAll(server, USER)]);
    expect(server.calls).toBe(1);
    expect(a).toBe(b);
  });

  it('un refus du serveur met la fiche en « Erreur » avec un message clair, sans bloquer les autres', async () => {
    const server = new FakeServer();
    const bad = pendingRecord({ createdAt: new Date(1000).toISOString() });
    const good = pendingRecord({ createdAt: new Date(2000).toISOString() });
    await putRecord(bad);
    await putRecord(good);
    // le serveur refuse seulement la première
    const original = server.insertIgnoreDuplicates.bind(server);
    server.insertIgnoreDuplicates = async (t, row) =>
      row.id === bad.id ? { ok: false, kind: 'rejected', code: '23514', message: 'check violation' } : original(t, row);
    const report = await syncAll(server, USER);
    expect(report.rejected).toBe(1);
    expect(report.sent).toBe(1);
    const badAfter = await getRecord(bad.id);
    expect(badAfter?.state).toBe('ERROR');
    expect(badAfter?.error).toMatch(/refusé la fiche/);
    expect((await getRecord(good.id))?.state).toBe('SYNCED');
  });

  it('compte non activé (droits insuffisants) : message explicite', async () => {
    const server = new FakeServer();
    server.reject = { code: '42501', message: 'new row violates row-level security policy' };
    const rec = pendingRecord();
    await putRecord(rec);
    await syncAll(server, USER);
    const after = await getRecord(rec.id);
    expect(after?.state).toBe('ERROR');
    expect(after?.error).toMatch(/pas encore activé/);
  });

  it('« Réessayer » après une erreur remet la fiche en attente puis la synchronise', async () => {
    const server = new FakeServer();
    server.reject = { code: '42501', message: 'rls' };
    const rec = pendingRecord();
    await putRecord(rec);
    await syncAll(server, USER);
    expect((await getRecord(rec.id))?.state).toBe('ERROR');
    server.reject = null; // l'administrateur a activé le compte
    await retryRecord(rec.id);
    expect((await getRecord(rec.id))?.state).toBe('PENDING');
    await syncAll(server, USER);
    expect((await getRecord(rec.id))?.state).toBe('SYNCED');
    expect(server.rows.size).toBe(1);
  });

  it('session expirée : l\'envoi s\'arrête, les fiches restent en attente', async () => {
    const server = new FakeServer();
    server.authExpired = true;
    await putRecord(pendingRecord());
    await putRecord(pendingRecord());
    const report = await syncAll(server, USER);
    expect(report.stoppedBy).toBe('auth');
    expect(report.remaining).toBe(2);
    expect(server.calls).toBe(1); // inutile d'insister sur toutes les fiches
  });

  it('réseau qui se fige (aucune réponse) : l\'envoi est abandonné après le délai, la fiche reste en attente, la file n\'est pas bloquée', async () => {
    const hanging: Transport = { insertIgnoreDuplicates: () => new Promise(() => {}) }; // ne répond jamais
    const rec = pendingRecord();
    await putRecord(rec);
    const report = await syncAll(hanging, USER, { timeoutMs: 60 });
    expect(report.stoppedBy).toBe('network');
    expect((await getRecord(rec.id))?.state).toBe('PENDING');
    // la file n'est pas restée bloquée : un envoi suivant fonctionne
    const server = new FakeServer();
    const again = await syncAll(server, USER);
    expect(again.sent).toBe(1);
    expect((await getRecord(rec.id))?.state).toBe('SYNCED');
  });

  it('l\'envoi reçoit un signal d\'annulation pour libérer la connexion au bout du délai', async () => {
    let received: AbortSignal | undefined;
    const t: Transport = { insertIgnoreDuplicates: (_t, _r, signal) => { received = signal; return new Promise(() => {}); } };
    await putRecord(pendingRecord());
    await syncAll(t, USER, { timeoutMs: 40 });
    expect(received?.aborted).toBe(true);
  });

  it('les brouillons ne sont jamais envoyés', async () => {
    const server = new FakeServer();
    await putRecord(pendingRecord({ state: 'LOCAL', row: undefined, draft: { answers: {}, stepIndex: 0, startedAt: '', ordering: 'ASC', consent: true } }));
    await syncAll(server, USER);
    expect(server.calls).toBe(0);
  });

  it('un autre compte sur le même téléphone ne voit ni n\'envoie les fiches de ce compte', async () => {
    const server = new FakeServer();
    await putRecord(pendingRecord());
    const report = await syncAll(server, 'user-2');
    expect(server.calls).toBe(0);
    expect(report.sent).toBe(0);
    expect(await listRecords('user-2')).toHaveLength(0);
    expect(await listRecords(USER)).toHaveLength(1);
  });

  it('une fiche soumise passe de brouillon à « en attente » et perd son brouillon', async () => {
    const rec = pendingRecord({ state: 'LOCAL', draft: { answers: { a: 1 }, stepIndex: 2, startedAt: '', ordering: 'ASC', consent: true } });
    await queueForSync(rec);
    const after = await getRecord(rec.id);
    expect(after?.state).toBe('PENDING');
    expect(after?.draft).toBeUndefined();
  });

  it('les données survivent à la fermeture de l\'application (rouverture de la base locale)', async () => {
    const rec = pendingRecord();
    await putRecord(rec);
    // on « ferme » la connexion locale sans effacer le stockage, puis on relit
    const reopened = await listRecords(USER);
    expect(reopened.map((r) => r.id)).toEqual([rec.id]);
  });
});
