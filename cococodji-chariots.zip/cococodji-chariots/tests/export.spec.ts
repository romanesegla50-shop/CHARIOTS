import { describe, expect, it } from 'vitest';
import { spawnSync } from 'node:child_process';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import {
  buildCandidateZones, buildDatasets, buildSummarySheet, fmtLocal, neutralizeFormula, safeFileName, toCsv, toXlsxBlob,
  type Dataset, type ExportContext, type ExportData,
} from '@/lib/export';
import type { FullZone, ServerRow, Summary } from '@/lib/admin';

const AWA = '11111111-1111-4111-8111-111111111111';
const KOFFI = '22222222-2222-4222-8222-222222222222';
const Z1 = 'aaaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaa1';
const Z2 = 'aaaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaa2';
const Z3 = 'aaaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaa3';

const ctx: ExportContext = {
  zones: [{ id: Z1, code: 'Z01', label: 'Entrée nord' }, { id: Z2, code: 'Z02', label: null }, { id: Z3, code: 'Z03', label: null }],
  profiles: [
    { id: AWA, full_name: 'Awa', email: 'awa@test.bj' },
    { id: KOFFI, full_name: '', email: 'koffi@test.bj' },
  ],
};

const base = (o: Partial<ServerRow>): ServerRow => ({
  id: 'x', mission_id: 'm', zone_id: Z1, surveyor_id: AWA, status: 'SOUMIS', version: 1,
  created_at: '2026-11-02T08:00:00Z', updated_at: '2026-11-02T08:00:00Z', submitted_at: '2026-11-02T08:20:00Z', synced_at: '2026-11-02T08:21:00Z',
  ...o,
});

const buyer = (o: Partial<ServerRow>) => base({
  consent: true, form_version: 'acheteur-v1', started_at: '2026-11-02T08:15:00Z', ended_at: '2026-11-02T08:25:00Z',
  q1_transporte: 'OUI', q2_frequence: 'PRESQUE_CHAQUE_VISITE', q3_difficultes: ['CHARGES_LOURDES', 'AUTRE'], q3_autre: 'Escaliers',
  q4_mode_transport: 'PORTEUR_PAYE', q5_nb_trajets: '3_OU_PLUS', q6_utilisation: 'CERTAINEMENT', q7_trajet_utile: 'ETALS_PARKING',
  q8_moment_utile: 'HEURES_AFFLUENCE', q9_paiement: 'PRIX_FIXE', q10_prix: 'AUTRE_MONTANT', q10_montant_fcfa: 150, q10_ordre_options: '300-200-100',
  q11_caution: 'DEPEND_MONTANT', q12_inquietude: 'PRIX', q13_remarque: 'À ne pas oublier ; "guillemets"\net retour à la ligne', ...o,
});

const zones: FullZone[] = [
  {
    id: Z1, code: 'Z01', label: 'Entrée nord', description: 'Près du parking', sector: 'Nord', is_candidate: true, approval_status: 'VALIDE',
    mission_id: 'm', approved_by: AWA, approved_at: '2026-11-05T10:00:00Z',
    manager_checks: { espace: { done: true, note: 'Confirmé par téléphone' }, frais: { done: false, note: '' } },
  },
  { id: Z2, code: 'Z02', label: null, description: null, sector: null, is_candidate: true, approval_status: 'NON_VALIDE', mission_id: 'm', approved_by: null, approved_at: null, manager_checks: {} },
  { id: Z3, code: 'Z03', label: null, description: null, sector: null, is_candidate: false, approval_status: 'NON_VALIDE', mission_id: 'm', approved_by: null, approved_at: null, manager_checks: {} },
];

const evalRow = (zone: string, user: string, scores: number[], status = 'SOUMIS') =>
  base({
    id: `ev-${zone}-${user}`, zone_id: zone, surveyor_id: user, status: status as ServerRow['status'],
    score_flux: scores[0], score_zones_lourdes: scores[1], score_acces_sortie: scores[2], score_passage: scores[3],
    score_retour_chariots: scores[4], score_surveillance: scores[5], score_faible_encombrement: scores[6],
  });

const data: ExportData = {
  buyers: [
    buyer({ id: 'b1' }),
    buyer({ id: 'b2', surveyor_id: KOFFI, zone_id: Z2, q3_difficultes: ['PLUSIEURS_SACS'], q3_autre: null, q10_prix: '200', q10_montant_fcfa: null, q13_remarque: '=HYPERLINK("http://x")' }),
    buyer({ id: 'b3', status: 'BROUILLON', zone_id: null }),
    buyer({ id: 'b4', status: 'EXCLU' }),
  ],
  vendors: [base({
    id: 'v1', consent: true, form_version: 'commercante-v1', q1_difficultes_clients: 'TRES_SOUVENT', q2_produits: ['SACS_PROVISIONS', 'PRODUITS_LOURDS'],
    q3_comportement: 'PAIENT_PORTEUR', q4_zone_id: Z2, q5_moment: 'MATIN', q6_risques: ['VOL_PERTE'], q7_utiliseraient: 'OUI',
  })],
  observations: [base({
    id: 'o1', form_version: 'observation-v1', observed_on: '2026-11-02', start_time: '09:00:00', end_time: '09:15:00', people_count: 120, heavy_load_count: 30,
    flow_level: 'FORT', obstacles: ['MARCHES', 'PENTE'], trolley_access: 'DIFFICILE', congestion_risk: 'ELEVE', distance_exit_m: 80,
  })],
  evaluations: [
    evalRow(Z1, AWA, [5, 4, 3, 3, 2, 4, 1]),
    evalRow(Z1, KOFFI, [3, 4, 5, 3, 4, 4, 3]),
    evalRow(Z1, 'brouillon-user', [1, 1, 1, 1, 1, 1, 1], 'BROUILLON'),
  ],
  zones,
  mission: null,
  includeAll: false,
};

/** Lecteur CSV indépendant du code testé (séparateur « ; », guillemets doublés). */
function parseCsv(csv: string): string[][] {
  const body = csv.replace(/^﻿/, '');
  const rows: string[][] = [];
  let row: string[] = [];
  let cell = '';
  let q = false;
  for (let i = 0; i < body.length; i++) {
    const ch = body[i];
    if (q) {
      if (ch === '"' && body[i + 1] === '"') { cell += '"'; i++; }
      else if (ch === '"') q = false;
      else cell += ch;
    } else if (ch === '"') q = true;
    else if (ch === ';') { row.push(cell); cell = ''; }
    else if (ch === '\r' && body[i + 1] === '\n') { row.push(cell); rows.push(row); row = []; cell = ''; i++; }
    else cell += ch;
  }
  if (cell || row.length) { row.push(cell); rows.push(row); }
  return rows;
}
const col = (ds: Dataset, header: string) => ds.headers.indexOf(header);

describe('Heure du Bénin', () => {
  it('convertit l\'UTC en heure locale (UTC+1) y compris au changement de jour', () => {
    expect(fmtLocal('2026-11-02T08:15:00Z')).toBe('2026-11-02 09:15');
    expect(fmtLocal('2026-11-02T23:30:00Z')).toBe('2026-11-03 00:30');
    expect(fmtLocal(null)).toBe('');
    expect(fmtLocal('pas une date')).toBe('');
  });
});

describe('Protection contre les formules (injection CSV)', () => {
  it('neutralise = + - @ en début de cellule, laisse le reste intact', () => {
    expect(neutralizeFormula('=1+1')).toBe("'=1+1");
    expect(neutralizeFormula('+33 1 23')).toBe("'+33 1 23");
    expect(neutralizeFormula('-cmd')).toBe("'-cmd");
    expect(neutralizeFormula('@SUM(A1)')).toBe("'@SUM(A1)");
    expect(neutralizeFormula('Escaliers = danger')).toBe('Escaliers = danger');
    expect(neutralizeFormula('')).toBe('');
  });
});

describe('CSV', () => {
  const ds = buildDatasets(data, ctx).buyers;
  const csv = toCsv(ds);
  const parsed = parseCsv(csv);

  it('UTF-8 avec BOM, lignes CRLF, séparateur « ; », en-têtes explicites', () => {
    expect(csv.charCodeAt(0)).toBe(0xfeff);
    expect(csv).toContain('\r\n');
    expect(parsed[0]).toEqual(ds.headers);
    expect(ds.headers).toContain('Q2 Fréquence des difficultés');
    expect(ds.headers).toContain('Q10 Prix jugé acceptable');
    // chaque ligne a autant de colonnes que l'en-tête (le retour à la ligne et le « ; » d'une remarque ne cassent rien)
    for (const r of parsed) expect(r).toHaveLength(ds.headers.length);
  });

  it('seules les réponses soumises sont exportées par défaut (ni brouillon ni exclue)', () => {
    expect(parsed).toHaveLength(1 + 2);
    expect(parsed.slice(1).map((r) => r[0]).sort()).toEqual(['b1', 'b2']);
    const all = buildDatasets({ ...data, includeAll: true }, ctx).buyers;
    expect(all.rows).toHaveLength(4);
    expect(all.rows.map((r) => r[col(all, 'Statut')]).sort()).toEqual(['Brouillon', 'Exclue', 'Soumise', 'Soumise']);
  });

  it('le contenu des cellules est exactement celui des réponses (libellés français, zone, enquêteur, heure locale)', () => {
    const r1 = parsed.find((r) => r[0] === 'b1')!;
    const get = (h: string) => r1[col(ds, h)];
    expect(get('Enquêteur')).toBe('Awa');
    expect(get('Zone (code)')).toBe('Z01');
    expect(get('Statut')).toBe('Soumise');
    expect(get('Début de l’entretien')).toBe('2026-11-02 09:15');
    expect(get('Consentement')).toBe('Oui');
    expect(get('Q2 Fréquence des difficultés')).toBe('Presque à chaque visite');
    expect(get('Q3 Difficultés principales')).toBe('Charges lourdes | Autre');
    expect(get('Q3 Autre difficulté (texte)')).toBe('Escaliers');
    expect(get('Q5 Nombre de trajets')).toBe('3 ou plus');
    expect(get('Q10 Prix jugé acceptable')).toBe('Autre montant');
    expect(get('Q10 Autre montant (FCFA)')).toBe('150');
    expect(get('Q10 Ordre de présentation des prix')).toBe('300-200-100');
    expect(get('Q11 Caution remboursable : découragement')).toBe('Cela dépend du montant');
  });

  it('un enquêteur sans nom est identifié par son e-mail', () => {
    const r2 = parsed.find((r) => r[0] === 'b2')!;
    expect(r2[col(ds, 'Enquêteur')]).toBe('koffi@test.bj');
    expect(r2[col(ds, 'Zone (code)')]).toBe('Z02');
  });

  it('une remarque avec « ; », guillemets et retour à la ligne est restituée à l\'identique', () => {
    const r1 = parsed.find((r) => r[0] === 'b1')!;
    expect(r1[col(ds, 'Q13 Remarque ou suggestion')]).toBe('À ne pas oublier ; "guillemets"\net retour à la ligne');
  });

  it('une remarque commençant par « = » est neutralisée (aucune formule exécutable dans Excel)', () => {
    const r2 = parsed.find((r) => r[0] === 'b2')!;
    expect(r2[col(ds, 'Q13 Remarque ou suggestion')]).toBe(`'=HYPERLINK("http://x")`);
  });

  it('les nombres décimaux utilisent la virgule (Excel en français)', () => {
    const s = toCsv({ name: 't', headers: ['a'], rows: [[3.5], [3]] });
    expect(s).toContain('3,5');
    expect(s).toContain('\r\n3\r\n');
  });

  it('aucune colonne ne contient de donnée personnelle de la personne interrogée', () => {
    for (const d of Object.values(buildDatasets(data, ctx)))
      expect(d.headers.filter((h) => /téléphone|telephone|nom de la personne|adresse|photo/i.test(h))).toEqual([]);
  });
});

describe('Commerçantes et observations', () => {
  const d = buildDatasets(data, ctx);
  it('commerçantes : listes jointes, zone concernée', () => {
    const r = d.vendors.rows[0];
    expect(r[col(d.vendors, 'Q2 Produits ou achats difficiles')]).toBe('Sacs de provisions | Produits lourds');
    expect(r[col(d.vendors, 'Q4 Zone concernée (code)')]).toBe('Z02');
    expect(r[col(d.vendors, 'Q1 Clients en difficulté pour transporter')]).toBe('Très souvent');
  });
  it('observations : heures sans les secondes, nombres restent des nombres', () => {
    const r = d.observations.rows[0];
    expect(r[col(d.observations, 'Heure de début')]).toBe('09:00');
    expect(r[col(d.observations, 'Heure de fin')]).toBe('09:15');
    expect(r[col(d.observations, 'Personnes passant dans la zone (approx.)')]).toBe(120);
    expect(r[col(d.observations, 'Obstacles visibles')]).toBe('Marches | Pente');
    expect(r[col(d.observations, 'Distance vers sortie ou parking (m)')]).toBe(80);
  });
});

describe('Zones candidates', () => {
  const ds = buildCandidateZones(data, ctx);
  it('seules les zones candidates figurent dans le tableau (Z03 exclue)', () => {
    expect(ds.rows.map((r) => r[0])).toEqual(['Z01', 'Z02']);
  });
  it('moyennes calculées sur les évaluations soumises uniquement (le brouillon est ignoré)', () => {
    const r = ds.rows[0];
    expect(r[col(ds, 'Nombre d’évaluations soumises')]).toBe(2);
    expect(r[col(ds, 'Moyenne : Flux de clients')]).toBe(4); // (5+3)/2
    expect(r[col(ds, 'Moyenne : Faible encombrement')]).toBe(2); // (1+3)/2
    // total des moyennes : 4 + 4 + 4 + 3 + 3 + 4 + 2 = 24
    expect(r[col(ds, 'Total des moyennes (sur 35)')]).toBe(24);
  });
  it('une zone sans évaluation affiche 0 évaluation et aucune note inventée', () => {
    const r = ds.rows[1];
    expect(r[col(ds, 'Nombre d’évaluations soumises')]).toBe(0);
    expect(r[col(ds, 'Moyenne : Flux de clients')]).toBe('');
    expect(r[col(ds, 'Total des moyennes (sur 35)')]).toBe('');
  });
  it('validation et points à confirmer : jamais « validée » sans validation enregistrée', () => {
    expect(ds.rows[0][col(ds, 'Validation par l’administrateur')]).toBe('Validée par l’administrateur');
    expect(ds.rows[0][col(ds, 'Validée le')]).toBe('2026-11-05');
    expect(ds.rows[1][col(ds, 'Validation par l’administrateur')]).toBe('Non validée');
    expect(ds.rows[1][col(ds, 'Validée le')]).toBe('');
    expect(ds.rows[0][col(ds, 'À confirmer : Espace réellement disponible')]).toBe('Confirmé');
    expect(ds.rows[0][col(ds, 'Note : Espace réellement disponible')]).toBe('Confirmé par téléphone');
    expect(ds.rows[0][col(ds, 'À confirmer : Frais éventuels')]).toBe('À confirmer');
    expect(ds.rows[1][col(ds, 'À confirmer : Horaires')]).toBe('À confirmer');
  });
});

const summary: Summary = {
  generated_at: '2026-11-09T10:00:00Z', basis: 'x', filters: { from: null, to: null, surveyor: null, zone: null },
  buyers_total: 7, vendors_total: 3, observations_total: 3, zones_studied: 2,
  buyers_often_difficulty: { n: 3, d: 7 }, buyers_interested: { n: 4, d: 7 }, buyers_two_trips_or_more: { n: 4, d: 7 },
  vendors_clients_often_difficulty: { n: 2, d: 3 }, vendors_clients_would_use: { n: 2, d: 3 },
  price_distribution: { '200': 2, '100': 1, '300': 1, AUTRE_MONTANT: 1, NE_PAIERAIT_PAS: 2 }, price_other_amounts_fcfa: [150],
  deposit_reaction: {}, difficulties: { CHARGES_LOURDES: 3 }, concerns: { PRIX: 3 }, vendor_risks: {}, zones: [], observation_slots: [],
  first_date: '2026-11-02', last_date: '2026-11-04', drafts: { buyers: 1, vendors: 0, observations: 1 }, excluded: { buyers: 1, vendors: 0, observations: 0 }, refusals: 2,
};

describe('Feuille de synthèse', () => {
  const ds = buildSummarySheet(summary, null);
  const row = (label: string) => ds.rows.find((r) => String(r[0]).startsWith(label))!;
  it('chaque pourcentage est accompagné de son numérateur et de son dénominateur', () => {
    expect(row('Acheteurs : intérêt déclaré')).toEqual(['Acheteurs : intérêt déclaré (certainement ou probablement)', 4, 7, 57]);
    expect(row('Acheteurs : difficultés')).toEqual(['Acheteurs : difficultés souvent ou presque à chaque visite', 3, 7, 43]);
  });
  it('la volonté déclarée de payer = tous les prix choisis sauf « Je ne paierais pas » (5 sur 7)', () => {
    expect(row('Acheteurs : volonté déclarée')).toEqual(['Acheteurs : volonté déclarée de payer (un prix choisi)', 5, 7, 71]);
  });
  it('brouillons, exclues et refus sont indiqués à part', () => {
    expect(row('Brouillons')[1]).toBe(2);
    expect(row('Exclues')[1]).toBe(1);
    expect(row('Refus comptés')[1]).toBe(2);
  });
  it('l\'avertissement « enquête exploratoire » figure dans la feuille', () => {
    expect(String(row('AVERTISSEMENT')[1])).toMatch(/exploratoire/);
    expect(String(row('AVERTISSEMENT')[1])).toMatch(/ni autorisé ni lancé/);
  });
  it('aucun pourcentage quand la base est vide (pas de division par zéro)', () => {
    const empty = buildSummarySheet({ ...summary, buyers_often_difficulty: { n: 0, d: 0 } }, null);
    expect(empty.rows.find((r) => String(r[0]).startsWith('Acheteurs : difficultés'))![3]).toBe('');
  });
});

describe('Nom de fichier', () => {
  it('retire accents et caractères interdits', () => {
    expect(safeFileName('Mission pilote — Cococodji / Été')).toBe('Mission_pilote_Cococodji_Ete');
    expect(safeFileName('///')).toBe('export');
  });
});

describe('XLSX (relu avec un lecteur indépendant : openpyxl)', () => {
  it('produit un classeur valide : feuilles, en-têtes, nombres numériques, texte dangereux neutralisé', async () => {
    const d = buildDatasets(data, ctx);
    const blob = await toXlsxBlob([buildSummarySheet(summary, null), d.buyers, d.vendors, d.observations, d.candidates, d.evaluations]);
    const file = path.join(fs.mkdtempSync(path.join(os.tmpdir(), 'xlsx-')), 'test.xlsx');
    fs.writeFileSync(file, Buffer.from(await blob.arrayBuffer()));
    const py = `
import json, sys, openpyxl
wb = openpyxl.load_workbook(sys.argv[1])
out = {'sheets': wb.sheetnames}
b = wb['Acheteurs']
out['buyer_headers'] = [c.value for c in b[1]]
out['buyer_row_ids'] = [r[0].value for r in b.iter_rows(min_row=2)]
hdr = out['buyer_headers']
r = [row for row in b.iter_rows(min_row=2) if row[0].value == 'b2'][0]
out['b2_remark'] = r[hdr.index('Q13 Remarque ou suggestion')].value
out['b2_remark_type'] = r[hdr.index('Q13 Remarque ou suggestion')].data_type
r1 = [row for row in b.iter_rows(min_row=2) if row[0].value == 'b1'][0]
out['b1_amount'] = r1[hdr.index('Q10 Autre montant (FCFA)')].value
out['b1_amount_type'] = r1[hdr.index('Q10 Autre montant (FCFA)')].data_type
out['b1_freq'] = r1[hdr.index('Q2 Fréquence des difficultés')].value
o = wb['Observations']
oh = [c.value for c in o[1]]
out['obs_people'] = [row for row in o.iter_rows(min_row=2)][0][oh.index('Personnes passant dans la zone (approx.)')].value
z = wb['Zones candidates']
zh = [c.value for c in z[1]]
out['zone_codes'] = [row[0].value for row in z.iter_rows(min_row=2)]
out['zone_total'] = [row for row in z.iter_rows(min_row=2)][0][zh.index('Total des moyennes (sur 35)')].value
s = wb['Synthèse']
out['summary_rows'] = [[c.value for c in row] for row in s.iter_rows(min_row=2, max_row=20)]
out['frozen'] = b.freeze_panes
out['has_formula'] = any(isinstance(c.value, str) and c.value.startswith('=') for ws in wb for row in ws.iter_rows() for c in row)
print(json.dumps(out, ensure_ascii=False))
`;
    const res = spawnSync('python3', ['-I', '-c', py, file], { encoding: 'utf8' });
    expect(res.status, res.stderr).toBe(0);
    const out = JSON.parse(res.stdout);
    expect(out.sheets).toEqual(['Synthèse', 'Acheteurs', 'Commerçantes', 'Observations', 'Zones candidates', 'Évaluations détaillées']);
    expect(out.buyer_headers).toEqual(d.buyers.headers);
    expect(out.buyer_row_ids.sort()).toEqual(['b1', 'b2']);
    expect(out.b1_amount).toBe(150);
    expect(out.b1_amount_type).toBe('n'); // vrai nombre, pas du texte
    expect(out.b1_freq).toBe('Presque à chaque visite');
    expect(out.b2_remark).toBe(`'=HYPERLINK("http://x")`);
    expect(out.b2_remark_type).toBe('s'); // texte, jamais une formule
    expect(out.has_formula).toBe(false);
    expect(out.obs_people).toBe(120);
    expect(out.zone_codes).toEqual(['Z01', 'Z02']);
    expect(out.zone_total).toBe(24);
    expect(out.summary_rows.some((r: unknown[]) => String(r[0]).includes('intérêt déclaré') && r[1] === 4 && r[2] === 7 && r[3] === 57)).toBe(true);
    expect(out.frozen).toBe('A2'); // en-têtes figés
  });
});
