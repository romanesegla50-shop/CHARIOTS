# Cococodji Chariots — Enquête terrain

Application web (PWA) en français pour l'enquête exploratoire sur un éventuel service de chariots au marché de Cococodji.
**Projet à l'étude : ni autorisé ni lancé.** L'application ne dit jamais le contraire.

## Ce que fait l'application
- Comptes individuels : ADMINISTRATEUR et ENQUETEUR (jamais de compte partagé). Un nouveau compte est inactif tant que l'admin ne l'active pas.
- Enquêteur : questionnaire acheteur (avec consentement ; un refus n'enregistre rien d'autre qu'un compteur anonyme), questionnaire commerçante, grille d'observation (15 min), évaluation des emplacements candidats (7 critères de 1 à 5).
- Hors ligne : les fiches sont gardées sur le téléphone (IndexedDB) puis envoyées toutes seules, sans doublon (identifiant unique créé sur le téléphone). États : « Enregistré sur ce téléphone », « En attente de synchronisation », « Synchronisé », « Erreur de synchronisation ».
- Administrateur (onglet « Plus ») : mission, équipe, zones (jusqu'à 3 candidates, validation explicite), réponses (voir, corriger, exclure, supprimer, avec journal), résultats (chaque % avec n et base, avertissement obligatoire), exports CSV / XLSX / rapport PDF.
- Base centrale partagée : Supabase (PostgreSQL) avec règles d'accès par ligne (RLS). Aucune clé secrète dans le navigateur.

## Installation locale
```
npm install
cp .env.example .env.local     # puis renseigner les 2 variables (voir ci-dessous)
npm run dev                    # http://localhost:3000
```
Variables (toutes deux publiques, jamais la clé « service_role ») :
- `NEXT_PUBLIC_SUPABASE_URL` — Project Settings > API > Project URL
- `NEXT_PUBLIC_SUPABASE_ANON_KEY` — Project Settings > API > clé « anon public »

## Mise en ligne — pas à pas (coût : 0 € en offre gratuite)
1. **Supabase** (supabase.com, offre Free) : New project, choisir un mot de passe de base, région proche (ex. Europe).
2. **Base** : menu SQL Editor > New query > coller `supabase/migrations/001_schema.sql` > Run. Message de succès attendu.
3. **Comptes** : Authentication > Users > Add user > Create new user, e-mail + mot de passe, cocher **Auto Confirm User**. Un compte par personne (vous + chaque enquêteur).
   Authentication > Sign In / Providers : désactiver « Allow new users to sign up » pour que personne d'autre ne puisse créer de compte.
4. **Activation** : ouvrir `supabase/migrations/002_equipe.sql`, remplacer les e-mails par les vôtres (le vôtre dans la liste admin), puis le lancer dans le SQL Editor. Vous pouvez ensuite activer d'autres comptes depuis l'app (Plus > Équipe).
5. **Hébergement** : mettre le dossier sur GitHub, puis vercel.com > Add New Project > importer, ajouter les 2 variables d'environnement, Deploy. Vous obtenez une adresse https à partager.
6. **Téléphones** : ouvrir l'adresse dans Chrome, se connecter UNE FOIS avec réseau, puis menu > « Ajouter à l'écran d'accueil ». Ouvrir l'app une fois en ligne avant d'aller sur le terrain.

Coûts : Supabase Free et Vercel Hobby sont gratuits. Un projet Supabase gratuit est mis en pause après environ une semaine sans activité (réactivable d'un clic) : ouvrez-le la veille de la mission. Nom de domaine : optionnel (payant).

## Essai avec deux téléphones (à faire avant la mission)
1. Téléphone 1 : connecté en enquêteur. Téléphone 2 (ou ordinateur) : connecté en administrateur.
2. Sur le 1 : saisir 1 fiche acheteur, 1 commerçante, 1 observation avec réseau. Vérifier « Synchronisé ».
3. Sur le 2 : Plus > Réponses : les 3 fiches apparaissent. Plus > Résultats : les nombres sont corrects.
4. Sur le 1 : couper données mobiles et Wi-Fi, saisir une fiche, vérifier « En attente de synchronisation », rallumer le réseau : elle passe à « Synchronisé » et n'apparaît qu'une fois côté admin.
5. Plus > Export : télécharger CSV, XLSX, PDF et les ouvrir.
6. **Supprimer les données d'essai** : Plus > Réponses > Supprimer sur chaque fiche d'essai (trace conservée dans le journal), ou dans le SQL Editor : `delete from public.buyer_responses; delete from public.vendor_responses; delete from public.observation_sessions; delete from public.zone_evaluations; delete from public.refusals;`

## Limites à connaître
- Hors ligne : la page doit avoir été ouverte au moins une fois avec réseau (puis elle est en cache). La connexion initiale exige du réseau. Si le téléphone est vidé/réinitialisé avant l'envoi, les fiches non envoyées sont perdues : synchroniser chaque soir. Sur iPhone, le stockage d'un site peut être purgé s'il n'est pas utilisé pendant des semaines.
- Les comptes se créent dans le tableau de bord Supabase (l'app n'embarque volontairement aucune clé secrète).
- Les « participants » d'une mission sont informatifs (l'accès est contrôlé par le rôle et l'activation).
- Conflit de modification : si deux personnes modifient la même fiche, la seconde reçoit un message de conflit et doit recharger.
- Statistiques : exploratoires, non représentatives. Intérêt déclaré ≠ volonté de payer ≠ usage réel ≠ rentabilité.

## Sauvegarde, export, récupération
- Avant et après chaque journée : Plus > Export (CSV + XLSX), à garder sur ordinateur et clé USB.
- Sauvegarde complète : Supabase > Database > Backups (selon l'offre) ou `pg_dump` ; sinon les CSV font foi.
- Récupération : relancer `001_schema.sql` sur un nouveau projet (script rejouable), recréer les comptes, ré-importer au besoin depuis les CSV.
- Fiche supprimée par erreur : son contenu complet reste dans le journal (Plus > Journal).

## Tests
```
npm run test:db      # 89 tests PostgreSQL réel (PGlite) : RLS, doublons, conflits, audit, stats
npx vitest run       # 88 tests : formulaires, synchro, exports CSV/XLSX, rapport PDF
node tests/e2e/field.e2e.mjs        # 55 vérifications navigateur, téléphone 360 px, hors ligne
node tests/e2e/two-phones.e2e.mjs   # 15 vérifications : saisie sur A, lecture/exports/suppression sur B
```
Résultats détaillés : `tests/results.md`, `tests/results-e2e.md`.
**Important** : ces tests utilisent un vrai moteur PostgreSQL local et des serveurs simulés. Ils n'ont PAS été exécutés contre un vrai projet Supabase ni sur de vrais téléphones : faites l'essai ci-dessus avant la mission.

## Structure
`app/` page unique + styles · `components/` écrans (`screens/`, `admin/`) · `lib/` formulaires, synchro, base locale, exports, rapport · `public/` PWA (sw.js, manifest, icônes) · `supabase/migrations/` scripts SQL · `tests/`.
