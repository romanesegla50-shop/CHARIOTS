-- =====================================================================
-- COCOCODJI CHARIOTS — ENQUÊTE TERRAIN
-- Script 001 : tables, sécurité (RLS), audit, synthèse
--
-- Comment l'utiliser : Supabase > SQL Editor > New query > coller TOUT
-- ce fichier > Run. Il peut être relancé sans risque (il ne supprime rien).
--
-- Choix de conception (modifiables, voir le guide) :
--  * Un enquêteur ne lit que SES propres réponses. L'administrateur lit tout.
--    Les enquêteurs voient seulement des compteurs d'équipe (fonctions
--    team_progress et mission_overview), jamais le contenu des autres.
--  * Un enquêteur ne modifie que ses BROUILLONS. Une réponse soumise ne peut
--    plus être modifiée que par l'administrateur, et chaque modification est
--    enregistrée dans audit_log (avant / après).
--  * Un nouveau compte est INACTIF tant que l'administrateur ne l'active pas
--    (voir 002_equipe.sql). Un inconnu qui s'inscrirait ne peut rien lire
--    ni rien écrire.
--  * Aucune réponse n'est enregistrée sans consentement (contrainte SQL).
--    Un refus ne crée qu'une ligne dans « refusals » (compteur sans donnée).
-- =====================================================================


-- ---------------------------------------------------------------------
-- 1. PROFILS ET RÔLES
-- ---------------------------------------------------------------------
create table if not exists public.profiles (
  id         uuid primary key references auth.users(id) on delete cascade,
  email      text,
  full_name  text not null default '' check (char_length(full_name) <= 120),
  role       text not null default 'ENQUETEUR'
             check (role in ('ADMINISTRATEUR', 'ENQUETEUR')),
  active     boolean not null default false,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

-- Création automatique du profil à chaque nouveau compte (inactif par défaut)
create or replace function public.handle_new_user()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
begin
  insert into public.profiles (id, email, full_name)
  values (new.id, new.email, coalesce(new.raw_user_meta_data ->> 'full_name', ''))
  on conflict (id) do nothing;
  return new;
end;
$$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created
  after insert on auth.users
  for each row execute function public.handle_new_user();

-- Comptes déjà existants (si vous les avez créés avant de lancer ce script)
insert into public.profiles (id, email, full_name)
select u.id, u.email, coalesce(u.raw_user_meta_data ->> 'full_name', '')
from auth.users u
on conflict (id) do nothing;

-- Fonctions d'aide aux règles de sécurité
create or replace function public.is_active_user()
returns boolean
language sql stable security definer
set search_path = public
as $$
  select exists (select 1 from public.profiles p where p.id = auth.uid() and p.active);
$$;

create or replace function public.is_admin()
returns boolean
language sql stable security definer
set search_path = public
as $$
  select exists (
    select 1 from public.profiles p
    where p.id = auth.uid() and p.active and p.role = 'ADMINISTRATEUR'
  );
$$;

-- Garde-fous sur les profils : un administrateur ne peut pas se retirer
-- lui-même ses droits (évite de se verrouiller hors de l'application).
create or replace function public.tg_profiles_guard()
returns trigger
language plpgsql
as $$
begin
  if new.id <> old.id then
    raise exception 'Identifiant de profil non modifiable' using errcode = '42501';
  end if;
  if old.id = auth.uid() and (new.role <> 'ADMINISTRATEUR' or new.active = false) then
    raise exception 'Vous ne pouvez pas retirer vos propres droits d''administrateur'
      using errcode = '42501';
  end if;
  new.updated_at := now();
  return new;
end;
$$;

drop trigger if exists tg_profiles_guard on public.profiles;
create trigger tg_profiles_guard
  before update on public.profiles
  for each row execute function public.tg_profiles_guard();


-- ---------------------------------------------------------------------
-- 2. MISSIONS, ÉQUIPE, ZONES
-- ---------------------------------------------------------------------
create table if not exists public.missions (
  id                  uuid primary key default gen_random_uuid(),
  name                text not null check (char_length(name) between 1 and 200),
  start_date          date,
  end_date            date,
  status              text not null default 'PREPARATION'
                      check (status in ('PREPARATION', 'EN_COURS', 'EN_ANALYSE', 'TERMINEE')),
  instructions        text check (char_length(instructions) <= 5000),
  target_buyers       integer not null default 30 check (target_buyers >= 0),
  target_vendors      integer not null default 15 check (target_vendors >= 0),
  target_observations integer not null default 0 check (target_observations >= 0),
  created_by          uuid references public.profiles(id) default auth.uid(),
  created_at          timestamptz not null default now(),
  updated_at          timestamptz not null default now(),
  check (end_date is null or start_date is null or end_date >= start_date)
);
comment on table public.missions is
  'Objectifs exploratoires (pas des quotas, pas une garantie de représentativité).';

create table if not exists public.mission_members (
  mission_id uuid not null references public.missions(id) on delete cascade,
  user_id    uuid not null references public.profiles(id) on delete cascade,
  created_at timestamptz not null default now(),
  primary key (mission_id, user_id)
);

create table if not exists public.zones (
  id              uuid primary key default gen_random_uuid(),
  mission_id      uuid not null references public.missions(id) on delete cascade,
  code            text not null check (code ~ '^[A-Za-z0-9_-]{1,10}$'),
  label           text check (char_length(label) <= 120),
  description     text check (char_length(description) <= 1000),
  sector          text check (char_length(sector) <= 120),
  -- Module E : jusqu'à 3 zones candidates, jamais « validée » sans l'administrateur
  is_candidate    boolean not null default false,
  approval_status text not null default 'NON_VALIDE'
                  check (approval_status in ('NON_VALIDE', 'VALIDE')),
  approved_by     uuid references public.profiles(id),
  approved_at     timestamptz,
  -- Points à confirmer auprès du gestionnaire (espace, stationnement, trajets,
  -- horaires, règles de sécurité, frais) : objet JSON libre côté application.
  manager_checks  jsonb not null default '{}'::jsonb
                  check (jsonb_typeof(manager_checks) = 'object'),
  created_at      timestamptz not null default now(),
  updated_at      timestamptz not null default now(),
  unique (mission_id, code),
  unique (id, mission_id),
  check (approval_status = 'NON_VALIDE' or is_candidate)
);

create or replace function public.tg_zones_guard()
returns trigger
language plpgsql
as $$
begin
  new.code := upper(btrim(new.code));
  new.updated_at := now();
  if new.approval_status = 'VALIDE'
     and (tg_op = 'INSERT' or old.approval_status <> 'VALIDE') then
    new.approved_by := auth.uid();
    new.approved_at := now();
  elsif new.approval_status = 'NON_VALIDE' then
    new.approved_by := null;
    new.approved_at := null;
  end if;
  if new.is_candidate and (
       select count(*) from public.zones z
       where z.mission_id = new.mission_id and z.is_candidate and z.id <> new.id
     ) >= 3 then
    raise exception 'Maximum 3 zones candidates par mission' using errcode = '23514';
  end if;
  return new;
end;
$$;

drop trigger if exists tg_zones_guard on public.zones;
create trigger tg_zones_guard
  before insert or update on public.zones
  for each row execute function public.tg_zones_guard();

create or replace function public.tg_touch_updated_at()
returns trigger
language plpgsql
as $$
begin
  new.updated_at := now();
  return new;
end;
$$;

drop trigger if exists tg_touch_updated_at on public.missions;
create trigger tg_touch_updated_at
  before update on public.missions
  for each row execute function public.tg_touch_updated_at();


-- ---------------------------------------------------------------------
-- 3. QUESTIONNAIRE ACHETEUR (Module B)
--    id = identifiant créé sur le téléphone : il sert de clé anti-doublon.
--    version = numéro de version pour détecter les conflits de modification.
--    client_rev = identifiant de la dernière sauvegarde faite par le téléphone
--                 (permet de reconnaître un renvoi déjà reçu par le serveur).
-- ---------------------------------------------------------------------
create table if not exists public.buyer_responses (
  id            uuid primary key,
  mission_id    uuid not null references public.missions(id),
  zone_id       uuid,
  surveyor_id   uuid not null references public.profiles(id) default auth.uid(),
  status        text not null default 'BROUILLON'
                check (status in ('BROUILLON', 'SOUMIS', 'EXCLU')),
  consent       boolean not null check (consent is true),
  form_version  text not null default 'acheteur-v1',
  started_at    timestamptz,
  ended_at      timestamptz,

  q1_transporte      text check (q1_transporte in ('OUI', 'NON')),
  q2_frequence       text check (q2_frequence in
                       ('JAMAIS', 'RAREMENT', 'PARFOIS', 'SOUVENT', 'PRESQUE_CHAQUE_VISITE')),
  q3_difficultes     text[] check (q3_difficultes <@ array[
                       'CHARGES_LOURDES', 'PLUSIEURS_SACS', 'VOLUMINEUX', 'DISTANCE',
                       'PLUSIEURS_TRAJETS', 'MAINS_OCCUPEES', 'AUTRE']::text[]),
  q3_autre           text check (char_length(q3_autre) <= 200),
  q4_mode_transport  text check (q4_mode_transport in
                       ('A_LA_MAIN', 'AIDE_PROCHE', 'PORTEUR_PAYE', 'CHARIOT_DEJA', 'AUTRE')),
  q4_autre           text check (char_length(q4_autre) <= 200),
  q5_nb_trajets      text check (q5_nb_trajets in
                       ('1', '2', '3_OU_PLUS', 'VARIABLE', 'NE_SAIT_PAS')),
  q6_utilisation     text check (q6_utilisation in
                       ('CERTAINEMENT', 'PROBABLEMENT', 'PAS_SUR', 'PROBABLEMENT_PAS', 'CERTAINEMENT_PAS')),
  q7_trajet_utile    text check (q7_trajet_utile in
                       ('ENTRE_ETALS', 'ETALS_SORTIE', 'ETALS_PARKING', 'AUTRE')),
  q7_autre           text check (char_length(q7_autre) <= 200),
  q8_moment_utile    text check (q8_moment_utile in
                       ('TOUTE_VISITE', 'APRES_ACHATS', 'HEURES_AFFLUENCE', 'SELON_SECTEUR', 'AUTRE')),
  q8_autre           text check (char_length(q8_autre) <= 200),
  q9_paiement        text check (q9_paiement in
                       ('PRIX_FIXE', 'SELON_DUREE', 'AUTRE', 'AUCUN')),
  q9_autre           text check (char_length(q9_autre) <= 200),
  q10_prix           text check (q10_prix in
                       ('100', '200', '300', 'AUTRE_MONTANT', 'NE_PAIERAIT_PAS')),
  q10_montant_fcfa   integer check (q10_montant_fcfa between 0 and 1000000),
  q10_ordre_options  text check (char_length(q10_ordre_options) <= 80),
  q11_caution        text check (q11_caution in ('OUI', 'NON', 'DEPEND_MONTANT', 'NE_SAIT_PAS')),
  q12_inquietude     text check (q12_inquietude in
                       ('DISPONIBILITE', 'PRIX', 'SECURITE', 'MANIABILITE', 'OU_RENDRE', 'AUCUNE', 'AUTRE')),
  q12_autre          text check (char_length(q12_autre) <= 200),
  q13_remarque       text check (char_length(q13_remarque) <= 1000),

  created_at    timestamptz not null default now(),
  updated_at    timestamptz not null default now(),
  synced_at     timestamptz not null default now(),
  submitted_at  timestamptz,
  version       integer not null default 1,
  client_rev    uuid,

  foreign key (zone_id, mission_id) references public.zones (id, mission_id),
  check (ended_at is null or started_at is null or ended_at >= started_at),
  constraint buyer_complete_when_submitted check (
    status <> 'SOUMIS' or coalesce((
      zone_id is not null
      and q1_transporte is not null
      and q2_frequence is not null
      and q3_difficultes is not null and cardinality(q3_difficultes) > 0
      and q4_mode_transport is not null
      and q5_nb_trajets is not null
      and q6_utilisation is not null
      and q7_trajet_utile is not null
      and q8_moment_utile is not null
      and q9_paiement is not null
      and q10_prix is not null
      and q11_caution is not null
      and q12_inquietude is not null
      and (q10_prix <> 'AUTRE_MONTANT' or q10_montant_fcfa is not null)
      and (not ('AUTRE' = any (q3_difficultes)) or nullif(btrim(q3_autre), '') is not null)
    ), false)
  )
);


-- ---------------------------------------------------------------------
-- 4. QUESTIONNAIRE COMMERÇANTE (Module C)
--    Q2 et Q6 acceptent plusieurs réponses (tableaux) : le cahier des
--    charges parle de « produits » et de « risques » au pluriel.
-- ---------------------------------------------------------------------
create table if not exists public.vendor_responses (
  id            uuid primary key,
  mission_id    uuid not null references public.missions(id),
  zone_id       uuid,
  surveyor_id   uuid not null references public.profiles(id) default auth.uid(),
  status        text not null default 'BROUILLON'
                check (status in ('BROUILLON', 'SOUMIS', 'EXCLU')),
  consent       boolean not null check (consent is true),
  form_version  text not null default 'commercante-v1',
  started_at    timestamptz,
  ended_at      timestamptz,

  q1_difficultes_clients text check (q1_difficultes_clients in
                   ('JAMAIS', 'RAREMENT', 'PARFOIS', 'SOUVENT', 'TRES_SOUVENT', 'NE_SAIT_PAS')),
  q2_produits            text[] check (q2_produits <@ array[
                   'SACS_PROVISIONS', 'PRODUITS_LOURDS', 'VOLUMINEUX', 'PLUSIEURS_ETALS', 'AUTRE']::text[]),
  q2_autre               text check (char_length(q2_autre) <= 200),
  q3_comportement        text check (q3_comportement in
                   ('PORTENT_EUX_MEMES', 'PLUSIEURS_TRAJETS', 'DEMANDENT_AIDE', 'PAIENT_PORTEUR', 'AUTRE')),
  q3_autre               text check (char_length(q3_autre) <= 200),
  q4_secteur_texte       text check (char_length(q4_secteur_texte) <= 500),
  q4_zone_id             uuid references public.zones(id),
  q5_moment              text check (q5_moment in
                   ('MATIN', 'MILIEU_JOURNEE', 'APRES_MIDI', 'FORTE_AFFLUENCE', 'VARIABLE')),
  q6_risques             text[] check (q6_risques <@ array[
                   'ENCOMBREMENT', 'CIRCULATION', 'VOL_PERTE', 'CONFLIT', 'SALETE', 'AUCUN', 'AUTRE']::text[]),
  q6_autre               text check (char_length(q6_autre) <= 200),
  q7_utiliseraient       text check (q7_utiliseraient in ('OUI', 'NON', 'INCERTAIN')),
  q8_pourquoi            text check (char_length(q8_pourquoi) <= 1000),
  q9_suggestion          text check (char_length(q9_suggestion) <= 1000),

  created_at    timestamptz not null default now(),
  updated_at    timestamptz not null default now(),
  synced_at     timestamptz not null default now(),
  submitted_at  timestamptz,
  version       integer not null default 1,
  client_rev    uuid,

  foreign key (zone_id, mission_id) references public.zones (id, mission_id),
  check (ended_at is null or started_at is null or ended_at >= started_at),
  constraint vendor_complete_when_submitted check (
    status <> 'SOUMIS' or coalesce((
      zone_id is not null
      and q1_difficultes_clients is not null
      and q2_produits is not null and cardinality(q2_produits) > 0
      and q3_comportement is not null
      and q5_moment is not null
      and q6_risques is not null and cardinality(q6_risques) > 0
      and q7_utiliseraient is not null
    ), false)
  )
);


-- ---------------------------------------------------------------------
-- 5. OBSERVATIONS DE FLUX (Module D)
--    Observations ponctuelles : pas un comptage complet du marché,
--    aucune identification des passants, aucune photo.
-- ---------------------------------------------------------------------
create table if not exists public.observation_sessions (
  id            uuid primary key,
  mission_id    uuid not null references public.missions(id),
  zone_id       uuid not null,
  surveyor_id   uuid not null references public.profiles(id) default auth.uid(),
  status        text not null default 'BROUILLON'
                check (status in ('BROUILLON', 'SOUMIS', 'EXCLU')),
  form_version  text not null default 'observation-v1',

  observed_on   date,
  start_time    time,
  end_time      time,
  people_count          integer check (people_count between 0 and 100000),
  heavy_load_count      integer check (heavy_load_count between 0 and 100000),
  multiple_trips_count  integer check (multiple_trips_count between 0 and 100000),
  help_or_porter_count  integer check (help_or_porter_count between 0 and 100000),
  flow_level    text check (flow_level in ('FAIBLE', 'MOYEN', 'FORT')),
  obstacles     text[] check (obstacles <@ array[
                  'AUCUN', 'ETROITURES', 'MARCHES', 'PENTE', 'SOL_IRREGULIER', 'AUTRE']::text[]
                  and not ('AUCUN' = any (obstacles) and cardinality(obstacles) > 1)),
  obstacles_autre text check (char_length(obstacles_autre) <= 200),
  distance_exit_m integer check (distance_exit_m between 0 and 5000),
  trolley_access  text check (trolley_access in
                    ('PROBABLEMENT_ACCESSIBLE', 'DIFFICILE', 'A_VERIFIER')),
  congestion_risk text check (congestion_risk in ('FAIBLE', 'MOYEN', 'ELEVE', 'A_VERIFIER')),
  comments      text check (char_length(comments) <= 1000),

  created_at    timestamptz not null default now(),
  updated_at    timestamptz not null default now(),
  synced_at     timestamptz not null default now(),
  submitted_at  timestamptz,
  version       integer not null default 1,
  client_rev    uuid,

  foreign key (zone_id, mission_id) references public.zones (id, mission_id),
  check (end_time is null or start_time is null or end_time > start_time),
  constraint observation_complete_when_submitted check (
    status <> 'SOUMIS' or coalesce((
      observed_on is not null and start_time is not null and end_time is not null
      and people_count is not null
      and flow_level is not null
      and obstacles is not null and cardinality(obstacles) > 0
      and trolley_access is not null
      and congestion_risk is not null
    ), false)
  )
);

-- Empêche de saisir deux fois la même session (même enquêteur, zone, jour, heure de début)
create unique index if not exists observation_sessions_no_double_entry
  on public.observation_sessions (surveyor_id, zone_id, observed_on, start_time)
  where start_time is not null and status <> 'EXCLU';


-- ---------------------------------------------------------------------
-- 6. ÉVALUATION DES EMPLACEMENTS CANDIDATS (Module E)
--    Score = outil de comparaison interne, PAS une autorisation d'occupation.
-- ---------------------------------------------------------------------
create table if not exists public.zone_evaluations (
  id            uuid primary key,
  mission_id    uuid not null references public.missions(id),
  zone_id       uuid not null,
  surveyor_id   uuid not null references public.profiles(id) default auth.uid(),
  status        text not null default 'BROUILLON'
                check (status in ('BROUILLON', 'SOUMIS', 'EXCLU')),
  form_version  text not null default 'evaluation-v1',

  score_flux             smallint check (score_flux between 1 and 5),
  score_zones_lourdes    smallint check (score_zones_lourdes between 1 and 5),
  score_acces_sortie     smallint check (score_acces_sortie between 1 and 5),
  score_passage          smallint check (score_passage between 1 and 5),
  score_retour_chariots  smallint check (score_retour_chariots between 1 and 5),
  score_surveillance     smallint check (score_surveillance between 1 and 5),
  score_faible_encombrement smallint check (score_faible_encombrement between 1 and 5),
  notes         text check (char_length(notes) <= 2000),

  created_at    timestamptz not null default now(),
  updated_at    timestamptz not null default now(),
  synced_at     timestamptz not null default now(),
  submitted_at  timestamptz,
  version       integer not null default 1,
  client_rev    uuid,

  foreign key (zone_id, mission_id) references public.zones (id, mission_id),
  unique (zone_id, surveyor_id),
  constraint evaluation_complete_when_submitted check (
    status <> 'SOUMIS' or coalesce((
      score_flux is not null and score_zones_lourdes is not null
      and score_acces_sortie is not null and score_passage is not null
      and score_retour_chariots is not null and score_surveillance is not null
      and score_faible_encombrement is not null
    ), false)
  )
);


-- ---------------------------------------------------------------------
-- 7. COMPTEUR DE REFUS (aucune donnée personnelle, aucune réponse)
-- ---------------------------------------------------------------------
create table if not exists public.refusals (
  id          uuid primary key,
  mission_id  uuid not null references public.missions(id),
  zone_id     uuid,
  surveyor_id uuid not null references public.profiles(id) default auth.uid(),
  form_type   text not null check (form_type in ('ACHETEUR', 'COMMERCANT')),
  created_at  timestamptz not null default now(),
  synced_at   timestamptz not null default now(),
  foreign key (zone_id, mission_id) references public.zones (id, mission_id)
);


-- ---------------------------------------------------------------------
-- 8. JOURNAL D'AUDIT (lecture administrateur uniquement, non modifiable)
-- ---------------------------------------------------------------------
create table if not exists public.audit_log (
  id         bigint generated always as identity primary key,
  at         timestamptz not null default now(),
  actor_id   uuid,
  actor_role text,
  table_name text not null,
  record_id  text,
  action     text not null,
  old_data   jsonb,
  new_data   jsonb
);
create index if not exists audit_log_record_idx on public.audit_log (table_name, record_id);
create index if not exists audit_log_at_idx on public.audit_log (at desc);

create or replace function public.audit_row()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
declare
  v_old  jsonb;
  v_new  jsonb;
  v_role text;
begin
  if tg_op = 'INSERT' then
    v_new := to_jsonb(new);
  elsif tg_op = 'UPDATE' then
    v_old := to_jsonb(old);
    v_new := to_jsonb(new);
    -- Les sauvegardes successives d'un brouillon ne sont pas tracées
    if v_old ->> 'status' = 'BROUILLON' and v_new ->> 'status' = 'BROUILLON' then
      return new;
    end if;
  else
    v_old := to_jsonb(old);
  end if;

  select p.role into v_role from public.profiles p where p.id = auth.uid();

  insert into public.audit_log (actor_id, actor_role, table_name, record_id, action, old_data, new_data)
  values (
    auth.uid(), v_role, tg_table_name,
    coalesce(v_new ->> 'id', v_old ->> 'id', coalesce(v_new, v_old) ->> 'user_id'),
    tg_op, v_old, v_new
  );
  return null;
end;
$$;

-- Contrôle des écritures sur les 4 tables de collecte :
--  * version forcée à 1 à la création
--  * à la modification : refus si la version envoyée n'est pas celle du serveur
--    (= quelqu'un d'autre a modifié entre-temps -> conflit explicite, jamais d'écrasement silencieux)
--  * l'auteur, la mission et la date de création ne changent jamais
create or replace function public.tg_before_write()
returns trigger
language plpgsql
as $$
begin
  if tg_op = 'INSERT' then
    new.version := 1;
    new.updated_at := now();
    new.synced_at := now();
    if new.status = 'SOUMIS' then
      new.submitted_at := now();
    end if;
    return new;
  end if;

  if new.id <> old.id or new.surveyor_id <> old.surveyor_id
     or new.mission_id <> old.mission_id or new.created_at <> old.created_at then
    raise exception 'Champs non modifiables (identifiant, enquêteur, mission, date de création)'
      using errcode = '42501';
  end if;

  if new.version is distinct from old.version then
    raise exception 'CONFLIT_VERSION: cette fiche a été modifiée ailleurs (version serveur %, version envoyée %)',
      old.version, new.version
      using errcode = 'PT409';
  end if;

  new.version := old.version + 1;
  new.updated_at := now();
  new.synced_at := now();
  if new.status = 'SOUMIS' and old.status <> 'SOUMIS' then
    new.submitted_at := now();
  end if;
  return new;
end;
$$;

do $$
declare
  t text;
begin
  foreach t in array array['buyer_responses', 'vendor_responses', 'observation_sessions', 'zone_evaluations']
  loop
    execute format('drop trigger if exists tg_before_write on public.%I', t);
    execute format('create trigger tg_before_write before insert or update on public.%I
                    for each row execute function public.tg_before_write()', t);
    execute format('drop trigger if exists tg_audit on public.%I', t);
    execute format('create trigger tg_audit after update or delete on public.%I
                    for each row execute function public.audit_row()', t);
  end loop;

  foreach t in array array['missions', 'zones', 'profiles', 'mission_members', 'refusals']
  loop
    execute format('drop trigger if exists tg_audit on public.%I', t);
    execute format('create trigger tg_audit after insert or update or delete on public.%I
                    for each row execute function public.audit_row()', t);
  end loop;
end;
$$;


-- ---------------------------------------------------------------------
-- 9. INDEX
-- ---------------------------------------------------------------------
create index if not exists buyer_responses_idx on public.buyer_responses (mission_id, status, zone_id);
create index if not exists buyer_responses_surveyor_idx on public.buyer_responses (surveyor_id);
create index if not exists vendor_responses_idx on public.vendor_responses (mission_id, status, zone_id);
create index if not exists vendor_responses_surveyor_idx on public.vendor_responses (surveyor_id);
create index if not exists observation_sessions_idx on public.observation_sessions (mission_id, status, zone_id);
create index if not exists observation_sessions_surveyor_idx on public.observation_sessions (surveyor_id);
create index if not exists zone_evaluations_idx on public.zone_evaluations (mission_id, status);
create index if not exists refusals_idx on public.refusals (mission_id);


-- ---------------------------------------------------------------------
-- 10. SÉCURITÉ : RLS (règles d'accès appliquées par la base elle-même)
-- ---------------------------------------------------------------------
alter table public.profiles        enable row level security;
alter table public.missions        enable row level security;
alter table public.mission_members enable row level security;
alter table public.zones           enable row level security;
alter table public.refusals        enable row level security;
alter table public.audit_log       enable row level security;

-- Profils : chacun voit le sien, l'administrateur voit et gère tout
drop policy if exists profiles_select on public.profiles;
create policy profiles_select on public.profiles for select to authenticated
  using (id = auth.uid() or public.is_admin());
drop policy if exists profiles_update on public.profiles;
create policy profiles_update on public.profiles for update to authenticated
  using (public.is_admin()) with check (public.is_admin());

-- Missions et zones : lecture par tout utilisateur actif, écriture par l'administrateur
drop policy if exists missions_select on public.missions;
create policy missions_select on public.missions for select to authenticated
  using (public.is_active_user());
drop policy if exists missions_write on public.missions;
create policy missions_write on public.missions for all to authenticated
  using (public.is_admin()) with check (public.is_admin());

drop policy if exists zones_select on public.zones;
create policy zones_select on public.zones for select to authenticated
  using (public.is_active_user());
drop policy if exists zones_write on public.zones;
create policy zones_write on public.zones for all to authenticated
  using (public.is_admin()) with check (public.is_admin());

drop policy if exists members_select on public.mission_members;
create policy members_select on public.mission_members for select to authenticated
  using (user_id = auth.uid() or public.is_admin());
drop policy if exists members_write on public.mission_members;
create policy members_write on public.mission_members for all to authenticated
  using (public.is_admin()) with check (public.is_admin());

-- Journal d'audit : lecture administrateur uniquement
drop policy if exists audit_select on public.audit_log;
create policy audit_select on public.audit_log for select to authenticated
  using (public.is_admin());

-- Refus : un enquêteur crée et voit les siens, l'administrateur voit et supprime tout
drop policy if exists refusals_select on public.refusals;
create policy refusals_select on public.refusals for select to authenticated
  using (public.is_admin() or (public.is_active_user() and surveyor_id = auth.uid()));
drop policy if exists refusals_insert on public.refusals;
create policy refusals_insert on public.refusals for insert to authenticated
  with check (public.is_active_user() and surveyor_id = auth.uid());
drop policy if exists refusals_delete on public.refusals;
create policy refusals_delete on public.refusals for delete to authenticated
  using (public.is_admin());

-- Les 4 tables de collecte suivent exactement les mêmes règles
do $$
declare
  t text;
begin
  foreach t in array array['buyer_responses', 'vendor_responses', 'observation_sessions', 'zone_evaluations']
  loop
    execute format('alter table public.%I enable row level security', t);

    execute format('drop policy if exists %I on public.%I', t || '_select', t);
    execute format($p$create policy %I on public.%I for select to authenticated
      using (public.is_admin() or (public.is_active_user() and surveyor_id = auth.uid()))$p$,
      t || '_select', t);

    execute format('drop policy if exists %I on public.%I', t || '_insert', t);
    execute format($p$create policy %I on public.%I for insert to authenticated
      with check (public.is_active_user() and surveyor_id = auth.uid()
                  and status in ('BROUILLON', 'SOUMIS'))$p$,
      t || '_insert', t);

    -- Enquêteur : seulement ses brouillons. Administrateur : tout (tracé dans audit_log).
    execute format('drop policy if exists %I on public.%I', t || '_update', t);
    execute format($p$create policy %I on public.%I for update to authenticated
      using (public.is_admin()
             or (public.is_active_user() and surveyor_id = auth.uid() and status = 'BROUILLON'))
      with check (public.is_admin()
             or (public.is_active_user() and surveyor_id = auth.uid()
                 and status in ('BROUILLON', 'SOUMIS')))$p$,
      t || '_update', t);

    execute format('drop policy if exists %I on public.%I', t || '_delete', t);
    execute format($p$create policy %I on public.%I for delete to authenticated
      using (public.is_admin()
             or (public.is_active_user() and surveyor_id = auth.uid() and status = 'BROUILLON'))$p$,
      t || '_delete', t);
  end loop;
end;
$$;

-- Droits de base : aucun accès pour les visiteurs non connectés
revoke all on all tables in schema public from anon;
revoke all on all sequences in schema public from anon;
revoke truncate, references, trigger on all tables in schema public from authenticated;
-- Le journal d'audit n'est jamais modifiable depuis l'application
revoke insert, update, delete on public.audit_log from authenticated;
-- Pas de création/suppression de profils depuis l'application
revoke insert, delete on public.profiles from authenticated;


-- ---------------------------------------------------------------------
-- 11. FONCTIONS : progression d'équipe, aperçu de mission, synthèse
-- ---------------------------------------------------------------------

-- Compteurs d'équipe visibles par tout utilisateur actif (jamais le contenu des fiches)
create or replace function public.team_progress(p_mission uuid)
returns table (
  surveyor_id uuid, surveyor_name text,
  buyers bigint, vendors bigint, observations bigint, evaluations bigint
)
language sql stable security definer
set search_path = public
as $$
  select p.id,
         coalesce(nullif(p.full_name, ''), split_part(p.email, '@', 1)),
         (select count(*) from public.buyer_responses r
            where r.surveyor_id = p.id and r.mission_id = p_mission and r.status = 'SOUMIS'),
         (select count(*) from public.vendor_responses r
            where r.surveyor_id = p.id and r.mission_id = p_mission and r.status = 'SOUMIS'),
         (select count(*) from public.observation_sessions r
            where r.surveyor_id = p.id and r.mission_id = p_mission and r.status = 'SOUMIS'),
         (select count(*) from public.zone_evaluations r
            where r.surveyor_id = p.id and r.mission_id = p_mission and r.status = 'SOUMIS')
  from public.profiles p
  where public.is_active_user() and p.active
  order by 2;
$$;

create or replace function public.mission_overview(p_mission uuid)
returns jsonb
language sql stable security definer
set search_path = public
as $$
  select case when not public.is_active_user() then null else jsonb_build_object(
    'buyers',       (select count(*) from public.buyer_responses where mission_id = p_mission and status = 'SOUMIS'),
    'vendors',      (select count(*) from public.vendor_responses where mission_id = p_mission and status = 'SOUMIS'),
    'observations', (select count(*) from public.observation_sessions where mission_id = p_mission and status = 'SOUMIS'),
    'zones_observed', (select count(distinct zone_id) from public.observation_sessions where mission_id = p_mission and status = 'SOUMIS'),
    'refusals',     (select count(*) from public.refusals where mission_id = p_mission),
    'target_buyers',       (select target_buyers from public.missions where id = p_mission),
    'target_vendors',      (select target_vendors from public.missions where id = p_mission),
    'target_observations', (select target_observations from public.missions where id = p_mission)
  ) end;
$$;

-- Synthèse du Module F : calculée uniquement sur les réponses SOUMISES (valides),
-- chaque pourcentage est rendu sous forme {n, d} (numérateur, dénominateur).
create or replace function public.survey_summary(
  p_mission  uuid,
  p_from     date default null,
  p_to       date default null,
  p_surveyor uuid default null,
  p_zone     uuid default null
)
returns jsonb
language plpgsql stable security definer
set search_path = public
as $$
declare
  result jsonb;
begin
  if not public.is_admin() then
    raise exception 'Accès réservé à l''administrateur' using errcode = '42501';
  end if;

  with ball as (
    select * from public.buyer_responses
    where mission_id = p_mission
      and (p_surveyor is null or surveyor_id = p_surveyor)
      and (p_zone is null or zone_id = p_zone)
      and (p_from is null or (coalesce(started_at, created_at) at time zone 'Africa/Porto-Novo')::date >= p_from)
      and (p_to   is null or (coalesce(started_at, created_at) at time zone 'Africa/Porto-Novo')::date <= p_to)
  ),
  vall as (
    select * from public.vendor_responses
    where mission_id = p_mission
      and (p_surveyor is null or surveyor_id = p_surveyor)
      and (p_zone is null or zone_id = p_zone)
      and (p_from is null or (coalesce(started_at, created_at) at time zone 'Africa/Porto-Novo')::date >= p_from)
      and (p_to   is null or (coalesce(started_at, created_at) at time zone 'Africa/Porto-Novo')::date <= p_to)
  ),
  oall as (
    select * from public.observation_sessions
    where mission_id = p_mission
      and (p_surveyor is null or surveyor_id = p_surveyor)
      and (p_zone is null or zone_id = p_zone)
      and (p_from is null or observed_on >= p_from)
      and (p_to   is null or observed_on <= p_to)
  ),
  b as (select * from ball where status = 'SOUMIS'),
  v as (select * from vall where status = 'SOUMIS'),
  o as (select * from oall where status = 'SOUMIS')
  select jsonb_build_object(
    'generated_at', now(),
    'basis', 'Réponses au statut SOUMIS uniquement (brouillons et exclues non comptés)',
    'filters', jsonb_build_object('from', p_from, 'to', p_to, 'surveyor', p_surveyor, 'zone', p_zone),

    'buyers_total',       (select count(*) from b),
    'vendors_total',      (select count(*) from v),
    'observations_total', (select count(*) from o),
    'zones_studied',      (select count(distinct zone_id) from o),

    'buyers_often_difficulty', jsonb_build_object(
      'n', (select count(*) from b where q2_frequence in ('SOUVENT', 'PRESQUE_CHAQUE_VISITE')),
      'd', (select count(*) from b)),
    'buyers_interested', jsonb_build_object(
      'n', (select count(*) from b where q6_utilisation in ('CERTAINEMENT', 'PROBABLEMENT')),
      'd', (select count(*) from b)),
    'buyers_two_trips_or_more', jsonb_build_object(
      'n', (select count(*) from b where q5_nb_trajets in ('2', '3_OU_PLUS')),
      'd', (select count(*) from b)),
    'vendors_clients_often_difficulty', jsonb_build_object(
      'n', (select count(*) from v where q1_difficultes_clients in ('SOUVENT', 'TRES_SOUVENT')),
      'd', (select count(*) from v)),
    'vendors_clients_would_use', jsonb_build_object(
      'n', (select count(*) from v where q7_utiliseraient = 'OUI'),
      'd', (select count(*) from v)),

    'price_distribution', (select coalesce(jsonb_object_agg(k, c), '{}'::jsonb)
                           from (select q10_prix as k, count(*) as c from b group by q10_prix) x),
    'price_other_amounts_fcfa', (select coalesce(jsonb_agg(q10_montant_fcfa order by q10_montant_fcfa), '[]'::jsonb)
                                 from b where q10_prix = 'AUTRE_MONTANT'),
    'deposit_reaction', (select coalesce(jsonb_object_agg(k, c), '{}'::jsonb)
                         from (select q11_caution as k, count(*) as c from b group by q11_caution) x),
    'difficulties', (select coalesce(jsonb_object_agg(k, c), '{}'::jsonb)
                     from (select d as k, count(*) as c from b, unnest(q3_difficultes) d group by d) x),
    'concerns', (select coalesce(jsonb_object_agg(k, c), '{}'::jsonb)
                 from (select q12_inquietude as k, count(*) as c from b group by q12_inquietude) x),
    'vendor_risks', (select coalesce(jsonb_object_agg(k, c), '{}'::jsonb)
                     from (select d as k, count(*) as c from v, unnest(q6_risques) d group by d) x),

    'zones', (select coalesce(jsonb_agg(zz.obj order by zz.code), '[]'::jsonb) from (
        select z.code,
          jsonb_build_object(
            'zone_id', z.id,
            'zone_code', z.code,
            'buyers', (select count(*) from b where b.zone_id = z.id),
            'buyers_often_difficulty', (select count(*) from b where b.zone_id = z.id
                                         and q2_frequence in ('SOUVENT', 'PRESQUE_CHAQUE_VISITE')),
            'buyers_interested', (select count(*) from b where b.zone_id = z.id
                                   and q6_utilisation in ('CERTAINEMENT', 'PROBABLEMENT')),
            'vendors', (select count(*) from v where v.zone_id = z.id),
            'observations', (select count(*) from o where o.zone_id = z.id),
            'observed_people_total', (select coalesce(sum(people_count), 0) from o where o.zone_id = z.id),
            'observed_heavy_loads_total', (select coalesce(sum(heavy_load_count), 0) from o where o.zone_id = z.id),
            'observed_strong_flow_sessions', (select count(*) from o where o.zone_id = z.id and flow_level = 'FORT')
          ) as obj
        from public.zones z
        where z.mission_id = p_mission and (p_zone is null or z.id = p_zone)
      ) zz),

    'observation_slots', (select coalesce(jsonb_agg(jsonb_build_object(
          'zone_code', z.code, 'date', o.observed_on, 'start', o.start_time, 'end', o.end_time)
          order by o.observed_on, o.start_time), '[]'::jsonb)
        from o join public.zones z on z.id = o.zone_id),

    'first_date', (select min(dt) from (
        select (coalesce(started_at, created_at) at time zone 'Africa/Porto-Novo')::date as dt from b
        union all select (coalesce(started_at, created_at) at time zone 'Africa/Porto-Novo')::date from v
        union all select observed_on from o) x),
    'last_date', (select max(dt) from (
        select (coalesce(started_at, created_at) at time zone 'Africa/Porto-Novo')::date as dt from b
        union all select (coalesce(started_at, created_at) at time zone 'Africa/Porto-Novo')::date from v
        union all select observed_on from o) x),

    'drafts',   jsonb_build_object(
        'buyers', (select count(*) from ball where status = 'BROUILLON'),
        'vendors', (select count(*) from vall where status = 'BROUILLON'),
        'observations', (select count(*) from oall where status = 'BROUILLON')),
    'excluded', jsonb_build_object(
        'buyers', (select count(*) from ball where status = 'EXCLU'),
        'vendors', (select count(*) from vall where status = 'EXCLU'),
        'observations', (select count(*) from oall where status = 'EXCLU')),
    'refusals', (select count(*) from public.refusals r
                 where r.mission_id = p_mission
                   and (p_surveyor is null or r.surveyor_id = p_surveyor)
                   and (p_zone is null or r.zone_id = p_zone))
  ) into result;

  return result;
end;
$$;

-- Droits d'exécution : jamais pour les visiteurs non connectés
revoke execute on function public.team_progress(uuid) from public, anon;
revoke execute on function public.mission_overview(uuid) from public, anon;
revoke execute on function public.survey_summary(uuid, date, date, uuid, uuid) from public, anon;
revoke execute on function public.is_admin() from public, anon;
revoke execute on function public.is_active_user() from public, anon;
grant execute on function public.team_progress(uuid) to authenticated;
grant execute on function public.mission_overview(uuid) to authenticated;
grant execute on function public.survey_summary(uuid, date, date, uuid, uuid) to authenticated;
grant execute on function public.is_admin() to authenticated;
grant execute on function public.is_active_user() to authenticated;


-- ---------------------------------------------------------------------
-- 12. MISE À JOUR EN DIRECT ENTRE UTILISATEURS (Realtime, filtré par les règles RLS)
-- ---------------------------------------------------------------------
do $$
declare
  t text;
begin
  if exists (select 1 from pg_publication where pubname = 'supabase_realtime') then
    foreach t in array array['buyer_responses', 'vendor_responses', 'observation_sessions',
                             'zone_evaluations', 'missions', 'zones']
    loop
      if not exists (
        select 1 from pg_publication_tables
        where pubname = 'supabase_realtime' and schemaname = 'public' and tablename = t
      ) then
        execute format('alter publication supabase_realtime add table public.%I', t);
      end if;
    end loop;
  end if;
end;
$$;

-- Fin du script 001.
