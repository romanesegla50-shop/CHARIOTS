-- =====================================================================
-- COCOCODJI CHARIOTS — Script 002 : activer l'équipe
--
-- À lancer APRÈS 001 et APRÈS avoir créé les comptes dans
-- Supabase > Authentication > Users > Add user (cochez « Auto Confirm User »).
--
-- 1. Remplacez les adresses e-mail ci-dessous par les vraies.
-- 2. Collez le script dans SQL Editor > Run.
-- Vous pouvez le relancer à chaque fois que vous ajoutez un enquêteur.
-- Pour désactiver quelqu'un : Équipe dans l'application (ne supprimez
-- jamais un compte qui a déjà saisi des réponses).
-- =====================================================================
do $$
declare
  admin_email  text   := 'votre.email@exemple.com';           -- <-- À MODIFIER
  surveyors    text[] := array[                               -- <-- À MODIFIER
    'ami1@exemple.com',
    'ami2@exemple.com'
  ];
  n_admin int;
  n_surv  int;
begin
  update public.profiles
     set role = 'ADMINISTRATEUR', active = true
   where lower(email) = lower(admin_email);
  get diagnostics n_admin = row_count;
  if n_admin = 0 then
    raise exception 'Compte administrateur introuvable pour % : créez-le d''abord dans Authentication > Users.', admin_email;
  end if;

  update public.profiles
     set role = 'ENQUETEUR', active = true
   where lower(email) = any (select lower(e) from unnest(surveyors) e)
     and lower(email) <> lower(admin_email);
  get diagnostics n_surv = row_count;

  raise notice 'Administrateur activé : %. Enquêteurs activés : % sur % demandés.',
    admin_email, n_surv, cardinality(surveyors);
end;
$$;

-- Vérification : liste des comptes et de leur état
select email, role, active from public.profiles order by role, email;
