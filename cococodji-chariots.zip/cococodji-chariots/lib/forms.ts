import type { FormType, TableName } from './types';

// Les noms de champs (key) sont EXACTEMENT les noms de colonnes de la base (script 001).
// Le test « contrat » (tests/contract.spec.ts) vérifie que chaque fiche produite ici
// est acceptée par le schéma SQL.

export type Answers = Record<string, unknown>;

export interface Option {
  value: string;
  label: string;
  /** reste à la fin quand l'ordre des options est inversé (ex. « Je ne paierais pas ») */
  fixedLast?: boolean;
}

export interface Question {
  key: string;
  label: string;
  help?: string;
  type: 'single' | 'multi' | 'text' | 'longtext' | 'number' | 'date' | 'time' | 'zone' | 'rating';
  options?: Option[];
  /** 'candidate' : seules les zones candidates (Module E) sont proposées */
  zoneFilter?: 'candidate';
  required?: boolean;
  /** options présentées dans un ordre alterné d'un répondant à l'autre (prix) */
  orderable?: boolean;
  /** champ texte affiché quand la valeur « AUTRE » est choisie */
  otherTextKey?: string;
  otherTextRequired?: boolean;
  otherValue?: string;
  /** valeur incompatible avec les autres (ex. « Aucun » obstacle) */
  exclusive?: string;
  min?: number;
  max?: number;
  unit?: string;
  placeholder?: string;
  showIf?: (a: Answers) => boolean;
  defaultValue?: () => unknown;
}

export interface Step {
  title: string;
  questions: Question[];
}

export interface FormDef {
  type: FormType;
  table: TableName;
  title: string;
  version: string;
  /** demande le consentement avant l'entretien (questionnaires) */
  consent: boolean;
  /** enregistre started_at / ended_at */
  trackTimes: boolean;
  /** colonne qui garde l'ordre dans lequel les prix ont été présentés */
  orderKey?: string;
  intro?: string;
  note?: string;
  steps: Step[];
  crossCheck?: (a: Answers) => string | null;
}

const localToday = () => new Date().toLocaleDateString('en-CA');
const hhmm = (d: Date) => `${String(d.getHours()).padStart(2, '0')}:${String(d.getMinutes()).padStart(2, '0')}`;

export const INTRO_ACHETEUR =
  'Bonjour. Je réalise une petite étude pour évaluer l’intérêt d’un éventuel service de chariots pour transporter les achats au marché de Cococodji. Le service n’est pas encore autorisé ni lancé. Vos réponses sont anonymes et vous pouvez refuser de répondre. Puis-je vous poser quelques questions ?';

export const INTRO_COMMERCANTE =
  'Bonjour. Je réalise une petite étude pour savoir si un éventuel service de chariots pourrait aider les clients à transporter leurs achats au marché de Cococodji. Le service n’est pas encore autorisé ni lancé. Vos réponses sont anonymes et vous pouvez refuser de répondre. Puis-je vous poser quelques questions ?';

const FREQ_OPTIONS_NOTE = 'Ne notez ni nom, ni téléphone, ni aucune information personnelle.';

export const BUYER_FORM: FormDef = {
  type: 'acheteur',
  table: 'buyer_responses',
  title: 'Questionnaire acheteur ou acheteuse',
  version: 'acheteur-v1',
  consent: true,
  trackTimes: true,
  orderKey: 'q10_ordre_options',
  intro: INTRO_ACHETEUR,
  steps: [
    {
      title: 'Lieu de l’entretien',
      questions: [
        { key: 'zone_id', type: 'zone', required: true, label: 'Dans quelle zone du marché êtes-vous ?' },
      ],
    },
    {
      title: 'Ses achats',
      questions: [
        {
          key: 'q1_transporte', type: 'single', required: true,
          label: 'Aujourd’hui, transportez-vous des achats que vous devez déplacer jusqu’à une sortie, un parking ou un autre point de récupération ?',
          options: [{ value: 'OUI', label: 'Oui' }, { value: 'NON', label: 'Non' }],
        },
        {
          key: 'q2_frequence', type: 'single', required: true,
          label: 'À quelle fréquence avez-vous du mal à transporter vos achats dans ce marché ?',
          options: [
            { value: 'JAMAIS', label: 'Jamais' },
            { value: 'RAREMENT', label: 'Rarement' },
            { value: 'PARFOIS', label: 'Parfois' },
            { value: 'SOUVENT', label: 'Souvent' },
            { value: 'PRESQUE_CHAQUE_VISITE', label: 'Presque à chaque visite' },
          ],
        },
        {
          key: 'q3_difficultes', type: 'multi', required: true,
          label: 'Quelle est la difficulté principale ?',
          help: 'Plusieurs réponses possibles.',
          options: [
            { value: 'CHARGES_LOURDES', label: 'Charges lourdes' },
            { value: 'PLUSIEURS_SACS', label: 'Plusieurs sacs' },
            { value: 'VOLUMINEUX', label: 'Marchandises volumineuses' },
            { value: 'DISTANCE', label: 'Distance jusqu’au parking ou à la sortie' },
            { value: 'PLUSIEURS_TRAJETS', label: 'Plusieurs trajets' },
            { value: 'MAINS_OCCUPEES', label: 'Mains occupées' },
            { value: 'AUTRE', label: 'Autre' },
          ],
          otherTextKey: 'q3_autre', otherTextRequired: true,
        },
        {
          key: 'q4_mode_transport', type: 'single', required: true,
          label: 'Aujourd’hui, comment transportez-vous vos achats ?',
          options: [
            { value: 'A_LA_MAIN', label: 'À la main' },
            { value: 'AIDE_PROCHE', label: 'Avec l’aide d’un proche ou accompagnant' },
            { value: 'PORTEUR_PAYE', label: 'Avec un porteur payé' },
            { value: 'CHARIOT_DEJA', label: 'Avec un chariot déjà disponible' },
            { value: 'AUTRE', label: 'Autre' },
          ],
          otherTextKey: 'q4_autre',
        },
        {
          key: 'q5_nb_trajets', type: 'single', required: true,
          label: 'Pour une visite typique, combien de trajets faites-vous entre vos achats et votre point de récupération ?',
          options: [
            { value: '1', label: '1' },
            { value: '2', label: '2' },
            { value: '3_OU_PLUS', label: '3 ou plus' },
            { value: 'VARIABLE', label: 'Variable' },
            { value: 'NE_SAIT_PAS', label: 'Ne sait pas' },
          ],
        },
      ],
    },
    {
      title: 'Le service envisagé',
      questions: [
        {
          key: 'q6_utilisation', type: 'single', required: true,
          label: 'Si un chariot autorisé était disponible, l’utiliseriez-vous probablement ?',
          options: [
            { value: 'CERTAINEMENT', label: 'Certainement' },
            { value: 'PROBABLEMENT', label: 'Probablement' },
            { value: 'PAS_SUR', label: 'Pas sûr(e)' },
            { value: 'PROBABLEMENT_PAS', label: 'Probablement pas' },
            { value: 'CERTAINEMENT_PAS', label: 'Certainement pas' },
          ],
        },
        {
          key: 'q7_trajet_utile', type: 'single', required: true,
          label: 'Pour quel trajet serait-il le plus utile ?',
          options: [
            { value: 'ENTRE_ETALS', label: 'Entre les étals' },
            { value: 'ETALS_SORTIE', label: 'Des étals à la sortie' },
            { value: 'ETALS_PARKING', label: 'Des étals au parking ou au point de récupération' },
            { value: 'AUTRE', label: 'Autre' },
          ],
          otherTextKey: 'q7_autre',
        },
        {
          key: 'q8_moment_utile', type: 'single', required: true,
          label: 'À quel moment serait-il le plus utile ?',
          options: [
            { value: 'TOUTE_VISITE', label: 'Pendant toute la visite' },
            { value: 'APRES_ACHATS', label: 'Après les achats' },
            { value: 'HEURES_AFFLUENCE', label: 'Aux heures d’affluence' },
            { value: 'SELON_SECTEUR', label: 'Selon le secteur' },
            { value: 'AUTRE', label: 'Autre' },
          ],
          otherTextKey: 'q8_autre',
        },
      ],
    },
    {
      title: 'Paiement et prix',
      questions: [
        {
          key: 'q9_paiement', type: 'single', required: true,
          label: 'Quel mode de paiement préféreriez-vous ?',
          options: [
            { value: 'PRIX_FIXE', label: 'Prix fixe par utilisation' },
            { value: 'SELON_DUREE', label: 'Paiement selon la durée' },
            { value: 'AUTRE', label: 'Autre' },
            { value: 'AUCUN', label: 'Aucun paiement' },
          ],
          otherTextKey: 'q9_autre',
        },
        {
          key: 'q10_prix', type: 'single', required: true, orderable: true,
          label: 'Pour une utilisation, quel prix vous semblerait acceptable ?',
          help: 'L’ordre des prix alterne d’une personne à l’autre pour ne pas influencer la réponse.',
          options: [
            { value: '100', label: '100 FCFA' },
            { value: '200', label: '200 FCFA' },
            { value: '300', label: '300 FCFA' },
            { value: 'AUTRE_MONTANT', label: 'Autre montant', fixedLast: true },
            { value: 'NE_PAIERAIT_PAS', label: 'Je ne paierais pas', fixedLast: true },
          ],
        },
        {
          key: 'q10_montant_fcfa', type: 'number', required: true, min: 1, max: 1000000, unit: 'FCFA',
          help: 'Si la personne ne paierait rien, choisissez plutôt « Je ne paierais pas ».',
          label: 'Quel montant (en FCFA) ?',
          showIf: (a) => a.q10_prix === 'AUTRE_MONTANT',
        },
        {
          key: 'q11_caution', type: 'single', required: true,
          label: 'Une caution remboursable en plus du prix vous découragerait-elle ?',
          options: [
            { value: 'OUI', label: 'Oui' },
            { value: 'NON', label: 'Non' },
            { value: 'DEPEND_MONTANT', label: 'Cela dépend du montant' },
            { value: 'NE_SAIT_PAS', label: 'Ne sait pas' },
          ],
        },
      ],
    },
    {
      title: 'Pour terminer',
      questions: [
        {
          key: 'q12_inquietude', type: 'single', required: true,
          label: 'Quelle serait votre principale inquiétude ?',
          options: [
            { value: 'DISPONIBILITE', label: 'Disponibilité du chariot' },
            { value: 'PRIX', label: 'Prix' },
            { value: 'SECURITE', label: 'Sécurité ou perte des achats' },
            { value: 'MANIABILITE', label: 'Maniabilité ou état du sol' },
            { value: 'OU_RENDRE', label: 'Où le rendre' },
            { value: 'AUCUNE', label: 'Aucune' },
            { value: 'AUTRE', label: 'Autre' },
          ],
          otherTextKey: 'q12_autre',
        },
        {
          key: 'q13_remarque', type: 'longtext', required: false,
          label: 'Remarque ou suggestion (facultatif)',
          help: FREQ_OPTIONS_NOTE,
        },
      ],
    },
  ],
};

export const VENDOR_FORM: FormDef = {
  type: 'commercante',
  table: 'vendor_responses',
  title: 'Questionnaire vendeuse ou commerçante',
  version: 'commercante-v1',
  consent: true,
  trackTimes: true,
  intro: INTRO_COMMERCANTE,
  steps: [
    {
      title: 'Lieu de l’entretien',
      questions: [
        { key: 'zone_id', type: 'zone', required: true, label: 'Dans quelle zone du marché êtes-vous ?' },
      ],
    },
    {
      title: 'Les clients et leurs achats',
      questions: [
        {
          key: 'q1_difficultes_clients', type: 'single', required: true,
          label: 'Vos clients ont-ils parfois du mal à transporter leurs achats ?',
          options: [
            { value: 'JAMAIS', label: 'Jamais' },
            { value: 'RAREMENT', label: 'Rarement' },
            { value: 'PARFOIS', label: 'Parfois' },
            { value: 'SOUVENT', label: 'Souvent' },
            { value: 'TRES_SOUVENT', label: 'Très souvent' },
            { value: 'NE_SAIT_PAS', label: 'Ne sait pas' },
          ],
        },
        {
          key: 'q2_produits', type: 'multi', required: true,
          label: 'Quels produits ou achats posent le plus de difficultés ?',
          help: 'Plusieurs réponses possibles.',
          options: [
            { value: 'SACS_PROVISIONS', label: 'Sacs de provisions' },
            { value: 'PRODUITS_LOURDS', label: 'Produits lourds' },
            { value: 'VOLUMINEUX', label: 'Articles volumineux' },
            { value: 'PLUSIEURS_ETALS', label: 'Plusieurs achats provenant de différents étals' },
            { value: 'AUTRE', label: 'Autre' },
          ],
          otherTextKey: 'q2_autre',
        },
        {
          key: 'q3_comportement', type: 'single', required: true,
          label: 'Que font généralement les clients ?',
          options: [
            { value: 'PORTENT_EUX_MEMES', label: 'Portent eux-mêmes leurs achats' },
            { value: 'PLUSIEURS_TRAJETS', label: 'Font plusieurs trajets' },
            { value: 'DEMANDENT_AIDE', label: 'Demandent de l’aide' },
            { value: 'PAIENT_PORTEUR', label: 'Paient un porteur' },
            { value: 'AUTRE', label: 'Autre' },
          ],
          otherTextKey: 'q3_autre',
        },
      ],
    },
    {
      title: 'Où et quand',
      questions: [
        {
          key: 'q4_secteur_texte', type: 'longtext', required: false,
          label: 'Dans quel secteur ou sur quel trajet un chariot pourrait-il être utile ?',
          help: 'Réponse libre. Le code de zone ci-dessous est facultatif.',
        },
        { key: 'q4_zone_id', type: 'zone', required: false, label: 'Code de zone concerné (facultatif)' },
        {
          key: 'q5_moment', type: 'single', required: true,
          label: 'À quels moments le besoin semble-t-il le plus fort ?',
          options: [
            { value: 'MATIN', label: 'Matin' },
            { value: 'MILIEU_JOURNEE', label: 'Milieu de journée' },
            { value: 'APRES_MIDI', label: 'Après-midi' },
            { value: 'FORTE_AFFLUENCE', label: 'Jours de forte affluence' },
            { value: 'VARIABLE', label: 'Variable' },
          ],
        },
      ],
    },
    {
      title: 'Risques et avis',
      questions: [
        {
          key: 'q6_risques', type: 'multi', required: true, exclusive: 'AUCUN',
          label: 'Quels risques ou difficultés anticipez-vous ?',
          help: 'Plusieurs réponses possibles.',
          options: [
            { value: 'ENCOMBREMENT', label: 'Encombrement' },
            { value: 'CIRCULATION', label: 'Circulation' },
            { value: 'VOL_PERTE', label: 'Vol ou perte' },
            { value: 'CONFLIT', label: 'Conflit avec les activités existantes' },
            { value: 'SALETE', label: 'Saleté ou dégradation' },
            { value: 'AUCUN', label: 'Aucun' },
            { value: 'AUTRE', label: 'Autre' },
          ],
          otherTextKey: 'q6_autre',
        },
        {
          key: 'q7_utiliseraient', type: 'single', required: true,
          label: 'Pensez-vous que vos clients utiliseraient un tel service ?',
          options: [
            { value: 'OUI', label: 'Oui' },
            { value: 'NON', label: 'Non' },
            { value: 'INCERTAIN', label: 'Incertain' },
          ],
        },
        { key: 'q8_pourquoi', type: 'longtext', required: false, label: 'Pourquoi ? (facultatif)', help: FREQ_OPTIONS_NOTE },
        { key: 'q9_suggestion', type: 'longtext', required: false, label: 'Autre suggestion (facultatif)' },
      ],
    },
  ],
};

export const OBSERVATION_FORM: FormDef = {
  type: 'observation',
  table: 'observation_sessions',
  title: 'Observation des flux',
  version: 'observation-v1',
  consent: false,
  trackTimes: false,
  note:
    'Observations ponctuelles : ce n’est pas un comptage complet de la fréquentation du marché. N’identifiez, ne suivez et ne photographiez aucune personne.',
  steps: [
    {
      title: 'Zone et horaire',
      questions: [
        { key: 'zone_id', type: 'zone', required: true, label: 'Zone observée' },
        { key: 'observed_on', type: 'date', required: true, label: 'Date', defaultValue: localToday },
        { key: 'start_time', type: 'time', required: true, label: 'Heure de début', defaultValue: () => hhmm(new Date()) },
        {
          key: 'end_time', type: 'time', required: true, label: 'Heure de fin',
          help: 'Idéalement 15 minutes après le début.',
          defaultValue: () => hhmm(new Date(Date.now() + 15 * 60000)),
        },
      ],
    },
    {
      title: 'Ce que vous comptez',
      questions: [
        { key: 'people_count', type: 'number', required: true, min: 0, max: 100000, label: 'Nombre approximatif de personnes passant dans la zone', help: 'Pendant la période observée (15 minutes idéalement).' },
        { key: 'heavy_load_count', type: 'number', required: false, min: 0, max: 100000, label: 'Personnes portant plusieurs sacs ou des charges encombrantes' },
        { key: 'multiple_trips_count', type: 'number', required: false, min: 0, max: 100000, label: 'Personnes semblant faire plusieurs trajets', help: 'Seulement si vous pouvez le voir raisonnablement.' },
        { key: 'help_or_porter_count', type: 'number', required: false, min: 0, max: 100000, label: 'Personnes demandant de l’aide ou utilisant un porteur' },
      ],
    },
    {
      title: 'Le terrain',
      questions: [
        {
          key: 'flow_level', type: 'single', required: true, label: 'Niveau de flux piéton',
          options: [{ value: 'FAIBLE', label: 'Faible' }, { value: 'MOYEN', label: 'Moyen' }, { value: 'FORT', label: 'Fort' }],
        },
        {
          key: 'obstacles', type: 'multi', required: true, exclusive: 'AUCUN', label: 'Obstacles visibles', help: 'Plusieurs réponses possibles.',
          options: [
            { value: 'AUCUN', label: 'Aucun' },
            { value: 'ETROITURES', label: 'Étroitures' },
            { value: 'MARCHES', label: 'Marches' },
            { value: 'PENTE', label: 'Pente' },
            { value: 'SOL_IRREGULIER', label: 'Sol irrégulier' },
            { value: 'AUTRE', label: 'Autre' },
          ],
          otherTextKey: 'obstacles_autre',
        },
        { key: 'distance_exit_m', type: 'number', required: false, min: 0, max: 5000, unit: 'm', label: 'Distance approximative vers une sortie ou un parking', help: 'Si vous pouvez l’estimer.' },
        {
          key: 'trolley_access', type: 'single', required: true, label: 'Accessibilité potentielle pour un chariot',
          options: [
            { value: 'PROBABLEMENT_ACCESSIBLE', label: 'Probablement accessible' },
            { value: 'DIFFICILE', label: 'Difficile' },
            { value: 'A_VERIFIER', label: 'À vérifier' },
          ],
        },
        {
          key: 'congestion_risk', type: 'single', required: true, label: 'Risque potentiel d’encombrement',
          options: [
            { value: 'FAIBLE', label: 'Faible' },
            { value: 'MOYEN', label: 'Moyen' },
            { value: 'ELEVE', label: 'Élevé' },
            { value: 'A_VERIFIER', label: 'À vérifier' },
          ],
        },
      ],
    },
    {
      title: 'Commentaires',
      questions: [
        { key: 'comments', type: 'longtext', required: false, label: 'Commentaires factuels (facultatif)', help: 'Décrivez des faits, pas des personnes.' },
      ],
    },
  ],
  crossCheck: (a) => {
    const s = a.start_time, e = a.end_time;
    if (typeof s === 'string' && typeof e === 'string' && s && e && e <= s) return 'L’heure de fin doit être après l’heure de début.';
    return null;
  },
};

const rating = (key: string, label: string, help?: string): Question => ({
  key, type: 'rating', required: true, label, help, min: 1, max: 5,
});

/** Module E : comparer jusqu'à trois zones candidates. Outil de comparaison INTERNE, pas une autorisation d'occupation. */
export const EVALUATION_FORM: FormDef = {
  type: 'evaluation',
  table: 'zone_evaluations',
  title: 'Évaluation d’un emplacement candidat',
  version: 'evaluation-v1',
  consent: false,
  trackTimes: false,
  note:
    'Ce score est un outil de comparaison interne. Il ne vaut pas autorisation d’occupation, et aucun emplacement n’est « approuvé » sans validation explicite de l’administrateur. À confirmer auprès du gestionnaire : espace réellement disponible, autorisation de stationnement, trajets permis, horaires, règles de sécurité, frais éventuels.',
  steps: [
    {
      title: 'Zone évaluée',
      questions: [
        {
          key: 'zone_id', type: 'zone', zoneFilter: 'candidate', required: true,
          label: 'Quelle zone candidate évaluez-vous ?',
          help: 'Seules les zones candidates choisies par l’administrateur apparaissent. Une seule évaluation par zone et par enquêteur.',
        },
      ],
    },
    {
      title: 'Clients et accès',
      questions: [
        rating('score_flux', 'Flux de clients', '1 = très défavorable, 5 = très favorable'),
        rating('score_zones_lourdes', 'Proximité des zones d’achats lourds'),
        rating('score_acces_sortie', 'Accès à la sortie ou au parking'),
        rating('score_passage', 'Largeur et qualité du passage'),
      ],
    },
    {
      title: 'Exploitation',
      questions: [
        rating('score_retour_chariots', 'Facilité de retour des chariots'),
        rating('score_surveillance', 'Possibilité de surveillance'),
        rating('score_faible_encombrement', 'Faible risque d’encombrement', '5 = risque d’encombrement très faible'),
        { key: 'notes', type: 'longtext', required: false, label: 'Notes et commentaires (facultatif)', help: 'Faits observés, sans identifier de personne.' },
      ],
    },
  ],
};

export const FORMS: Record<FormType, FormDef> = {
  acheteur: BUYER_FORM,
  commercante: VENDOR_FORM,
  observation: OBSERVATION_FORM,
  evaluation: EVALUATION_FORM,
};

export function isFormType(v: string): v is FormType {
  return v === 'acheteur' || v === 'commercante' || v === 'observation' || v === 'evaluation';
}

/** Zones proposables pour une question (filtre « candidates » du Module E). */
export function zonesForQuestion<Z extends { is_candidate: boolean }>(q: Question, zones: Z[]): Z[] {
  return q.zoneFilter === 'candidate' ? zones.filter((z) => z.is_candidate) : zones;
}

// ------------------------------------------------------------------ logique commune

export const isEmpty = (v: unknown) =>
  v === undefined || v === null || v === '' || (Array.isArray(v) && v.length === 0) || (typeof v === 'number' && Number.isNaN(v));

export function visibleQuestions(step: Step, answers: Answers): Question[] {
  return step.questions.filter((q) => !q.showIf || q.showIf(answers));
}

export function validateQuestion(q: Question, answers: Answers): string | null {
  const v = answers[q.key];
  if (q.required && isEmpty(v)) return 'Cette réponse est obligatoire.';
  if (isEmpty(v)) return null;
  if (q.type === 'rating') {
    const n = Number(v);
    if (!Number.isInteger(n) || n < 1 || n > 5) return 'Choisissez une note de 1 à 5.';
  }
  if (q.type === 'number') {
    const n = Number(v);
    if (!Number.isFinite(n) || !Number.isInteger(n)) return 'Entrez un nombre entier.';
    if (q.min !== undefined && n < q.min) return `Le minimum est ${q.min}.`;
    if (q.max !== undefined && n > q.max) return `Le maximum est ${q.max}.`;
  }
  if (q.otherTextKey && q.otherTextRequired) {
    const other = q.otherValue ?? 'AUTRE';
    const chosen = Array.isArray(v) ? v.includes(other) : v === other;
    const t = answers[q.otherTextKey];
    if (chosen && (typeof t !== 'string' || t.trim() === '')) return 'Précisez « Autre ».';
  }
  return null;
}

export function validateStep(step: Step, answers: Answers): Record<string, string> {
  const errors: Record<string, string> = {};
  for (const q of visibleQuestions(step, answers)) {
    const e = validateQuestion(q, answers);
    if (e) errors[q.key] = e;
  }
  return errors;
}

/** Retourne l'index de la première étape en erreur, ou -1 */
export function firstInvalidStep(def: FormDef, answers: Answers): { index: number; errors: Record<string, string> } {
  for (let i = 0; i < def.steps.length; i++) {
    const errors = validateStep(def.steps[i], answers);
    if (def.crossCheck && i === def.steps.length - 1) {
      /* contrôle croisé ci-dessous */
    }
    if (Object.keys(errors).length) return { index: i, errors };
  }
  const cross = def.crossCheck?.(answers);
  if (cross) {
    // l'erreur concerne l'heure de fin (observation) : on rouvre l'étape qui la contient
    const idx = def.steps.findIndex((s) => s.questions.some((q) => q.key === 'end_time'));
    return { index: Math.max(idx, 0), errors: { end_time: cross } };
  }
  return { index: -1, errors: {} };
}

/** Ordre de présentation des options (prix) : ASC = ordre normal, DESC = inversé (sauf options fixes en fin) */
export function orderedOptions(q: Question, ordering: 'ASC' | 'DESC'): Option[] {
  const opts = q.options ?? [];
  if (!q.orderable || ordering === 'ASC') return opts;
  const movable = opts.filter((o) => !o.fixedLast).reverse();
  return [...movable, ...opts.filter((o) => o.fixedLast)];
}

export function orderingString(def: FormDef, ordering: 'ASC' | 'DESC'): string | null {
  const q = def.steps.flatMap((s) => s.questions).find((x) => x.orderable);
  if (!q) return null;
  return orderedOptions(q, ordering)
    .filter((o) => !o.fixedLast)
    .map((o) => o.value)
    .join('-');
}

/** Colonnes de la table issues des réponses (uniquement les questions visibles et non vides). */
export function columnsFromAnswers(def: FormDef, answers: Answers): Record<string, unknown> {
  const row: Record<string, unknown> = {};
  for (const step of def.steps) {
    for (const q of visibleQuestions(step, answers)) {
      const v = answers[q.key];
      if (!isEmpty(v)) {
        if (q.type === 'number' || q.type === 'rating') row[q.key] = Number(v);
        else if (typeof v === 'string') row[q.key] = v.trim();
        else row[q.key] = v;
      }
      if (q.otherTextKey) {
        const other = q.otherValue ?? 'AUTRE';
        const chosen = Array.isArray(v) ? v.includes(other) : v === other;
        const t = answers[q.otherTextKey];
        if (chosen && typeof t === 'string' && t.trim()) row[q.otherTextKey] = t.trim();
      }
    }
  }
  return row;
}

/** Toutes les colonnes que le formulaire peut remplir. */
export function editableKeys(def: FormDef): string[] {
  const keys = new Set<string>();
  for (const s of def.steps) {
    for (const q of s.questions) {
      keys.add(q.key);
      if (q.otherTextKey) keys.add(q.otherTextKey);
    }
  }
  return [...keys];
}

const normalizeStored = (k: string, v: unknown): unknown => {
  if (v === undefined || v === null || v === '') return null;
  if ((k === 'start_time' || k === 'end_time') && typeof v === 'string') return v.slice(0, 5); // « 09:15:00 » -> « 09:15 »
  return v;
};

/** Relit une fiche du serveur sous forme de réponses de formulaire (pour la corriger). */
export function rowToAnswers(def: FormDef, row: Record<string, unknown>): Answers {
  const a: Answers = {};
  for (const k of editableKeys(def)) {
    const v = normalizeStored(k, row[k]);
    if (v !== null) a[k] = v;
  }
  return a;
}

/**
 * Champs réellement modifiés entre la fiche d'origine et les réponses corrigées.
 * Un champ devenu sans objet (ex. montant après changement de prix) est remis à null.
 */
export function buildPatch(def: FormDef, original: Record<string, unknown>, answers: Answers): Record<string, unknown> {
  const wanted = columnsFromAnswers(def, answers);
  const patch: Record<string, unknown> = {};
  for (const k of editableKeys(def)) {
    const next = normalizeStored(k, wanted[k]);
    const prev = normalizeStored(k, original[k]);
    if (JSON.stringify(next) !== JSON.stringify(prev)) patch[k] = next;
  }
  return patch;
}

export interface RowContext {
  id: string;
  missionId: string;
  userId: string;
  startedAt: string;
  endedAt: string;
  createdAt: string;
  ordering: 'ASC' | 'DESC';
}

/** Transforme les réponses en ligne prête pour la table (statut SOUMIS). */
export function buildRow(def: FormDef, answers: Answers, ctx: RowContext): Record<string, unknown> {
  const row: Record<string, unknown> = {
    id: ctx.id,
    mission_id: ctx.missionId,
    surveyor_id: ctx.userId,
    status: 'SOUMIS',
    form_version: def.version,
    created_at: ctx.createdAt,
  };
  if (def.consent) row.consent = true;
  if (def.trackTimes) {
    row.started_at = ctx.startedAt;
    row.ended_at = ctx.endedAt;
  }
  const ostr = orderingString(def, ctx.ordering);
  if (def.orderKey && ostr) row[def.orderKey] = ostr;

  Object.assign(row, columnsFromAnswers(def, answers));
  return row;
}

export function defaultAnswers(def: FormDef): Answers {
  const a: Answers = {};
  for (const s of def.steps) for (const q of s.questions) if (q.defaultValue) a[q.key] = q.defaultValue();
  return a;
}

export function labelFor(q: Question, value: unknown, zones: { id: string; code: string; label: string | null }[]): string {
  if (isEmpty(value)) return '—';
  if (q.type === 'zone') {
    const z = zones.find((x) => x.id === value);
    return z ? `${z.code}${z.label ? ' — ' + z.label : ''}` : String(value);
  }
  if (q.type === 'single') return q.options?.find((o) => o.value === value)?.label ?? String(value);
  if (q.type === 'multi' && Array.isArray(value)) return value.map((v) => q.options?.find((o) => o.value === v)?.label ?? String(v)).join(', ');
  if (q.type === 'rating') return `${value} sur 5`;
  if (q.type === 'number') return q.unit ? `${value} ${q.unit}` : String(value);
  return String(value);
}
