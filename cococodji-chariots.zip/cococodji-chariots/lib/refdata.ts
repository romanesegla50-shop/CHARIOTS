import type { SupabaseClient } from '@supabase/supabase-js';
import { getMeta, setMeta } from './localdb';
import type { Profile, Reference, ReferenceMission, ReferenceZone } from './types';

// Mission et zones sont recopiées sur le téléphone à chaque connexion réussie,
// pour que les formulaires restent utilisables sans réseau.

export async function getCachedReference(): Promise<Reference | null> {
  return (await getMeta<Reference>('reference')) ?? null;
}

export async function refreshReference(c: SupabaseClient): Promise<Reference | null> {
  const { data: missions, error } = await c
    .from('missions')
    .select('id,name,status,start_date,end_date,instructions,target_buyers,target_vendors,target_observations,created_at')
    .order('created_at', { ascending: false });
  if (error || !missions) return null;

  const list = missions as (ReferenceMission & { created_at: string })[];
  // la mission « courante » : la plus récente qui n'est pas terminée, sinon la plus récente
  const current = list.find((m) => m.status !== 'TERMINEE') ?? list[0] ?? null;

  let zones: ReferenceZone[] = [];
  if (current) {
    const { data, error: zerr } = await c
      .from('zones')
      .select('id,code,label,description,sector,is_candidate,approval_status')
      .eq('mission_id', current.id)
      .order('code');
    if (zerr) return null;
    zones = (data ?? []) as ReferenceZone[];
  }

  const ref: Reference = {
    mission: current
      ? {
          id: current.id,
          name: current.name,
          status: current.status,
          start_date: current.start_date,
          end_date: current.end_date,
          instructions: current.instructions,
          target_buyers: current.target_buyers,
          target_vendors: current.target_vendors,
          target_observations: current.target_observations,
        }
      : null,
    zones,
    fetchedAt: new Date().toISOString(),
  };
  await setMeta('reference', ref);
  return ref;
}

export async function getCachedProfile(userId: string): Promise<Profile | null> {
  return (await getMeta<Profile>(`profile:${userId}`)) ?? null;
}

export async function refreshProfile(c: SupabaseClient, userId: string): Promise<Profile | null> {
  const { data, error } = await c.from('profiles').select('id,email,full_name,role,active').eq('id', userId).maybeSingle();
  if (error || !data) return null;
  await setMeta(`profile:${userId}`, data);
  return data as Profile;
}

export interface Overview {
  buyers: number;
  vendors: number;
  observations: number;
  zones_observed: number;
  refusals: number;
  target_buyers: number;
  target_vendors: number;
  target_observations: number;
}
export interface TeamRow {
  surveyor_id: string;
  surveyor_name: string;
  buyers: number;
  vendors: number;
  observations: number;
  evaluations: number;
}
export interface ServerStats {
  overview: Overview | null;
  team: TeamRow[];
  fetchedAt: string;
}

export async function getCachedStats(): Promise<ServerStats | null> {
  return (await getMeta<ServerStats>('stats')) ?? null;
}

export async function refreshStats(c: SupabaseClient, missionId: string): Promise<ServerStats | null> {
  const [ov, tp] = await Promise.all([
    c.rpc('mission_overview', { p_mission: missionId }),
    c.rpc('team_progress', { p_mission: missionId }),
  ]);
  if (ov.error || tp.error) return null;
  const stats: ServerStats = {
    overview: (ov.data as Overview | null) ?? null,
    team: ((tp.data ?? []) as TeamRow[]).map((r) => ({
      ...r,
      buyers: Number(r.buyers),
      vendors: Number(r.vendors),
      observations: Number(r.observations),
      evaluations: Number(r.evaluations),
    })),
    fetchedAt: new Date().toISOString(),
  };
  await setMeta('stats', stats);
  return stats;
}
