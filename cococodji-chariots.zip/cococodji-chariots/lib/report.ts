import type { FullZone, ServerRow, Summary } from './admin';
import { MANAGER_CHECK_ITEMS } from './admin';
import { fmtLocalDate } from './export';
import {
  CONFUSION_WARNING, DISCLAIMER, EVAL_CRITERIA, NOT_AUTHORIZED, distribution, optionLabel, pct, summarizeEvaluations, willingToPay,
} from './stats';
import type { ReferenceMission } from './types';

// Contenu du rapport PDF (annexe possible au dossier ANaGeM). Tout est calculé à partir des données
// réellement enregistrées ; aucune valeur de démonstration. Séparé du rendu pour pouvoir être testé.

export type Block =
  | { type: 'para'; text: string; style?: 'normal' | 'note' | 'warning' }
  | { type: 'bullets'; items: string[] }
  | { type: 'table'; headers: string[]; rows: string[][]; widths?: number[]; caption?: string };

export interface Section {
  title: string;
  blocks: Block[];
}

export interface ReportModel {
  title: string;
  subtitle: string;
  generatedAt: string;
  notices: string[];
  sections: Section[];
}

export interface ReportInput {
  mission: ReferenceMission | null;
  summary: Summary;
  zones: FullZone[];
  evaluations: ServerRow[];
  generatedAt: string;
  filtersText?: string;
}

const frDate = (d: string | null | undefined) => {
  if (!d) return '-';
  const [y, m, day] = d.slice(0, 10).split('-');
  return `${day}/${m}/${y}`;
};
const ratioRow = (label: string, n: number, d: number): string[] => [label, String(n), String(d), d > 0 ? pct({ n, d }) : '-'];
const distRows = (obj: Record<string, number>, form: 'acheteur' | 'commercante', key: string, base: number) =>
  distribution(obj, (k) => optionLabel(form, key, k), base).map((x) => [x.label, String(x.count), String(base), x.pct]);

export function buildReport(inp: ReportInput): ReportModel {
  const { mission, summary: s, zones } = inp;
  const sections: Section[] = [];
  const noData = s.buyers_total + s.vendors_total + s.observations_total === 0;

  // ---- 1. échantillon et période
  sections.push({
    title: '1. Échantillon et période de collecte',
    blocks: [
      {
        type: 'table',
        headers: ['Élément', 'Réalisé', 'Objectif exploratoire'],
        widths: [0.5, 0.2, 0.3],
        rows: [
          ['Acheteurs interrogés (réponses valides)', String(s.buyers_total), mission ? String(mission.target_buyers) : '-'],
          ['Commerçantes interrogées (réponses valides)', String(s.vendors_total), mission ? String(mission.target_vendors) : '-'],
          ['Sessions d\'observation', String(s.observations_total), mission && mission.target_observations ? String(mission.target_observations) : '-'],
          ['Zones étudiées (observations)', String(s.zones_studied), '-'],
        ],
      },
      {
        type: 'bullets',
        items: [
          `Période des réponses : ${s.first_date ? `du ${frDate(s.first_date)} au ${frDate(s.last_date)}` : 'aucune réponse enregistrée'}.`,
          mission ? `Mission : ${mission.name}.` : 'Mission : non renseignée.',
          `Base de calcul : réponses soumises uniquement. Non comptées : ${s.drafts.buyers + s.drafts.vendors + s.drafts.observations} brouillon(s), ${s.excluded.buyers + s.excluded.vendors + s.excluded.observations} réponse(s) exclue(s).`,
          `Refus de répondre comptés (anonymes) : ${s.refusals}.`,
          ...(inp.filtersText ? [`Filtres appliqués : ${inp.filtersText}.`] : []),
        ],
      },
      { type: 'para', style: 'note', text: 'Les objectifs sont exploratoires : ce ne sont ni des quotas obligatoires ni une garantie de représentativité statistique.' },
    ],
  });

  // ---- 2. zones et horaires
  const studied = s.zones.filter((z) => z.observations > 0 || z.buyers > 0 || z.vendors > 0);
  sections.push({
    title: '2. Zones et horaires couverts',
    blocks: noData
      ? [{ type: 'para', text: 'Aucune donnée enregistrée pour l\'instant.' }]
      : [
          {
            type: 'table',
            headers: ['Zone', 'Acheteurs', 'Commerçantes', 'Sessions d\'observation'],
            widths: [0.25, 0.25, 0.25, 0.25],
            rows: studied.map((z) => [z.zone_code, String(z.buyers), String(z.vendors), String(z.observations)]),
          },
          s.observation_slots.length
            ? {
                type: 'table',
                caption: 'Créneaux d\'observation enregistrés',
                headers: ['Zone', 'Date', 'Début', 'Fin'],
                widths: [0.25, 0.25, 0.25, 0.25],
                rows: s.observation_slots.map((o) => [o.zone_code, frDate(o.date), String(o.start).slice(0, 5), String(o.end).slice(0, 5)]),
              }
            : { type: 'para', text: 'Aucune session d\'observation soumise.' },
        ],
  });

  // ---- 3. acheteurs
  const pay = willingToPay(s.price_distribution);
  sections.push({
    title: '3. Résultats : acheteurs',
    blocks: s.buyers_total === 0
      ? [{ type: 'para', text: 'Aucun questionnaire acheteur valide pour l\'instant : aucun résultat à présenter.' }]
      : [
          {
            type: 'table',
            headers: ['Indicateur', 'n', 'Base (d)', '%'],
            widths: [0.58, 0.12, 0.15, 0.15],
            rows: [
              ratioRow('Difficultés « souvent » ou « presque à chaque visite »', s.buyers_often_difficulty.n, s.buyers_often_difficulty.d),
              ratioRow('Intérêt déclaré (« certainement » ou « probablement »)', s.buyers_interested.n, s.buyers_interested.d),
              ratioRow('Volonté déclarée de payer (un prix a été choisi)', pay.n, pay.d),
              ratioRow('Deux trajets ou plus pour une visite typique', s.buyers_two_trips_or_more.n, s.buyers_two_trips_or_more.d),
            ],
          },
          { type: 'para', style: 'warning', text: CONFUSION_WARNING },
          { type: 'table', caption: 'Prix jugé acceptable pour une utilisation (déclaratif)', headers: ['Réponse', 'Nombre', 'Base', '%'], widths: [0.52, 0.16, 0.16, 0.16], rows: distRows(s.price_distribution, 'acheteur', 'q10_prix', s.buyers_total) },
          ...(s.price_other_amounts_fcfa.length ? [{ type: 'para' as const, text: `Autres montants proposés (FCFA) : ${s.price_other_amounts_fcfa.join(', ')}.` }] : []),
          { type: 'table', caption: 'Difficultés principales (plusieurs réponses possibles : le total peut dépasser 100 %)', headers: ['Difficulté', 'Nombre', 'Base', '%'], widths: [0.52, 0.16, 0.16, 0.16], rows: distRows(s.difficulties, 'acheteur', 'q3_difficultes', s.buyers_total) },
          { type: 'table', caption: 'Principale inquiétude', headers: ['Inquiétude', 'Nombre', 'Base', '%'], widths: [0.52, 0.16, 0.16, 0.16], rows: distRows(s.concerns, 'acheteur', 'q12_inquietude', s.buyers_total) },
          { type: 'table', caption: 'Une caution remboursable découragerait-elle ?', headers: ['Réponse', 'Nombre', 'Base', '%'], widths: [0.52, 0.16, 0.16, 0.16], rows: distRows(s.deposit_reaction, 'acheteur', 'q11_caution', s.buyers_total) },
        ],
  });

  // ---- 4. commerçantes
  sections.push({
    title: '4. Résultats : commerçantes',
    blocks: s.vendors_total === 0
      ? [{ type: 'para', text: 'Aucun questionnaire commerçante valide pour l\'instant : aucun résultat à présenter.' }]
      : [
          {
            type: 'table',
            headers: ['Indicateur', 'n', 'Base (d)', '%'],
            widths: [0.58, 0.12, 0.15, 0.15],
            rows: [
              ratioRow('Clients en difficulté « souvent » ou « très souvent »', s.vendors_clients_often_difficulty.n, s.vendors_clients_often_difficulty.d),
              ratioRow('Pensent que leurs clients utiliseraient le service', s.vendors_clients_would_use.n, s.vendors_clients_would_use.d),
            ],
          },
          { type: 'table', caption: 'Risques ou difficultés anticipés (plusieurs réponses possibles)', headers: ['Risque', 'Nombre', 'Base', '%'], widths: [0.52, 0.16, 0.16, 0.16], rows: distRows(s.vendor_risks, 'commercante', 'q6_risques', s.vendors_total) },
        ],
  });

  // ---- 5. zones
  sections.push({
    title: '5. Indicateurs par zone',
    blocks: studied.length === 0
      ? [{ type: 'para', text: 'Aucune zone avec des réponses pour l\'instant.' }]
      : [
          {
            type: 'table',
            headers: ['Zone', 'Acheteurs', 'Difficultés fréquentes', 'Intéressés', 'Commerçantes', 'Obs.', 'Personnes observées', 'Charges lourdes', 'Flux fort'],
            widths: [0.09, 0.11, 0.14, 0.11, 0.12, 0.07, 0.13, 0.12, 0.11],
            rows: studied.map((z) => [
              z.zone_code, String(z.buyers), `${z.buyers_often_difficulty} sur ${z.buyers}`, `${z.buyers_interested} sur ${z.buyers}`,
              String(z.vendors), String(z.observations), String(z.observed_people_total), String(z.observed_heavy_loads_total), String(z.observed_strong_flow_sessions),
            ]),
          },
          { type: 'para', style: 'note', text: 'Les effectifs par zone sont très petits : ces comparaisons sont indicatives et ne permettent pas de conclure qu\'une zone a un besoin supérieur à une autre. Les observations sont ponctuelles, ce n\'est pas un comptage complet de la fréquentation du marché.' },
        ],
  });

  // ---- 6. emplacements candidats
  const ev = summarizeEvaluations(inp.evaluations);
  const candidates = zones.filter((z) => z.is_candidate);
  sections.push({
    title: '6. Évaluation des emplacements candidats',
    blocks: candidates.length === 0
      ? [{ type: 'para', text: 'Aucune zone candidate n\'a été définie.' }]
      : [
          {
            type: 'table',
            headers: ['Zone', 'Éval.', ...EVAL_CRITERIA.map((c) => c.short), 'Total /35', 'Validation'],
            widths: [0.07, 0.06, 0.09, 0.1, 0.1, 0.09, 0.09, 0.1, 0.1, 0.09, 0.11],
            rows: candidates.map((z) => {
              const e = ev.get(z.id);
              return [
                z.code, String(e?.n ?? 0),
                ...EVAL_CRITERIA.map((c) => (e && e.averages[c.key] !== null ? String(e.averages[c.key]).replace('.', ',') : '-')),
                e && e.total !== null ? String(e.total).replace('.', ',') : '-',
                z.approval_status === 'VALIDE' ? `Validée le ${frDate(z.approved_at)}` : 'Non validée',
              ];
            }),
          },
          {
            type: 'para',
            style: 'note',
            text: `Notes moyennes de 1 (très défavorable) à 5 (très favorable) : ${EVAL_CRITERIA.map((c) => `${c.short} = ${c.label.toLowerCase()}`).join(' ; ')}. « Éval. » = nombre d'évaluations soumises.`,
          },
          {
            type: 'table',
            caption: 'Points à confirmer auprès du gestionnaire',
            headers: ['Zone', ...MANAGER_CHECK_ITEMS.map((i) => i.label)],
            widths: [0.1, 0.15, 0.15, 0.15, 0.15, 0.15, 0.15],
            rows: candidates.map((z) => [z.code, ...MANAGER_CHECK_ITEMS.map((i) => (z.manager_checks?.[i.key]?.done ? 'Confirmé' : 'À confirmer'))]),
          },
          { type: 'para', style: 'warning', text: 'Ce score est un outil de comparaison interne. Il ne vaut pas autorisation d\'occupation. Aucun emplacement n\'est « approuvé » sans validation explicite de l\'administrateur, et cette validation interne ne remplace ni l\'accord du gestionnaire du marché ni l\'autorisation de l\'ANaGeM.' },
        ],
  });

  // ---- 7. méthode et limites
  sections.push({
    title: '7. Méthode et limites de l\'enquête',
    blocks: [
      {
        type: 'bullets',
        items: [
          'Enquête exploratoire menée au marché moderne de Cococodji (Abomey-Calavi, Bénin) par plusieurs enquêteurs, par entretien court.',
          'Les personnes sont interrogées après consentement, de façon anonyme : aucun nom, numéro de téléphone ni photo n\'est collecté. Le refus de répondre est libre.',
          'Les échantillons sont petits et non aléatoires : les résultats ne sont pas nécessairement représentatifs de l\'ensemble des visiteurs du marché.',
          'Les réponses sont déclaratives : une intention d\'utilisation ou un prix déclaré n\'est pas une utilisation réelle.',
          'Les observations de flux sont ponctuelles (environ 15 minutes par zone et par créneau) et ne constituent pas un comptage complet.',
          'Les prix proposés ont été présentés dans un ordre alterné d\'une personne à l\'autre pour limiter l\'effet de la première option.',
        ],
      },
    ],
  });

  return {
    title: 'Cococodji Chariots - Rapport de synthèse de l\'enquête terrain',
    subtitle: mission ? mission.name : 'Enquête terrain',
    generatedAt: inp.generatedAt,
    notices: [NOT_AUTHORIZED, DISCLAIMER],
    sections,
  };
}

export const reportFileName = (generatedAt: string) => `Cococodji_Chariots_rapport_${fmtLocalDate(generatedAt) || 'synthese'}.pdf`;
void pct;
