import type { Block, ReportModel } from './report';

// Rendu du rapport en PDF (A4) avec jsPDF, chargé à la demande (uniquement sur l'écran Export).
// Police standard : on remplace les caractères typographiques qu'elle ne sait pas afficher.

export const pdfSafe = (s: string): string =>
  s
    .replace(/[‘’ʼ]/g, '\'')
    .replace(/[“”]/g, '"')
    .replace(/[–—]/g, '-')
    .replace(/…/g, '...')
    .replace(/[  ]/g, ' ')
    .replace(/≥/g, '>=')
    .replace(/≤/g, '<=');

const NAVY: [number, number, number] = [11, 37, 69];
const GRAY: [number, number, number] = [71, 84, 103];
const LINE: [number, number, number] = [201, 211, 223];
const WARN_BG: [number, number, number] = [254, 240, 199];
const WARN_TX: [number, number, number] = [147, 55, 13];
const NOTE_BG: [number, number, number] = [219, 231, 245];
const HEAD_BG: [number, number, number] = [11, 37, 69];

export async function renderReportPdf(model: ReportModel): Promise<Blob> {
  const { jsPDF } = await import('jspdf');
  const doc = new jsPDF({ unit: 'mm', format: 'a4', orientation: 'portrait' });
  const W = 210;
  const H = 297;
  const M = 16; // marges
  const CW = W - 2 * M;
  let y = M;
  let page = 1;

  const footer = () => {
    doc.setFont('helvetica', 'normal');
    doc.setFontSize(8);
    doc.setTextColor(...GRAY);
    doc.text(pdfSafe('Cococodji Chariots - Enquête exploratoire - projet à l\'étude, ni autorisé ni lancé'), M, H - 8);
    doc.text(`Page ${page}`, W - M, H - 8, { align: 'right' });
  };
  const newPage = () => {
    footer();
    doc.addPage();
    page++;
    y = M;
  };
  const need = (h: number) => {
    if (y + h > H - 16) newPage();
  };

  const wrap = (text: string, width: number, size: number, bold = false): string[] => {
    doc.setFont('helvetica', bold ? 'bold' : 'normal');
    doc.setFontSize(size);
    return doc.splitTextToSize(pdfSafe(text), width) as string[];
  };

  const paragraph = (text: string, style: 'normal' | 'note' | 'warning' = 'normal') => {
    const size = 10;
    const pad = style === 'normal' ? 0 : 3;
    const lines = wrap(text, CW - 2 * pad, size);
    const lh = 4.6;
    const h = lines.length * lh + 2 * pad;
    need(h + 2);
    if (style !== 'normal') {
      doc.setFillColor(...(style === 'warning' ? WARN_BG : NOTE_BG));
      doc.roundedRect(M, y, CW, h, 1.5, 1.5, 'F');
    }
    doc.setFont('helvetica', 'normal');
    doc.setFontSize(size);
    const txt: [number, number, number] = style === 'warning' ? WARN_TX : style === 'note' ? NAVY : [16, 24, 40];
    doc.setTextColor(...txt);
    lines.forEach((l, i) => doc.text(l, M + pad, y + pad + 3.6 + i * lh));
    y += h + 3;
  };

  const bullets = (items: string[]) => {
    const size = 10;
    const lh = 4.6;
    for (const it of items) {
      const lines = wrap(it, CW - 6, size);
      need(lines.length * lh + 1.5);
      doc.setFont('helvetica', 'normal');
      doc.setFontSize(size);
      doc.setTextColor(16, 24, 40);
      doc.text('-', M + 1, y + 3.6);
      lines.forEach((l, i) => doc.text(l, M + 6, y + 3.6 + i * lh));
      y += lines.length * lh + 1.5;
    }
    y += 1.5;
  };

  const table = (b: Extract<Block, { type: 'table' }>) => {
    const n = b.headers.length;
    const widths = (b.widths && b.widths.length === n ? b.widths : Array(n).fill(1 / n)).map((w) => w * CW);
    const size = n > 8 ? 7 : 8.5;
    const lh = size * 0.42;
    const padX = 1.6;
    const padY = 1.6;
    const cellLines = (row: string[], bold: boolean) => row.map((c, i) => wrap(c, widths[i] - 2 * padX, size, bold));
    const rowHeight = (lines: string[][]) => Math.max(...lines.map((l) => l.length)) * lh + 2 * padY;
    const drawRow = (row: string[], header: boolean, shade: boolean) => {
      const lines = cellLines(row, header);
      const h = rowHeight(lines);
      let x = M;
      if (header) {
        doc.setFillColor(...HEAD_BG);
        doc.rect(M, y, CW, h, 'F');
      } else if (shade) {
        doc.setFillColor(238, 242, 246);
        doc.rect(M, y, CW, h, 'F');
      }
      doc.setFont('helvetica', header ? 'bold' : 'normal');
      doc.setFontSize(size);
      doc.setTextColor(...(header ? ([255, 255, 255] as [number, number, number]) : ([16, 24, 40] as [number, number, number])));
      lines.forEach((ls, i) => {
        ls.forEach((l, k) => doc.text(l, x + padX, y + padY + 2.9 + k * lh));
        x += widths[i];
      });
      doc.setDrawColor(...LINE);
      doc.line(M, y + h, M + CW, y + h);
      y += h;
      return h;
    };
    const headerH = rowHeight(cellLines(b.headers, true));
    const firstH = b.rows.length ? rowHeight(cellLines(b.rows[0], false)) : 0;
    // la légende, l'en-tête et au moins la première ligne restent toujours ensemble
    need((b.caption ? 6.5 : 0) + headerH + firstH + 4);
    if (b.caption) {
      doc.setFont('helvetica', 'bold');
      doc.setFontSize(10);
      doc.setTextColor(...NAVY);
      doc.text(pdfSafe(b.caption), M, y + 4);
      y += 6.5;
    }
    drawRow(b.headers, true, false);
    b.rows.forEach((r, idx) => {
      const h = rowHeight(cellLines(r, false));
      if (y + h > H - 16) {
        newPage();
        drawRow(b.headers, true, false); // l'en-tête est répétée à chaque page
      }
      drawRow(r, false, idx % 2 === 1);
    });
    y += 5;
  };

  // ---- page de titre (le titre peut tenir sur plusieurs lignes : la bannière s'adapte)
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(17);
  const titleLines = doc.splitTextToSize(pdfSafe(model.title), CW) as string[];
  const bannerH = 10 + titleLines.length * 7.5 + 12;
  doc.setFillColor(...NAVY);
  doc.rect(0, 0, W, bannerH, 'F');
  doc.setTextColor(255, 255, 255);
  titleLines.forEach((l, i) => doc.text(l, M, 14 + i * 7.5));
  doc.setFont('helvetica', 'normal');
  doc.setFontSize(11);
  doc.text(pdfSafe(model.subtitle), M, 14 + titleLines.length * 7.5 + 3, { maxWidth: CW });
  y = bannerH + 8;
  doc.setTextColor(...GRAY);
  doc.setFontSize(9);
  doc.text(pdfSafe(`Document généré le ${model.generatedAt.slice(0, 10).split('-').reverse().join('/')} à partir des données enregistrées dans la base commune.`), M, y);
  y += 7;
  model.notices.forEach((n, i) => paragraph(n, i === 0 ? 'note' : 'warning'));
  y += 2;

  for (const s of model.sections) {
    need(48);
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(13);
    doc.setTextColor(...NAVY);
    doc.text(pdfSafe(s.title), M, y + 5);
    doc.setDrawColor(...NAVY);
    doc.setLineWidth(0.4);
    doc.line(M, y + 7, M + CW, y + 7);
    y += 11;
    for (const b of s.blocks) {
      if (b.type === 'para') paragraph(b.text, b.style);
      else if (b.type === 'bullets') bullets(b.items);
      else table(b);
    }
    y += 2;
  }
  footer();
  return doc.output('blob');
}
