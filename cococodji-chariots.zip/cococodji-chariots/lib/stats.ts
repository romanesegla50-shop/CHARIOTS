import type { Ratio } from './admin';
import { FORMS } from './forms';
import type { FormType } from './types';

export const DISCLAIMER =
  'Ces résultats proviennent d’une enquête exploratoire. Ils ne sont pas nécessairement représentatifs de l’ensemble des visiteurs du marché et ne garantissent pas la rentabilité du projet.';

export const NOT_AUTHORIZED =
  'Projet à l’étude : le service de chariots n’est ni autorisé ni lancé. Aucune autorisation n’a été accordée.';

export const CONFUSION_WARNING =
  'Intérêt déclaré, volonté déclarée de payer, utilisation réelle et rentabilité sont quatre choses différentes : cette enquête ne mesure que les deux premières, et seulement ce que les personnes disent.';

export const pct = (r: Ratio): string => (r.d > 0 ? `${Math.round((r.n / r.d) * 100)} %` : '—');

/** « 21 sur 30 répondants valides, soit 70 % » (jamais un pourcentage sans sa base de calcul). */
export function ratioText(r: Ratio, noun = 'répondants valides'): string {
  if (r.d === 0) return `aucun ${noun.replace(/s$/, '')} pour l’instant`;
  return `${r.n} sur ${r.d} ${noun}, soit ${pct(r)}`;
}

export interface DistRow {
  key: string;
  label: string;
  count: number;
  pct: string;
  share: number;
}

export function distribution(obj: Record<string, number> | undefined, labelOf: (k: string) => string, base?: number): DistRow[] {
  const entries = Object.entries(obj ?? {});
  const total = base ?? entries.reduce((s, [, c]) => s + Number(c), 0);
  return entries
    .map(([key, count]) => ({
      key,
      label: labelOf(key),
      count: Number(count),
      pct: total > 0 ? `${Math.round((Number(count) / total) * 100)} %` : '—',
      share: total > 0 ? Number(count) / total : 0,
    }))
    .sort((a, b) => b.count - a.count || a.label.localeCompare(b.label, 'fr'));
}

/** Libellé français d'une valeur de réponse (« PRESQUE_CHAQUE_VISITE » -> « Presque à chaque visite »). */
export function optionLabel(form: FormType, key: string, value: string): string {
  const q = FORMS[form].steps.flatMap((s) => s.questions).find((x) => x.key === key);
  return q?.options?.find((o) => o.value === value)?.label ?? value;
}

/** Volonté déclarée de payer : tous les prix choisis sauf « Je ne paierais pas » (valeur déclarée, pas une utilisation réelle). */
export function willingToPay(priceDistribution: Record<string, number>): Ratio {
  const d = Object.values(priceDistribution).reduce((s, c) => s + Number(c), 0);
  const n = d - Number(priceDistribution.NE_PAIERAIT_PAS ?? 0);
  return { n, d };
}

// ------------------------------------------------------------------ évaluation des emplacements candidats
export const EVAL_CRITERIA: { key: string; label: string; short: string }[] = [
  { key: 'score_flux', label: 'Flux de clients', short: 'Flux' },
  { key: 'score_zones_lourdes', label: 'Proximité des achats lourds', short: 'Achats lourds' },
  { key: 'score_acces_sortie', label: 'Accès sortie / parking', short: 'Accès sortie' },
  { key: 'score_passage', label: 'Largeur et qualité du passage', short: 'Passage' },
  { key: 'score_retour_chariots', label: 'Retour des chariots', short: 'Retour' },
  { key: 'score_surveillance', label: 'Surveillance', short: 'Surveill.' },
  { key: 'score_faible_encombrement', label: 'Faible encombrement', short: 'Faible encomb.' },
];

export interface EvalRow {
  zone_id: string | null;
  status: string;
  [k: string]: unknown;
}

export interface ZoneEvalSummary {
  zone_id: string;
  n: number;
  averages: Record<string, number | null>;
  total: number | null; // somme des moyennes, sur 35
}

const round1 = (x: number) => Math.round(x * 10) / 10;

export function summarizeEvaluations(rows: EvalRow[]): Map<string, ZoneEvalSummary> {
  const byZone = new Map<string, EvalRow[]>();
  for (const r of rows) {
    if (r.status !== 'SOUMIS' || !r.zone_id) continue;
    byZone.set(r.zone_id, [...(byZone.get(r.zone_id) ?? []), r]);
  }
  const out = new Map<string, ZoneEvalSummary>();
  for (const [zone_id, list] of byZone) {
    const averages: Record<string, number | null> = {};
    let total = 0;
    for (const c of EVAL_CRITERIA) {
      const vals = list.map((r) => Number(r[c.key])).filter((v) => Number.isFinite(v));
      averages[c.key] = vals.length ? round1(vals.reduce((s, v) => s + v, 0) / vals.length) : null;
      if (averages[c.key] !== null) total += vals.reduce((s, v) => s + v, 0) / vals.length;
    }
    out.set(zone_id, { zone_id, n: list.length, averages, total: round1(total) });
  }
  return out;
}
