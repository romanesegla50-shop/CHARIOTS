import type { SupabaseClient } from '@supabase/supabase-js';
import type { FormType, Profile, ReferenceMission, ReferenceZone } from './types';

// Accès aux données de l'espace administrateur. Toutes les règles d'accès sont appliquées par la base
// (RLS) : si un enquêteur appelait ces fonctions, la base refuserait ou ne renverrait rien.

export type ResponseTable = 'buyer_responses' | 'vendor_responses' | 'observation_sessions' | 'zone_evaluations';

export const RESPONSE_TABLES: { table: ResponseTable; kind: FormType; label: string }[] = [
  { table: 'buyer_responses', kind: 'acheteur', label: 'Acheteurs' },
  { table: 'vendor_responses', kind: 'commercante', label: 'Commerçantes' },
  { table: 'observation_sessions', kind: 'observation', label: 'Observations' },
  { table: 'zone_evaluations', kind: 'evaluation', label: 'Évaluations de zones' },
];

export const TABLE_LABEL: Record<string, string> = {
  buyer_responses: 'Réponse acheteur',
  vendor_responses: 'Réponse commerçante',
  observation_sessions: 'Observation',
  zone_evaluations: 'Évaluation de zone',
  missions: 'Mission',
  zones: 'Zone',
  profiles: 'Compte',
  mission_members: 'Participant',
  refusals: 'Refus (compteur)',
};

export type ResponseStatus = 'BROUILLON' | 'SOUMIS' | 'EXCLU';
export const STATUS_LABEL: Record<ResponseStatus, string> = {
  BROUILLON: 'Brouillon',
  SOUMIS: 'Soumise',
  EXCLU: 'Exclue',
};

export interface ServerRow {
  id: string;
  mission_id: string;
  zone_id: string | null;
  surveyor_id: string;
  status: ResponseStatus;
  version: number;
  created_at: string;
  updated_at: string;
  submitted_at: string | null;
  synced_at: string;
  [key: string]: unknown;
}

export type Result<T = void> = { ok: true; data: T } | { ok: false; error: string; conflict?: boolean; code?: string };

interface PgError {
  code?: string;
  message?: string;
}

/** Traduit les erreurs de la base en messages compréhensibles. */
export function explainError(e: PgError | null | undefined): string {
  if (!e) return 'Erreur inconnue.';
  const m = e.message ?? '';
  switch (e.code) {
    case 'PT409':
      return 'Cette fiche a été modifiée ailleurs entre-temps. Rechargez la liste puis refaites la modification.';
    case '42501':
      return /administrateur/i.test(m) ? m : 'Droits insuffisants pour cette action.';
    case '23505':
      return 'Cette valeur existe déjà (par exemple un code de zone en double).';
    case '23503':
      return 'Impossible : cet élément est encore utilisé ailleurs (par exemple une zone qui a déjà des réponses).';
    case '23514':
      return /3 zones candidates/i.test(m)
        ? 'Maximum 3 zones candidates. Retirez-en une avant d’en ajouter une autre.'
        : /candidate/i.test(m) || /approval/i.test(m)
          ? 'Une zone doit d’abord être candidate pour pouvoir être validée.'
          : 'Valeur refusée par la base : vérifiez les champs.';
    default:
      return /fetch|network|failed/i.test(m) ? 'Pas de connexion : réessayez avec du réseau.' : m || 'Erreur inconnue.';
  }
}

const ok = <T>(data: T): Result<T> => ({ ok: true, data });
const fail = (e: PgError): Result<never> => ({ ok: false, error: explainError(e), conflict: e.code === 'PT409', code: e.code });

/** Lit toutes les lignes d'une requête par pages de 500 (la limite d'une requête est de 1000 lignes). */
export async function fetchAll<T>(
  c: SupabaseClient,
  table: string,
  build: (q: any) => any = (q) => q,
  columns = '*',
  orderBy = 'created_at',
): Promise<Result<T[]>> {
  const out: T[] = [];
  const size = 500;
  for (let from = 0; ; from += size) {
    let q = c.from(table).select(columns);
    q = build(q);
    const { data, error } = await q.order(orderBy, { ascending: true }).order('id', { ascending: true }).range(from, from + size - 1);
    if (error) return fail(error);
    out.push(...((data ?? []) as T[]));
    if (!data || data.length < size) break;
    if (from > 100000) break; // garde-fou
  }
  return ok(out);
}

// ------------------------------------------------------------------ équipe
export async function listProfiles(c: SupabaseClient): Promise<Result<Profile[]>> {
  const { data, error } = await c.from('profiles').select('id,email,full_name,role,active').order('email');
  if (error) return fail(error);
  return ok((data ?? []) as Profile[]);
}

export async function updateProfile(
  c: SupabaseClient,
  id: string,
  patch: Partial<Pick<Profile, 'active' | 'role' | 'full_name'>>,
): Promise<Result> {
  const { data, error } = await c.from('profiles').update(patch).eq('id', id).select('id');
  if (error) return fail(error);
  if (!data || data.length === 0) return { ok: false, error: 'Aucune modification : droits insuffisants ou compte introuvable.' };
  return ok(undefined);
}

export async function listMembers(c: SupabaseClient, missionId: string): Promise<Result<string[]>> {
  const { data, error } = await c.from('mission_members').select('user_id').eq('mission_id', missionId);
  if (error) return fail(error);
  return ok((data ?? []).map((r: { user_id: string }) => r.user_id));
}

export async function setMember(c: SupabaseClient, missionId: string, userId: string, on: boolean): Promise<Result> {
  if (on) {
    const { error } = await c.from('mission_members').upsert({ mission_id: missionId, user_id: userId }, { onConflict: 'mission_id,user_id', ignoreDuplicates: true });
    return error ? fail(error) : ok(undefined);
  }
  const { error } = await c.from('mission_members').delete().eq('mission_id', missionId).eq('user_id', userId);
  return error ? fail(error) : ok(undefined);
}

// ------------------------------------------------------------------ mission
export interface MissionInput {
  name: string;
  start_date: string | null;
  end_date: string | null;
  status: ReferenceMission['status'];
  instructions: string | null;
  target_buyers: number;
  target_vendors: number;
  target_observations: number;
}

export function validateMission(m: MissionInput): string | null {
  if (!m.name.trim()) return 'Le nom de la mission est obligatoire.';
  if (m.start_date && m.end_date && m.end_date < m.start_date) return 'La date de fin doit être après la date de début.';
  for (const [label, v] of [['acheteurs', m.target_buyers], ['commerçantes', m.target_vendors], ['sessions d’observation', m.target_observations]] as const) {
    if (!Number.isInteger(v) || v < 0 || v > 100000) return `L’objectif « ${label} » doit être un nombre entier positif.`;
  }
  return null;
}

export async function listMissions(c: SupabaseClient): Promise<Result<(ReferenceMission & { created_at: string })[]>> {
  const { data, error } = await c.from('missions').select('*').order('created_at', { ascending: false });
  if (error) return fail(error);
  return ok((data ?? []) as (ReferenceMission & { created_at: string })[]);
}

export async function saveMission(c: SupabaseClient, id: string | null, m: MissionInput): Promise<Result<string>> {
  const problem = validateMission(m);
  if (problem) return { ok: false, error: problem };
  const row = { ...m, name: m.name.trim(), instructions: m.instructions?.trim() || null };
  if (id) {
    const { data, error } = await c.from('missions').update(row).eq('id', id).select('id');
    if (error) return fail(error);
    if (!data?.length) return { ok: false, error: 'Aucune modification : droits insuffisants.' };
    return ok(id);
  }
  const { data, error } = await c.from('missions').insert(row).select('id').single();
  if (error) return fail(error);
  return ok((data as { id: string }).id);
}

// ------------------------------------------------------------------ zones
export interface ManagerCheck {
  done: boolean;
  note: string;
}
export type ManagerChecks = Record<string, ManagerCheck>;

/** Points à confirmer auprès du gestionnaire avant toute demande (Module E). */
export const MANAGER_CHECK_ITEMS: { key: string; label: string }[] = [
  { key: 'espace', label: 'Espace réellement disponible' },
  { key: 'stationnement', label: 'Autorisation de stationnement' },
  { key: 'trajets', label: 'Trajets permis' },
  { key: 'horaires', label: 'Horaires' },
  { key: 'securite', label: 'Règles de sécurité' },
  { key: 'frais', label: 'Frais éventuels' },
];

export interface FullZone extends ReferenceZone {
  mission_id: string;
  manager_checks: ManagerChecks;
  approved_by: string | null;
  approved_at: string | null;
}

export async function listZones(c: SupabaseClient, missionId: string): Promise<Result<FullZone[]>> {
  const { data, error } = await c.from('zones').select('*').eq('mission_id', missionId).order('code');
  if (error) return fail(error);
  return ok(((data ?? []) as FullZone[]).map((z) => ({ ...z, manager_checks: (z.manager_checks ?? {}) as ManagerChecks })));
}

export function validateZoneCode(code: string): string | null {
  const v = code.trim();
  if (!v) return 'Le code de zone est obligatoire.';
  if (!/^[A-Za-z0-9_-]{1,10}$/.test(v)) return 'Code de zone : 1 à 10 caractères (lettres, chiffres, - ou _), par exemple Z01.';
  return null;
}

export interface ZoneInput {
  code: string;
  label: string | null;
  description: string | null;
  sector: string | null;
}

export async function createZone(c: SupabaseClient, missionId: string, z: ZoneInput): Promise<Result<string>> {
  const problem = validateZoneCode(z.code);
  if (problem) return { ok: false, error: problem };
  const { data, error } = await c
    .from('zones')
    .insert({ mission_id: missionId, code: z.code.trim(), label: z.label?.trim() || null, description: z.description?.trim() || null, sector: z.sector?.trim() || null })
    .select('id')
    .single();
  if (error) return fail(error);
  return ok((data as { id: string }).id);
}

export async function updateZone(c: SupabaseClient, id: string, patch: Record<string, unknown>): Promise<Result> {
  if (typeof patch.code === 'string') {
    const problem = validateZoneCode(patch.code);
    if (problem) return { ok: false, error: problem };
  }
  const { data, error } = await c.from('zones').update(patch).eq('id', id).select('id');
  if (error) return fail(error);
  if (!data?.length) return { ok: false, error: 'Aucune modification : droits insuffisants.' };
  return ok(undefined);
}

export async function deleteZone(c: SupabaseClient, id: string): Promise<Result> {
  const { error } = await c.from('zones').delete().eq('id', id);
  return error ? fail(error) : ok(undefined);
}

// ------------------------------------------------------------------ réponses (consultation, correction, exclusion, suppression)
export async function updateResponse(
  c: SupabaseClient,
  table: ResponseTable,
  id: string,
  version: number,
  patch: Record<string, unknown>,
): Promise<Result<ServerRow>> {
  // « version » = celle que l'on a lue : si quelqu'un a modifié entre-temps, la base refuse (conflit explicite)
  const { data, error } = await c.from(table).update({ ...patch, version }).eq('id', id).select('*');
  if (error) return fail(error);
  if (!data?.length) return { ok: false, error: 'Aucune modification : droits insuffisants ou fiche introuvable.' };
  return ok(data[0] as ServerRow);
}

export const setResponseStatus = (c: SupabaseClient, table: ResponseTable, id: string, version: number, status: ResponseStatus) =>
  updateResponse(c, table, id, version, { status });

export async function deleteResponse(c: SupabaseClient, table: ResponseTable, id: string): Promise<Result> {
  const { data, error } = await c.from(table).delete().eq('id', id).select('id');
  if (error) return fail(error);
  if (!data?.length) return { ok: false, error: 'Aucune suppression : droits insuffisants ou fiche déjà supprimée.' };
  return ok(undefined);
}

// ------------------------------------------------------------------ journal d'audit
export interface AuditEntry {
  id: number;
  at: string;
  actor_id: string | null;
  actor_role: string | null;
  table_name: string;
  record_id: string | null;
  action: 'INSERT' | 'UPDATE' | 'DELETE';
  old_data: Record<string, unknown> | null;
  new_data: Record<string, unknown> | null;
}

export async function fetchAudit(c: SupabaseClient, limit = 100): Promise<Result<AuditEntry[]>> {
  const { data, error } = await c.from('audit_log').select('*').order('at', { ascending: false }).order('id', { ascending: false }).limit(limit);
  if (error) return fail(error);
  return ok((data ?? []) as AuditEntry[]);
}

const AUDIT_IGNORED = new Set(['updated_at', 'synced_at', 'version', 'submitted_at']);

/** Champs réellement modifiés entre l'ancienne et la nouvelle valeur (hors champs techniques). */
export function auditChanges(e: Pick<AuditEntry, 'old_data' | 'new_data' | 'action'>): { field: string; before: unknown; after: unknown }[] {
  const o = e.old_data ?? {};
  const n = e.new_data ?? {};
  const keys = new Set([...Object.keys(o), ...Object.keys(n)]);
  const out: { field: string; before: unknown; after: unknown }[] = [];
  for (const k of keys) {
    if (AUDIT_IGNORED.has(k)) continue;
    if (JSON.stringify(o[k]) !== JSON.stringify(n[k])) out.push({ field: k, before: o[k], after: n[k] });
  }
  return out;
}

// ------------------------------------------------------------------ synthèse (Module F)
export interface Ratio {
  n: number;
  d: number;
}

export interface ZoneSummary {
  zone_id: string;
  zone_code: string;
  buyers: number;
  buyers_often_difficulty: number;
  buyers_interested: number;
  vendors: number;
  observations: number;
  observed_people_total: number;
  observed_heavy_loads_total: number;
  observed_strong_flow_sessions: number;
}

export interface Summary {
  generated_at: string;
  basis: string;
  filters: { from: string | null; to: string | null; surveyor: string | null; zone: string | null };
  buyers_total: number;
  vendors_total: number;
  observations_total: number;
  zones_studied: number;
  buyers_often_difficulty: Ratio;
  buyers_interested: Ratio;
  buyers_two_trips_or_more: Ratio;
  vendors_clients_often_difficulty: Ratio;
  vendors_clients_would_use: Ratio;
  price_distribution: Record<string, number>;
  price_other_amounts_fcfa: number[];
  deposit_reaction: Record<string, number>;
  difficulties: Record<string, number>;
  concerns: Record<string, number>;
  vendor_risks: Record<string, number>;
  zones: ZoneSummary[];
  observation_slots: { zone_code: string; date: string; start: string; end: string }[];
  first_date: string | null;
  last_date: string | null;
  drafts: { buyers: number; vendors: number; observations: number };
  excluded: { buyers: number; vendors: number; observations: number };
  refusals: number;
}

export interface SummaryFilters {
  from?: string | null;
  to?: string | null;
  surveyor?: string | null;
  zone?: string | null;
}

export async function fetchSummary(c: SupabaseClient, missionId: string, f: SummaryFilters = {}): Promise<Result<Summary>> {
  const { data, error } = await c.rpc('survey_summary', {
    p_mission: missionId,
    p_from: f.from || null,
    p_to: f.to || null,
    p_surveyor: f.surveyor || null,
    p_zone: f.zone || null,
  });
  if (error) return fail(error);
  return ok(data as Summary);
}
