import type { RecordKind, ReferenceZone } from './types';

export const KIND_LABEL: Record<RecordKind, string> = {
  acheteur: 'Acheteur',
  commercante: 'Commerçante',
  observation: 'Observation',
  evaluation: 'Évaluation de zone',
  refus: 'Refus (compteur)',
};

export function zoneCode(zones: ReferenceZone[], id: string | null | undefined): string {
  if (!id) return '—';
  return zones.find((z) => z.id === id)?.code ?? '?';
}
