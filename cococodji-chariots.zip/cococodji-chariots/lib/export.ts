import { FORMS, type Question } from './forms';
import type { FullZone, ServerRow, Summary } from './admin';
import { STATUS_LABEL, type ResponseStatus } from './admin';
import { EVAL_CRITERIA, summarizeEvaluations, optionLabel, willingToPay, distribution } from './stats';
import { MANAGER_CHECK_ITEMS } from './admin';
import type { Profile, ReferenceMission } from './types';

// Exports : un tableau par questionnaire (jamais mélangés), en-têtes explicites en français, UTF-8.

export type Cell = string | number | null;
export interface Dataset {
  name: string; // nom de la feuille / du fichier
  headers: string[];
  rows: Cell[][];
}

export interface ExportContext {
  zones: Pick<FullZone, 'id' | 'code' | 'label'>[];
  profiles: Pick<Profile, 'id' | 'full_name' | 'email'>[];
}

// ------------------------------------------------------------------ dates (heure du Bénin)
const TZ = 'Africa/Porto-Novo';
const dtf = new Intl.DateTimeFormat('en-GB', {
  timeZone: TZ, year: 'numeric', month: '2-digit', day: '2-digit', hour: '2-digit', minute: '2-digit', hourCycle: 'h23',
});
function parts(iso: string): Record<string, string> | null {
  const d = new Date(iso);
  if (Number.isNaN(d.getTime())) return null;
  return Object.fromEntries(dtf.formatToParts(d).map((p) => [p.type, p.value]));
}
/** « 2026-11-02 09:15 » en heure du Bénin (UTC+1). */
export function fmtLocal(iso: unknown): string {
  if (typeof iso !== 'string' || !iso) return '';
  const p = parts(iso);
  return p ? `${p.year}-${p.month}-${p.day} ${p.hour}:${p.minute}` : '';
}
export function fmtLocalDate(iso: unknown): string {
  return fmtLocal(iso).slice(0, 10);
}

// ------------------------------------------------------------------ colonnes
interface Col {
  header: string;
  get: (row: ServerRow, ctx: ExportContext) => Cell;
}

const zoneCode = (ctx: ExportContext, id: unknown) => (typeof id === 'string' ? ctx.zones.find((z) => z.id === id)?.code ?? '?' : '');
const surveyorName = (ctx: ExportContext, id: string) => {
  const p = ctx.profiles.find((x) => x.id === id);
  return p ? p.full_name?.trim() || p.email || id.slice(0, 8) : id.slice(0, 8);
};

function common(): Col[] {
  return [
    { header: 'ID de la fiche', get: (r) => r.id },
    { header: 'Statut', get: (r) => STATUS_LABEL[r.status as ResponseStatus] ?? r.status },
    { header: 'Enquêteur', get: (r, c) => surveyorName(c, r.surveyor_id) },
    { header: 'Zone (code)', get: (r, c) => zoneCode(c, r.zone_id) },
  ];
}

/** Colonne issue d'une question : valeurs traduites en libellés français, listes séparées par « | ». */
function q(form: 'acheteur' | 'commercante' | 'observation' | 'evaluation', key: string, header: string): Col {
  const def = FORMS[form].steps.flatMap((s) => s.questions).find((x) => x.key === key) as Question | undefined;
  return {
    header,
    get: (r, c) => {
      const v = r[key];
      if (v === null || v === undefined || v === '') return '';
      if (def?.type === 'zone') return zoneCode(c, v);
      if (Array.isArray(v)) return v.map((x) => optionLabel(form, key, String(x))).join(' | ');
      if (def?.type === 'single') return optionLabel(form, key, String(v));
      if (typeof v === 'number') return v;
      if ((key === 'start_time' || key === 'end_time') && typeof v === 'string') return v.slice(0, 5);
      return String(v);
    },
  };
}
const text = (key: string, header: string): Col => ({ header, get: (r) => (r[key] === null || r[key] === undefined ? '' : String(r[key])) });

const BUYER_COLS: Col[] = [
  ...common(),
  { header: 'Début de l’entretien', get: (r) => fmtLocal(r.started_at) },
  { header: 'Fin de l’entretien', get: (r) => fmtLocal(r.ended_at) },
  { header: 'Consentement', get: (r) => (r.consent ? 'Oui' : 'Non') },
  q('acheteur', 'q1_transporte', 'Q1 Transporte des achats jusqu’à un point de récupération'),
  q('acheteur', 'q2_frequence', 'Q2 Fréquence des difficultés'),
  q('acheteur', 'q3_difficultes', 'Q3 Difficultés principales'),
  text('q3_autre', 'Q3 Autre difficulté (texte)'),
  q('acheteur', 'q4_mode_transport', 'Q4 Mode de transport actuel'),
  text('q4_autre', 'Q4 Autre mode (texte)'),
  q('acheteur', 'q5_nb_trajets', 'Q5 Nombre de trajets'),
  q('acheteur', 'q6_utilisation', 'Q6 Utiliserait un chariot autorisé'),
  q('acheteur', 'q7_trajet_utile', 'Q7 Trajet le plus utile'),
  text('q7_autre', 'Q7 Autre trajet (texte)'),
  q('acheteur', 'q8_moment_utile', 'Q8 Moment le plus utile'),
  text('q8_autre', 'Q8 Autre moment (texte)'),
  q('acheteur', 'q9_paiement', 'Q9 Mode de paiement préféré'),
  text('q9_autre', 'Q9 Autre mode de paiement (texte)'),
  q('acheteur', 'q10_prix', 'Q10 Prix jugé acceptable'),
  q('acheteur', 'q10_montant_fcfa', 'Q10 Autre montant (FCFA)'),
  text('q10_ordre_options', 'Q10 Ordre de présentation des prix'),
  q('acheteur', 'q11_caution', 'Q11 Caution remboursable : découragement'),
  q('acheteur', 'q12_inquietude', 'Q12 Principale inquiétude'),
  text('q12_autre', 'Q12 Autre inquiétude (texte)'),
  text('q13_remarque', 'Q13 Remarque ou suggestion'),
  { header: 'Version du formulaire', get: (r) => String(r.form_version ?? '') },
  { header: 'Créée le', get: (r) => fmtLocal(r.created_at) },
  { header: 'Soumise le', get: (r) => fmtLocal(r.submitted_at) },
  { header: 'Version de la fiche', get: (r) => r.version },
];

const VENDOR_COLS: Col[] = [
  ...common(),
  { header: 'Début de l’entretien', get: (r) => fmtLocal(r.started_at) },
  { header: 'Fin de l’entretien', get: (r) => fmtLocal(r.ended_at) },
  { header: 'Consentement', get: (r) => (r.consent ? 'Oui' : 'Non') },
  q('commercante', 'q1_difficultes_clients', 'Q1 Clients en difficulté pour transporter'),
  q('commercante', 'q2_produits', 'Q2 Produits ou achats difficiles'),
  text('q2_autre', 'Q2 Autre produit (texte)'),
  q('commercante', 'q3_comportement', 'Q3 Ce que font les clients'),
  text('q3_autre', 'Q3 Autre comportement (texte)'),
  text('q4_secteur_texte', 'Q4 Secteur ou trajet où un chariot serait utile'),
  { header: 'Q4 Zone concernée (code)', get: (r, c) => zoneCode(c, r.q4_zone_id) },
  q('commercante', 'q5_moment', 'Q5 Moment où le besoin est le plus fort'),
  q('commercante', 'q6_risques', 'Q6 Risques ou difficultés anticipés'),
  text('q6_autre', 'Q6 Autre risque (texte)'),
  q('commercante', 'q7_utiliseraient', 'Q7 Les clients utiliseraient le service'),
  text('q8_pourquoi', 'Q8 Pourquoi'),
  text('q9_suggestion', 'Q9 Autre suggestion'),
  { header: 'Version du formulaire', get: (r) => String(r.form_version ?? '') },
  { header: 'Créée le', get: (r) => fmtLocal(r.created_at) },
  { header: 'Soumise le', get: (r) => fmtLocal(r.submitted_at) },
  { header: 'Version de la fiche', get: (r) => r.version },
];

const OBS_COLS: Col[] = [
  ...common(),
  text('observed_on', 'Date'),
  q('observation', 'start_time', 'Heure de début'),
  q('observation', 'end_time', 'Heure de fin'),
  q('observation', 'people_count', 'Personnes passant dans la zone (approx.)'),
  q('observation', 'heavy_load_count', 'Personnes avec plusieurs sacs ou charges encombrantes'),
  q('observation', 'multiple_trips_count', 'Personnes semblant faire plusieurs trajets'),
  q('observation', 'help_or_porter_count', 'Personnes demandant de l’aide ou utilisant un porteur'),
  q('observation', 'flow_level', 'Niveau de flux piéton'),
  q('observation', 'obstacles', 'Obstacles visibles'),
  text('obstacles_autre', 'Autre obstacle (texte)'),
  q('observation', 'distance_exit_m', 'Distance vers sortie ou parking (m)'),
  q('observation', 'trolley_access', 'Accessibilité potentielle pour un chariot'),
  q('observation', 'congestion_risk', 'Risque potentiel d’encombrement'),
  text('comments', 'Commentaires factuels'),
  { header: 'Version du formulaire', get: (r) => String(r.form_version ?? '') },
  { header: 'Créée le', get: (r) => fmtLocal(r.created_at) },
  { header: 'Soumise le', get: (r) => fmtLocal(r.submitted_at) },
  { header: 'Version de la fiche', get: (r) => r.version },
];

const EVAL_COLS: Col[] = [
  ...common(),
  ...EVAL_CRITERIA.map((c) => q('evaluation', c.key, `${c.label} (1 à 5)`)),
  text('notes', 'Notes et commentaires'),
  { header: 'Créée le', get: (r) => fmtLocal(r.created_at) },
  { header: 'Soumise le', get: (r) => fmtLocal(r.submitted_at) },
];

function table(name: string, cols: Col[], rows: ServerRow[], ctx: ExportContext): Dataset {
  return { name, headers: cols.map((c) => c.header), rows: rows.map((r) => cols.map((c) => c.get(r, ctx))) };
}

export interface ExportData {
  buyers: ServerRow[];
  vendors: ServerRow[];
  observations: ServerRow[];
  evaluations: ServerRow[];
  zones: FullZone[];
  mission: ReferenceMission | null;
  /** false = uniquement les fiches au statut « Soumise » (par défaut) */
  includeAll: boolean;
}

const keep = (rows: ServerRow[], includeAll: boolean) => (includeAll ? rows : rows.filter((r) => r.status === 'SOUMIS'));
const byDate = (a: ServerRow, b: ServerRow) => String(a.created_at).localeCompare(String(b.created_at));

export function buildDatasets(d: ExportData, ctx: ExportContext) {
  const buyers = table('Acheteurs', BUYER_COLS, keep(d.buyers, d.includeAll).sort(byDate), ctx);
  const vendors = table('Commerçantes', VENDOR_COLS, keep(d.vendors, d.includeAll).sort(byDate), ctx);
  const observations = table('Observations', OBS_COLS, keep(d.observations, d.includeAll).sort(byDate), ctx);
  const evaluations = table('Évaluations détaillées', EVAL_COLS, keep(d.evaluations, d.includeAll).sort(byDate), ctx);
  return { buyers, vendors, observations, evaluations, candidates: buildCandidateZones(d, ctx) };
}

/** Zones candidates : moyennes des notes, validation de l'administrateur et points à confirmer auprès du gestionnaire. */
export function buildCandidateZones(d: ExportData, ctx: ExportContext): Dataset {
  const ev = summarizeEvaluations(d.evaluations);
  const headers = [
    'Zone (code)', 'Libellé', 'Secteur général', 'Description', 'Nombre d’évaluations soumises',
    ...EVAL_CRITERIA.map((c) => `Moyenne : ${c.label}`),
    'Total des moyennes (sur 35)',
    'Validation par l’administrateur', 'Validée le',
    ...MANAGER_CHECK_ITEMS.flatMap((i) => [`À confirmer : ${i.label}`, `Note : ${i.label}`]),
  ];
  const rows: Cell[][] = d.zones
    .filter((z) => z.is_candidate)
    .map((z) => {
      const s = ev.get(z.id);
      return [
        z.code, z.label ?? '', z.sector ?? '', z.description ?? '', s?.n ?? 0,
        ...EVAL_CRITERIA.map((c) => s?.averages[c.key] ?? ''),
        s?.total ?? '',
        z.approval_status === 'VALIDE' ? 'Validée par l’administrateur' : 'Non validée',
        z.approved_at ? fmtLocalDate(z.approved_at) : '',
        ...MANAGER_CHECK_ITEMS.flatMap((i) => {
          const c = z.manager_checks?.[i.key];
          return [c?.done ? 'Confirmé' : 'À confirmer', c?.note ?? ''];
        }),
      ];
    });
  void ctx;
  return { name: 'Zones candidates', headers, rows };
}

// ------------------------------------------------------------------ synthèse (feuille « Synthèse » du classeur)
export function buildSummarySheet(s: Summary, mission: ReferenceMission | null): Dataset {
  const r = (label: string, n: number, d: number): Cell[] => [label, n, d, d > 0 ? Math.round((n / d) * 100) : ''];
  const pay = willingToPay(s.price_distribution);
  const rows: Cell[][] = [
    ['Mission', mission?.name ?? '', '', ''],
    ['Période des réponses', s.first_date && s.last_date ? `${s.first_date} au ${s.last_date}` : 'Aucune réponse', '', ''],
    ['Base de calcul', 'Réponses soumises (brouillons et exclues non comptés)', '', ''],
    ['', '', '', ''],
    ['Acheteurs interrogés (valides)', s.buyers_total, '', ''],
    ['Commerçantes interrogées (valides)', s.vendors_total, '', ''],
    ['Sessions d’observation', s.observations_total, '', ''],
    ['Zones étudiées', s.zones_studied, '', ''],
    ['Refus comptés (anonymes)', s.refusals, '', ''],
    ['Brouillons (non comptés)', s.drafts.buyers + s.drafts.vendors + s.drafts.observations, '', ''],
    ['Exclues (non comptées)', s.excluded.buyers + s.excluded.vendors + s.excluded.observations, '', ''],
    ['', '', '', ''],
    r('Acheteurs : difficultés souvent ou presque à chaque visite', s.buyers_often_difficulty.n, s.buyers_often_difficulty.d),
    r('Acheteurs : intérêt déclaré (certainement ou probablement)', s.buyers_interested.n, s.buyers_interested.d),
    r('Acheteurs : volonté déclarée de payer (un prix choisi)', pay.n, pay.d),
    r('Acheteurs : deux trajets ou plus', s.buyers_two_trips_or_more.n, s.buyers_two_trips_or_more.d),
    r('Commerçantes : clients en difficulté souvent ou très souvent', s.vendors_clients_often_difficulty.n, s.vendors_clients_often_difficulty.d),
    r('Commerçantes : pensent que les clients utiliseraient', s.vendors_clients_would_use.n, s.vendors_clients_would_use.d),
    ['', '', '', ''],
    ...distribution(s.price_distribution, (k) => optionLabel('acheteur', 'q10_prix', k), s.buyers_total).map((x): Cell[] => [`Prix : ${x.label}`, x.count, s.buyers_total, s.buyers_total > 0 ? Math.round(x.share * 100) : '']),
    ...distribution(s.difficulties, (k) => optionLabel('acheteur', 'q3_difficultes', k), s.buyers_total).map((x): Cell[] => [`Difficulté : ${x.label}`, x.count, s.buyers_total, s.buyers_total > 0 ? Math.round(x.share * 100) : '']),
    ...distribution(s.concerns, (k) => optionLabel('acheteur', 'q12_inquietude', k), s.buyers_total).map((x): Cell[] => [`Inquiétude : ${x.label}`, x.count, s.buyers_total, s.buyers_total > 0 ? Math.round(x.share * 100) : '']),
    ['', '', '', ''],
    ['AVERTISSEMENT', 'Enquête exploratoire : résultats non nécessairement représentatifs, aucune garantie de rentabilité. Projet à l’étude, ni autorisé ni lancé.', '', ''],
  ];
  return { name: 'Synthèse', headers: ['Indicateur', 'Nombre (n)', 'Base (d)', 'Pourcentage'], rows };
}

// ------------------------------------------------------------------ CSV (compatible Excel en français et Google Sheets)
/** Une cellule qui commence par = + - @ serait exécutée comme formule par Excel : on la neutralise avec une apostrophe. */
export function neutralizeFormula(s: string): string {
  return /^[=+\-@\t\r]/.test(s) ? `'${s}` : s;
}

function csvCell(v: Cell): string {
  if (v === null || v === undefined) return '';
  let s: string;
  if (typeof v === 'number') s = Number.isInteger(v) ? String(v) : String(v).replace('.', ','); // virgule décimale (Excel français)
  else s = neutralizeFormula(v);
  return /[;"\r\n]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s;
}

/** CSV UTF-8 avec BOM, séparateur « ; », lignes CRLF : s'ouvre directement dans Excel (France) et s'importe dans Google Sheets. */
export function toCsv(ds: Dataset): string {
  const lines = [ds.headers.map(csvCell).join(';'), ...ds.rows.map((r) => r.map(csvCell).join(';'))];
  return '﻿' + lines.join('\r\n') + '\r\n';
}

export function safeFileName(s: string): string {
  return s.normalize('NFD').replace(/[̀-ͯ]/g, '').replace(/[^A-Za-z0-9_-]+/g, '_').replace(/^_+|_+$/g, '') || 'export';
}

// ------------------------------------------------------------------ XLSX
export async function toXlsxBlob(sheets: Dataset[]): Promise<Blob> {
  const { default: writeExcelFile } = await import('write-excel-file/universal');
  const widths = (ds: Dataset) =>
    ds.headers.map((h, i) => {
      const longest = Math.max(h.length, ...ds.rows.slice(0, 200).map((r) => String(r[i] ?? '').length));
      return { width: Math.min(60, Math.max(10, Math.round(longest * 0.9) + 2)) };
    });
  const spec = sheets.map((ds) => ({
    sheet: ds.name.slice(0, 31),
    stickyRowsCount: 1,
    columns: widths(ds),
    data: [
      ds.headers.map((h) => ({ value: h, fontWeight: 'bold' as const, wrap: true })),
      ...ds.rows.map((r) =>
        r.map((v) =>
          typeof v === 'number'
            ? { value: v, type: Number }
            : { value: v === null || v === undefined || v === '' ? null : neutralizeFormula(String(v)), type: String, wrap: true },
        ),
      ),
    ],
  }));
  return (await writeExcelFile(spec as never)).toBlob();
}

// ------------------------------------------------------------------ téléchargement (navigateur)
export function downloadBlob(blob: Blob, fileName: string) {
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = fileName;
  document.body.appendChild(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 10000);
}
export const csvBlob = (ds: Dataset) => new Blob([toCsv(ds)], { type: 'text/csv;charset=utf-8' });
