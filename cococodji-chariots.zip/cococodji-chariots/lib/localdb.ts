import { openDB, type IDBPDatabase } from 'idb';
import type { LocalRecord } from './types';

// Stockage local du téléphone (IndexedDB) : file d'attente hors ligne + brouillons.
// Ce n'est PAS la base partagée : tout ce qui est soumis est envoyé vers Supabase (voir sync.ts).

const DB_NAME = 'cococodji-chariots';
let dbPromise: Promise<IDBPDatabase> | null = null;
const listeners = new Set<() => void>();

function db() {
  if (!dbPromise) {
    dbPromise = openDB(DB_NAME, 1, {
      upgrade(d) {
        const s = d.createObjectStore('records', { keyPath: 'id' });
        s.createIndex('state', 'state');
        d.createObjectStore('meta');
      },
    });
  }
  return dbPromise;
}

/** Pour les tests : repart d'une base locale vide. */
export async function resetLocalDb() {
  if (dbPromise) {
    (await dbPromise).close();
    dbPromise = null;
  }
  await new Promise<void>((resolve, reject) => {
    const r = indexedDB.deleteDatabase(DB_NAME);
    r.onsuccess = () => resolve();
    r.onerror = () => reject(r.error);
    r.onblocked = () => resolve();
  });
}

export function onLocalChange(cb: () => void) {
  listeners.add(cb);
  return () => {
    listeners.delete(cb);
  };
}
const notify = () => listeners.forEach((cb) => cb());

export async function putRecord(rec: LocalRecord) {
  await (await db()).put('records', rec);
  notify();
}

export async function getRecord(id: string): Promise<LocalRecord | undefined> {
  return (await db()).get('records', id);
}

export async function deleteRecord(id: string) {
  await (await db()).delete('records', id);
  notify();
}

/** Les fiches du téléphone appartenant à cet utilisateur (un autre compte sur le même téléphone ne les voit pas). */
export async function listRecords(userId: string): Promise<LocalRecord[]> {
  const all = (await (await db()).getAll('records')) as LocalRecord[];
  return all.filter((r) => r.userId === userId).sort((a, b) => a.createdAt.localeCompare(b.createdAt));
}

export async function getMeta<T>(key: string): Promise<T | undefined> {
  return (await db()).get('meta', key) as Promise<T | undefined>;
}
export async function setMeta(key: string, value: unknown) {
  await (await db()).put('meta', value, key);
}

/** Compteur persistant (sert à alterner l'ordre des prix d'un répondant à l'autre). */
export async function nextCounter(name: string): Promise<number> {
  const n = ((await getMeta<number>(`counter:${name}`)) ?? 0) + 1;
  await setMeta(`counter:${name}`, n);
  return n;
}

export interface Counts {
  drafts: number;
  pending: number;
  error: number;
  synced: number;
}
export function countRecords(records: LocalRecord[]): Counts {
  const c: Counts = { drafts: 0, pending: 0, error: 0, synced: 0 };
  for (const r of records) {
    if (r.state === 'LOCAL') c.drafts++;
    else if (r.state === 'PENDING') c.pending++;
    else if (r.state === 'ERROR') c.error++;
    else if (r.state === 'SYNCED') c.synced++;
  }
  return c;
}
