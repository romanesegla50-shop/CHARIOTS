'use client';
import { useSyncExternalStore } from 'react';
import type { FormType } from './types';
import { isFormType } from './forms';

// Navigation interne par « # » : l'application est UNE seule page.
// Avantage terrain : sans réseau, le téléphone n'a besoin que de cette page en cache.

export type AdminPage = 'mission' | 'equipe' | 'reponses' | 'resultats' | 'export' | 'journal';
const ADMIN_PAGES: AdminPage[] = ['mission', 'equipe', 'reponses', 'resultats', 'export', 'journal'];

export type Route =
  | { name: 'home' }
  | { name: 'nouvelle' }
  | { name: 'envois' }
  | { name: 'plus' }
  | { name: 'zones' }
  | { name: 'admin'; page: AdminPage }
  | { name: 'formulaire'; type: FormType; id?: string };

export interface RouteState {
  route: Route;
  /** change à chaque navigation voulue par l'utilisateur (sert à repartir d'un formulaire neuf) */
  nonce: number;
}

export function parseHash(hash: string): Route {
  const parts = hash.replace(/^#\/?/, '').split('/').filter(Boolean);
  if (parts[0] === 'nouvelle') return { name: 'nouvelle' };
  if (parts[0] === 'envois') return { name: 'envois' };
  if (parts[0] === 'plus') return { name: 'plus' };
  if (parts[0] === 'zones') return { name: 'zones' };
  if (parts[0] === 'admin' && ADMIN_PAGES.includes(parts[1] as AdminPage)) return { name: 'admin', page: parts[1] as AdminPage };
  if (parts[0] === 'formulaire' && parts[1] && isFormType(parts[1])) {
    return { name: 'formulaire', type: parts[1], id: parts[2] };
  }
  return { name: 'home' };
}

let state: RouteState = { route: { name: 'home' }, nonce: 0 };
let started = false;
const listeners = new Set<() => void>();

function start() {
  if (started || typeof window === 'undefined') return;
  started = true;
  state = { route: parseHash(window.location.hash), nonce: 0 };
  window.addEventListener('hashchange', () => {
    state = { route: parseHash(window.location.hash), nonce: state.nonce + 1 };
    listeners.forEach((l) => l());
  });
}

function subscribe(cb: () => void) {
  start();
  listeners.add(cb);
  return () => {
    listeners.delete(cb);
  };
}
const getSnapshot = () => {
  start();
  return state;
};
const getServerSnapshot = (): RouteState => ({ route: { name: 'home' }, nonce: 0 });

export function useRoute(): RouteState {
  return useSyncExternalStore(subscribe, getSnapshot, getServerSnapshot);
}

export function navigate(path: string) {
  window.location.hash = path;
}

/** Ajoute l'identifiant du brouillon à l'adresse (sans recharger ni remonter l'écran) pour pouvoir le reprendre. */
export function rememberDraftInUrl(type: FormType, id: string) {
  window.history.replaceState(null, '', `#/formulaire/${type}/${id}`);
}
