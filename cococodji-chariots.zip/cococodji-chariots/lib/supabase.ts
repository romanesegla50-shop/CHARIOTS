import { createClient, type SupabaseClient } from '@supabase/supabase-js';
import type { Transport, TransportResult } from './sync';

let client: SupabaseClient | null = null;

// Les deux variables doivent être écrites littéralement pour être intégrées par Next.js.
const URL = process.env.NEXT_PUBLIC_SUPABASE_URL;
const ANON = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY;

export function isConfigured(): boolean {
  return Boolean(URL && ANON);
}

export function getClient(): SupabaseClient {
  if (!client) {
    if (!URL || !ANON) throw new Error('Supabase non configuré');
    client = createClient(URL, ANON, {
      auth: { persistSession: true, autoRefreshToken: true, detectSessionInUrl: false },
    });
  }
  return client;
}

interface PgError {
  code?: string;
  message?: string;
}

/** Range l'erreur reçue : problème de réseau / session expirée (on réessaiera) ou refus du serveur (à corriger). */
export function classifyError(error: PgError, status: number): TransportResult & { ok: false } {
  const message = error.message ?? 'Erreur inconnue';
  const code = error.code;
  const looksNetwork = status === 0 || status >= 500 || /failed to fetch|network|load failed|fetch/i.test(message);
  if (looksNetwork) return { ok: false, kind: 'network', message };
  if (status === 401 || code === 'PGRST301' || code === 'PGRST303' || /jwt/i.test(message)) {
    return { ok: false, kind: 'auth', message: 'Session expirée : reconnectez-vous.' };
  }
  return { ok: false, kind: 'rejected', code, message };
}

export function supabaseTransport(c: SupabaseClient): Transport {
  return {
    async insertIgnoreDuplicates(table, row, signal) {
      try {
        let q = c.from(table).upsert(row, { onConflict: 'id', ignoreDuplicates: true });
        if (signal) q = q.abortSignal(signal);
        const { error, status } = await q;
        if (!error) return { ok: true };
        return classifyError(error, status);
      } catch (e) {
        return { ok: false, kind: 'network', message: e instanceof Error ? e.message : String(e) };
      }
    },
  };
}
