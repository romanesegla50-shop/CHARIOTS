export type FormType = 'acheteur' | 'commercante' | 'observation' | 'evaluation';
export type RecordKind = FormType | 'refus';
export type TableName =
  | 'buyer_responses'
  | 'vendor_responses'
  | 'observation_sessions'
  | 'zone_evaluations'
  | 'refusals';

/**
 * LOCAL   = brouillon, « Enregistré sur ce téléphone » (jamais envoyé)
 * PENDING = soumis, « En attente de synchronisation »
 * SYNCED  = « Synchronisé » (le serveur a confirmé la réception)
 * ERROR   = « Erreur de synchronisation » (le serveur a refusé la fiche)
 */
export type SyncState = 'LOCAL' | 'PENDING' | 'SYNCED' | 'ERROR';

export interface DraftData {
  answers: Record<string, unknown>;
  stepIndex: number;
  startedAt: string;
  ordering: 'ASC' | 'DESC';
  consent: boolean;
}

export interface LocalRecord {
  id: string;
  userId: string;
  kind: RecordKind;
  table: TableName;
  state: SyncState;
  /** Identifiant de la dernière sauvegarde faite sur ce téléphone */
  clientRev: string;
  attempts: number;
  error?: string;
  /** Ligne prête à être envoyée (présente dès que la fiche est soumise) */
  row?: Record<string, unknown>;
  /** Brouillon en cours (présent tant que la fiche n'est pas soumise) */
  draft?: DraftData;
  zoneId?: string | null;
  createdAt: string;
  updatedAt: string;
  syncedAt?: string;
}

export interface ReferenceZone {
  id: string;
  code: string;
  label: string | null;
  description: string | null;
  sector: string | null;
  is_candidate: boolean;
  approval_status: 'NON_VALIDE' | 'VALIDE';
}

export interface ReferenceMission {
  id: string;
  name: string;
  status: 'PREPARATION' | 'EN_COURS' | 'EN_ANALYSE' | 'TERMINEE';
  start_date: string | null;
  end_date: string | null;
  instructions: string | null;
  target_buyers: number;
  target_vendors: number;
  target_observations: number;
}

export interface Reference {
  mission: ReferenceMission | null;
  zones: ReferenceZone[];
  fetchedAt: string;
}

export interface Profile {
  id: string;
  email: string | null;
  full_name: string;
  role: 'ADMINISTRATEUR' | 'ENQUETEUR';
  active: boolean;
}

export const STATE_LABEL: Record<SyncState, string> = {
  LOCAL: 'Enregistré sur ce téléphone',
  PENDING: 'En attente de synchronisation',
  SYNCED: 'Synchronisé',
  ERROR: 'Erreur de synchronisation',
};

export const MISSION_STATUS_LABEL: Record<ReferenceMission['status'], string> = {
  PREPARATION: 'Préparation',
  EN_COURS: 'En cours',
  EN_ANALYSE: 'En analyse',
  TERMINEE: 'Terminée',
};
