import { getRecord, listRecords, putRecord } from './localdb';
import type { LocalRecord } from './types';

/**
 * Moteur de synchronisation.
 *
 * Principe anti-doublon : chaque fiche porte un identifiant (UUID) créé sur le téléphone.
 * L'envoi est un « INSERT ... ON CONFLICT DO NOTHING » sur cet identifiant :
 * si une tentative a déjà atteint le serveur (réponse perdue en route), le renvoi est
 * simplement ignoré par la base. La fiche locale ne passe à « Synchronisé » que lorsque
 * le serveur a confirmé la réception.
 */

export type TransportResult =
  | { ok: true }
  | { ok: false; kind: 'network' | 'auth' | 'rejected'; code?: string; message: string };

export interface Transport {
  insertIgnoreDuplicates(table: string, row: Record<string, unknown>, signal?: AbortSignal): Promise<TransportResult>;
}

export interface SyncOptions {
  /** délai maximum d'un envoi avant de le considérer comme perdu (le renvoi est sans risque : même identifiant) */
  timeoutMs?: number;
}
export const SEND_TIMEOUT_MS = 20000;

export interface SyncReport {
  sent: number;
  rejected: number;
  remaining: number;
  stoppedBy?: 'network' | 'auth';
}

export function explainRejection(code?: string, message?: string): string {
  switch (code) {
    case '23505':
      return 'Doublon : cette fiche existe déjà sur le serveur (même créneau d’observation, ou zone déjà évaluée par vous).';
    case '23514':
      return 'Le serveur a refusé la fiche : champ obligatoire manquant ou valeur invalide.';
    case '23503':
      return 'Zone ou mission inconnue sur le serveur. Ouvrez l’application en ligne pour recharger les zones, puis réessayez.';
    case '42501':
      return 'Droits insuffisants : votre compte n’est peut-être pas encore activé. Prévenez l’administrateur, puis appuyez sur « Réessayer ».';
    default:
      return message || 'Le serveur a refusé la fiche.';
  }
}

let running: Promise<SyncReport> | null = null;

/** Envoie toutes les fiches « en attente » de cet utilisateur. Un seul envoi à la fois. */
export function syncAll(transport: Transport, userId: string, options: SyncOptions = {}): Promise<SyncReport> {
  if (running) return running;
  running = doSync(transport, userId, options.timeoutMs ?? SEND_TIMEOUT_MS).finally(() => {
    running = null;
  });
  return running;
}

/** Un envoi ne peut jamais bloquer la file : au-delà du délai, il est abandonné et sera retenté. */
async function sendWithTimeout(transport: Transport, rec: LocalRecord, timeoutMs: number): Promise<TransportResult> {
  const ctrl = new AbortController();
  let timer: ReturnType<typeof setTimeout> | undefined;
  const timeout = new Promise<TransportResult>((resolve) => {
    timer = setTimeout(() => {
      ctrl.abort();
      resolve({ ok: false, kind: 'network', message: 'Délai dépassé : le réseau ne répond pas.' });
    }, timeoutMs);
  });
  const send = (async (): Promise<TransportResult> => {
    try {
      return await transport.insertIgnoreDuplicates(rec.table, rec.row as Record<string, unknown>, ctrl.signal);
    } catch (e) {
      return { ok: false, kind: 'network', message: e instanceof Error ? e.message : String(e) };
    }
  })();
  try {
    return await Promise.race([send, timeout]);
  } finally {
    if (timer) clearTimeout(timer);
  }
}

async function doSync(transport: Transport, userId: string, timeoutMs: number): Promise<SyncReport> {
  const report: SyncReport = { sent: 0, rejected: 0, remaining: 0 };
  const pending = (await listRecords(userId)).filter((r) => r.state === 'PENDING' && r.row);

  for (const rec of pending) {
    const res = await sendWithTimeout(transport, rec, timeoutMs);

    // la fiche a pu être supprimée / modifiée pendant l'envoi : on relit avant d'écrire
    const fresh = (await getRecord(rec.id)) ?? rec;

    if (res.ok) {
      await putRecord({ ...fresh, state: 'SYNCED', syncedAt: new Date().toISOString(), error: undefined });
      report.sent++;
      continue;
    }

    if (res.kind === 'network' || res.kind === 'auth') {
      // pas de réseau (ou session expirée) : la fiche reste « en attente », on réessaiera plus tard
      await putRecord({ ...fresh, attempts: fresh.attempts + 1, error: res.message });
      report.stoppedBy = res.kind;
      break;
    }

    await putRecord({
      ...fresh,
      state: 'ERROR',
      attempts: fresh.attempts + 1,
      error: explainRejection(res.code, res.message),
    });
    report.rejected++;
  }

  report.remaining = (await listRecords(userId)).filter((r) => r.state === 'PENDING').length;
  return report;
}

/** Met une fiche soumise dans la file d'envoi (c'est ici qu'elle quitte le statut « brouillon »). */
export async function queueForSync(rec: LocalRecord) {
  await putRecord({ ...rec, state: 'PENDING', draft: undefined, attempts: 0, error: undefined });
}

/** Après une erreur : remet la fiche en attente pour un nouvel essai. */
export async function retryRecord(id: string) {
  const rec = await getRecord(id);
  if (rec && rec.state === 'ERROR' && rec.row) {
    await putRecord({ ...rec, state: 'PENDING', error: undefined });
  }
}
