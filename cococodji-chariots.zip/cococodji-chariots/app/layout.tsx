import type { Metadata, Viewport } from 'next';
import './globals.css';

export const metadata: Metadata = {
  title: 'Cococodji Chariots — Enquête terrain',
  description: 'Collecte de données sur le terrain, au marché de Cococodji (projet à l’étude, service non autorisé).',
  manifest: '/manifest.webmanifest',
  applicationName: 'Cococodji Chariots',
  appleWebApp: { capable: true, title: 'Chariots', statusBarStyle: 'black-translucent' },
  icons: { icon: '/icon-192.png', apple: '/apple-touch-icon.png' },
  robots: { index: false, follow: false },
};

export const viewport: Viewport = {
  width: 'device-width',
  initialScale: 1,
  themeColor: '#0b2545',
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="fr">
      <body>{children}</body>
    </html>
  );
}
