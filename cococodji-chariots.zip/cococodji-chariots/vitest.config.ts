import { defineConfig } from 'vitest/config';
import path from 'node:path';

export default defineConfig({
  test: { include: ['tests/**/*.spec.ts'], environment: 'node', testTimeout: 60000 },
  resolve: { alias: { '@': path.resolve(import.meta.dirname) } },
});
