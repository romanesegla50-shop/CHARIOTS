'use client';
import React from 'react';
import { useApp } from '../AppProvider';
import { ProgressBar, StatePill, ago, fmtDate, fmtDateTime } from '../ui';
import { navigate } from '@/lib/hashrouter';
import { KIND_LABEL, zoneCode } from '@/lib/labels';
import { MISSION_STATUS_LABEL } from '@/lib/types';

export default function Home() {
  const { reference, stats, counts, records, profile, user, online, canInstall, install } = useApp();
  const mission = reference?.mission ?? null;
  const ov = stats?.overview ?? null;
  const zones = reference?.zones ?? [];

  const totalServer = ov ? ov.buyers + ov.vendors + ov.observations : 0;
  const hasLocal = records.length > 0;
  const notStarted = totalServer === 0 && !hasLocal;
  const recent = [...records].sort((a, b) => b.updatedAt.localeCompare(a.updatedAt)).slice(0, 5);

  if (!mission) {
    return (
      <div className="stack">
        <h1>Cococodji Chariots — Enquête terrain</h1>
        <div className="notice warn">
          Aucune mission n’est encore disponible. L’administrateur doit créer la mission et ses zones. Si c’est déjà fait,
          {online ? ' tirez pour actualiser en rouvrant l’application.' : ' connectez-vous au réseau pour la charger.'}
        </div>
      </div>
    );
  }

  return (
    <div>
      <h1>Cococodji Chariots — Enquête terrain</h1>
      <div className="notice">
        <b>Projet à l’étude.</b> Le service de chariots n’est ni autorisé ni lancé. Aucune autorisation n’a été accordée.
      </div>

      <div className="card">
        <div className="row spread wrap">
          <h2 style={{ margin: 0 }}>{mission.name}</h2>
          <span className="pill LOCAL">{MISSION_STATUS_LABEL[mission.status]}</span>
        </div>
        <p className="muted" style={{ marginTop: 6 }}>
          {mission.start_date ? `Du ${fmtDate(mission.start_date)}` : 'Date de début non fixée'}
          {mission.end_date ? ` au ${fmtDate(mission.end_date)}` : ''}
        </p>
        {mission.instructions && (
          <details>
            <summary style={{ fontWeight: 700, color: 'var(--navy)', minHeight: 44, display: 'flex', alignItems: 'center' }}>
              Consignes communes
            </summary>
            <p style={{ whiteSpace: 'pre-wrap' }}>{mission.instructions}</p>
          </details>
        )}
      </div>

      {(mission.status === 'TERMINEE' || mission.status === 'EN_ANALYSE') && (
        <div className="notice warn">La mission est « {MISSION_STATUS_LABEL[mission.status]} » : la collecte devrait être terminée.</div>
      )}
      {profile && !profile.active && <div className="notice err">Votre compte n’est pas activé.</div>}

      <button className="btn" style={{ marginBottom: 14 }} onClick={() => navigate('#/nouvelle')}>
        ＋ Nouvelle réponse
      </button>

      {notStarted && (
        <div className="card center">
          <h3>L’enquête n’a pas encore commencé</h3>
          <p className="muted">Aucune réponse enregistrée pour l’instant. Appuyez sur « Nouvelle réponse » pour saisir la première.</p>
        </div>
      )}

      <h2>Sur ce téléphone</h2>
      <div className="grid2" style={{ marginBottom: 14 }}>
        <div className="stat"><b>{counts.drafts}</b><span>Brouillons enregistrés</span></div>
        <div className={`stat${counts.pending ? ' warn' : ''}`}><b>{counts.pending}</b><span>En attente de synchronisation</span></div>
        <div className="stat"><b>{counts.synced}</b><span>Synchronisées</span></div>
        <div className={`stat${counts.error ? ' err' : ''}`}><b>{counts.error}</b><span>Erreurs de synchronisation</span></div>
      </div>
      {(counts.pending > 0 || counts.error > 0) && (
        <button className="btn secondary" style={{ marginBottom: 14 }} onClick={() => navigate('#/envois')}>
          Voir mes envois
        </button>
      )}

      <h2>Toute l’équipe</h2>
      {ov ? (
        <div className="card stack">
          <div>
            <div className="row spread"><b>Acheteurs interrogés</b><span>{ov.buyers} sur {mission.target_buyers}</span></div>
            <ProgressBar value={ov.buyers} max={mission.target_buyers} />
          </div>
          <div>
            <div className="row spread"><b>Commerçantes interrogées</b><span>{ov.vendors} sur {mission.target_vendors}</span></div>
            <ProgressBar value={ov.vendors} max={mission.target_vendors} />
          </div>
          <div>
            <div className="row spread">
              <b>Sessions d’observation</b>
              <span>{ov.observations}{mission.target_observations ? ` sur ${mission.target_observations}` : ''}</span>
            </div>
            {mission.target_observations > 0 && <ProgressBar value={ov.observations} max={mission.target_observations} />}
          </div>
          <div className="grid2">
            <div className="stat"><b>{ov.zones_observed}</b><span>Zones observées</span></div>
            <div className="stat"><b>{ov.refusals}</b><span>Refus comptés</span></div>
          </div>
          <p className="muted small">
            Objectifs exploratoires, pas des quotas obligatoires. Chiffres du serveur
            {stats?.fetchedAt ? `, mis à jour ${ago(stats.fetchedAt)}` : ''}
            {!online ? ' (hors ligne : peut ne pas être à jour)' : ''}. Les fiches de ce téléphone pas encore synchronisées n’y figurent pas.
          </p>
        </div>
      ) : (
        <div className="notice">Totaux d’équipe indisponibles pour l’instant{!online ? ' (hors ligne)' : ''}.</div>
      )}

      {stats && stats.team.length > 0 && (
        <>
          <h2>Progression des enquêteurs</h2>
          {stats.team.map((t) => (
            <div className="list-item" key={t.surveyor_id}>
              <div className="row spread">
                <span className="t">{t.surveyor_name}{t.surveyor_id === user?.id ? ' (vous)' : ''}</span>
              </div>
              <div className="muted">
                {t.buyers} acheteur{t.buyers > 1 ? 's' : ''} · {t.vendors} commerçante{t.vendors > 1 ? 's' : ''} · {t.observations} observation{t.observations > 1 ? 's' : ''}
              </div>
            </div>
          ))}
        </>
      )}

      {recent.length > 0 && (
        <>
          <h2>Dernières fiches de ce téléphone</h2>
          {recent.map((r) => (
            <div className="list-item" key={r.id}>
              <div className="row spread wrap">
                <span className="t">{KIND_LABEL[r.kind]} · zone {zoneCode(zones, r.zoneId)}</span>
                <StatePill state={r.state} />
              </div>
              <div className="muted">{fmtDateTime(r.updatedAt)}</div>
            </div>
          ))}
        </>
      )}

      {canInstall && (
        <button className="btn secondary" style={{ marginTop: 14 }} onClick={() => void install()}>
          Installer l’application sur l’écran d’accueil
        </button>
      )}
      <p className="muted small center" style={{ marginTop: 18 }}>
        Conseil iPhone : bouton Partager, puis « Sur l’écran d’accueil ».
      </p>
    </div>
  );
}
