'use client';
import React from 'react';
import { useApp } from '../AppProvider';
import { navigate } from '@/lib/hashrouter';
import { KIND_LABEL, zoneCode } from '@/lib/labels';
import { fmtDateTime } from '../ui';

export default function NewEntry() {
  const { reference, records } = useApp();
  const drafts = records.filter((r) => r.state === 'LOCAL' && r.draft);
  const zones = reference?.zones ?? [];

  return (
    <div className="stack">
      <h1>Nouvelle réponse</h1>
      {!reference?.mission && <div className="notice warn">Aucune mission disponible : impossible de saisir pour l’instant.</div>}
      <button className="btn" onClick={() => navigate('#/formulaire/acheteur')}>
        Questionnaire acheteur ou acheteuse
      </button>
      <button className="btn" onClick={() => navigate('#/formulaire/commercante')}>
        Questionnaire vendeuse ou commerçante
      </button>
      <button className="btn" onClick={() => navigate('#/formulaire/observation')}>
        Observation des flux (15 minutes)
      </button>
      <button className="btn secondary" onClick={() => navigate('#/formulaire/evaluation')}>
        Évaluation d’un emplacement candidat
      </button>

      {drafts.length > 0 && (
        <>
          <h2 style={{ marginTop: 18 }}>Brouillons à reprendre</h2>
          {drafts.map((d) => (
            <button
              key={d.id}
              className="btn secondary"
              style={{ justifyContent: 'space-between', textAlign: 'left' }}
              onClick={() => navigate(`#/formulaire/${d.kind}/${d.id}`)}
            >
              <span>
                {KIND_LABEL[d.kind]} · zone {zoneCode(zones, d.zoneId)}
                <small style={{ display: 'block', fontWeight: 400 }}>{fmtDateTime(d.updatedAt)}</small>
              </span>
              <span>Reprendre ›</span>
            </button>
          ))}
        </>
      )}
    </div>
  );
}
