'use client';
import React, { useEffect, useState } from 'react';
import { useApp } from '../AppProvider';
import { BackToMenu, ErrorBox, Flash, useLoad, type FlashMsg } from '../admin/shared';
import { ConfirmButton, fmtDate } from '../ui';
import { getClient } from '@/lib/supabase';
import {
  MANAGER_CHECK_ITEMS, createZone, deleteZone, listZones, updateZone, validateZoneCode, type FullZone, type ManagerChecks,
} from '@/lib/admin';
import type { ReferenceZone } from '@/lib/types';

function ZoneBadges({ z }: { z: Pick<ReferenceZone, 'is_candidate' | 'approval_status'> & { approved_at?: string | null } }) {
  return (
    <span className="row wrap">
      {z.is_candidate && <span className="pill blue">Emplacement candidat</span>}
      {z.is_candidate &&
        (z.approval_status === 'VALIDE' ? (
          <span className="pill green">Validé par l’administrateur{z.approved_at ? ` le ${fmtDate(z.approved_at)}` : ''}</span>
        ) : (
          <span className="pill gray">Non validé</span>
        ))}
    </span>
  );
}

function ZoneEditor({ z, onChanged, setMsg }: { z: FullZone; onChanged: () => Promise<void>; setMsg: (m: FlashMsg) => void }) {
  const [f, setF] = useState({ code: z.code, label: z.label ?? '', sector: z.sector ?? '', description: z.description ?? '' });
  const [checks, setChecks] = useState<ManagerChecks>(z.manager_checks ?? {});
  const [busy, setBusy] = useState(false);
  useEffect(() => {
    setF({ code: z.code, label: z.label ?? '', sector: z.sector ?? '', description: z.description ?? '' });
    setChecks(z.manager_checks ?? {});
  }, [z]);

  const run = async (p: Promise<{ ok: boolean; error?: string }>, ok: string) => {
    setBusy(true);
    const r = await p;
    setBusy(false);
    if (!r.ok) return setMsg({ kind: 'err', text: (r as { error: string }).error });
    setMsg({ kind: 'ok', text: ok });
    await onChanged();
  };
  const allChecked = MANAGER_CHECK_ITEMS.every((i) => checks[i.key]?.done);

  return (
    <div className="stack" style={{ marginTop: 10 }}>
      <div className="field">
        <label className="lead" htmlFor={`zc-${z.id}`}>Code</label>
        <input id={`zc-${z.id}`} className="input" value={f.code} maxLength={10} onChange={(e) => setF({ ...f, code: e.target.value })} />
      </div>
      <div className="field">
        <label className="lead" htmlFor={`zl-${z.id}`}>Libellé</label>
        <input id={`zl-${z.id}`} className="input" value={f.label} maxLength={120} onChange={(e) => setF({ ...f, label: e.target.value })} />
      </div>
      <div className="field">
        <label className="lead" htmlFor={`zs-${z.id}`}>Secteur général</label>
        <input id={`zs-${z.id}`} className="input" value={f.sector} maxLength={120} onChange={(e) => setF({ ...f, sector: e.target.value })} />
      </div>
      <div className="field">
        <label className="lead" htmlFor={`zd-${z.id}`}>Description</label>
        <textarea id={`zd-${z.id}`} className="input" value={f.description} maxLength={1000} onChange={(e) => setF({ ...f, description: e.target.value })} />
      </div>
      <button
        className="btn secondary"
        disabled={busy}
        onClick={() => {
          const problem = validateZoneCode(f.code);
          if (problem) return setMsg({ kind: 'err', text: problem });
          void run(updateZone(getClient(), z.id, { code: f.code.trim(), label: f.label.trim() || null, sector: f.sector.trim() || null, description: f.description.trim() || null }), `Zone ${f.code.trim().toUpperCase()} enregistrée.`);
        }}
      >
        Enregistrer la zone
      </button>

      <label className="choice">
        <input
          type="checkbox"
          checked={z.is_candidate}
          disabled={busy || (z.is_candidate && z.approval_status === 'VALIDE')}
          onChange={(e) => void run(updateZone(getClient(), z.id, { is_candidate: e.target.checked }), e.target.checked ? 'Zone marquée comme candidate.' : 'Zone retirée des candidates.')}
        />
        Emplacement candidat (3 au maximum)
      </label>
      {z.is_candidate && z.approval_status === 'VALIDE' && <p className="help">Retirez d’abord la validation pour pouvoir retirer le statut de candidate.</p>}

      {z.is_candidate && (
        <div className="card">
          <h3>Points à confirmer auprès du gestionnaire</h3>
          {MANAGER_CHECK_ITEMS.map((i) => (
            <div key={i.key} style={{ marginBottom: 8 }}>
              <label className="checkrow">
                <input
                  type="checkbox"
                  checked={checks[i.key]?.done ?? false}
                  onChange={(e) => setChecks({ ...checks, [i.key]: { done: e.target.checked, note: checks[i.key]?.note ?? '' } })}
                />
                {i.label}
              </label>
              <input
                className="input"
                style={{ minHeight: 44, fontSize: 16 }}
                placeholder="Note (facultatif)"
                aria-label={`Note : ${i.label}`}
                value={checks[i.key]?.note ?? ''}
                maxLength={300}
                onChange={(e) => setChecks({ ...checks, [i.key]: { done: checks[i.key]?.done ?? false, note: e.target.value } })}
              />
            </div>
          ))}
          <button className="btn secondary" disabled={busy} onClick={() => void run(updateZone(getClient(), z.id, { manager_checks: checks }), 'Points à confirmer enregistrés.')}>
            Enregistrer ces points
          </button>
        </div>
      )}

      {z.is_candidate && (
        <div className="card">
          <h3>Validation</h3>
          <p className="muted small">
            Une zone n’est « validée » que par une décision explicite de l’administrateur. Cette validation est interne : elle ne remplace ni l’accord du gestionnaire du marché ni l’autorisation de l’ANaGeM.
          </p>
          {z.approval_status === 'VALIDE' ? (
            <ConfirmButton label="Retirer la validation" confirmLabel="Oui, retirer la validation" className="btn secondary"
              onConfirm={() => void run(updateZone(getClient(), z.id, { approval_status: 'NON_VALIDE' }), 'Validation retirée.')} />
          ) : (
            <ConfirmButton
              label="Valider cet emplacement"
              confirmLabel={allChecked ? 'Oui, valider' : 'Des points ne sont pas confirmés : valider quand même'}
              className="btn"
              onConfirm={() => void run(updateZone(getClient(), z.id, { approval_status: 'VALIDE' }), `Zone ${z.code} validée par l’administrateur.`)}
            />
          )}
        </div>
      )}

      <ConfirmButton label="Supprimer cette zone" confirmLabel="Oui, supprimer la zone" className="btn danger"
        onConfirm={() => void run(deleteZone(getClient(), z.id), `Zone ${z.code} supprimée.`)} />
      <p className="muted small">Une zone qui a déjà des réponses ne peut pas être supprimée.</p>
    </div>
  );
}

export default function Zones() {
  const { reference, profile, online, refreshAll } = useApp();
  const admin = profile?.role === 'ADMINISTRATEUR';
  const mission = reference?.mission ?? null;
  const full = useLoad(() => listZones(getClient(), mission!.id), [mission?.id], Boolean(admin && online && mission));
  const [msg, setMsg] = useState<FlashMsg>(null);
  const [adding, setAdding] = useState({ code: '', label: '', sector: '', description: '' });
  const [open, setOpen] = useState<string | null>(null);

  const zones: (ReferenceZone & Partial<FullZone>)[] = admin && full.data ? full.data : reference?.zones ?? [];
  const candidates = zones.filter((z) => z.is_candidate).length;

  const changed = async () => {
    await full.reload();
    await refreshAll();
  };

  const add = async () => {
    if (!mission) return;
    const r = await createZone(getClient(), mission.id, { code: adding.code, label: adding.label, sector: adding.sector, description: adding.description });
    if (!r.ok) return setMsg({ kind: 'err', text: r.error });
    setMsg({ kind: 'ok', text: `Zone ${adding.code.trim().toUpperCase()} ajoutée.` });
    setAdding({ code: '', label: '', sector: '', description: '' });
    await changed();
  };

  return (
    <div>
      <BackToMenu />
      <h1>Zones</h1>
      {!mission && <div className="notice warn">Aucune mission disponible pour l’instant.</div>}
      <div className="notice">
        Les emplacements candidats servent à une comparaison interne. Un emplacement n’est jamais « approuvé » sans validation explicite de l’administrateur.
      </div>
      <Flash msg={msg} />
      {full.error && <ErrorBox error={full.error} onRetry={full.reload} />}

      {admin && mission && (
        <div className="card">
          <h3>Ajouter une zone</h3>
          <div className="filters">
            <div className="field">
              <label htmlFor="nz-code">Code (ex. Z01)</label>
              <input id="nz-code" className="input" value={adding.code} maxLength={10} onChange={(e) => setAdding({ ...adding, code: e.target.value })} />
            </div>
            <div className="field">
              <label htmlFor="nz-label">Libellé</label>
              <input id="nz-label" className="input" value={adding.label} maxLength={120} onChange={(e) => setAdding({ ...adding, label: e.target.value })} />
            </div>
          </div>
          <button className="btn" disabled={!online} onClick={() => void add()}>Ajouter la zone</button>
        </div>
      )}

      {mission && zones.length === 0 && (
        <div className="card center">
          <p className="muted">{admin ? 'Aucune zone : ajoutez Z01, Z02… ci-dessus.' : 'Aucune zone définie pour l’instant.'}</p>
        </div>
      )}
      {admin && candidates > 0 && <p className="muted">{candidates} zone{candidates > 1 ? 's' : ''} candidate{candidates > 1 ? 's' : ''} sur 3 au maximum.</p>}

      {zones.map((z) => (
        <div className="list-item" key={z.id}>
          <div className="row spread wrap">
            <span className="t">{z.code}{z.label ? ` — ${z.label}` : ''}</span>
          </div>
          <ZoneBadges z={z} />
          {z.description && <p className="muted" style={{ marginTop: 6 }}>{z.description}</p>}
          {admin && full.data && (
            <>
              <button className="btn secondary small" style={{ marginTop: 8 }} onClick={() => setOpen(open === z.id ? null : z.id)}>
                {open === z.id ? 'Fermer' : 'Gérer cette zone'}
              </button>
              {open === z.id && <ZoneEditor z={z as FullZone} onChanged={changed} setMsg={setMsg} />}
            </>
          )}
        </div>
      ))}
    </div>
  );
}
