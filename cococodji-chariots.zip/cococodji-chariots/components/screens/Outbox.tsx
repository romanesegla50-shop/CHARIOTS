'use client';
import React, { useState } from 'react';
import { useApp } from '../AppProvider';
import { ConfirmButton, StatePill, fmtDateTime } from '../ui';
import { FORMS, labelFor, visibleQuestions, type Answers } from '@/lib/forms';
import { deleteRecord } from '@/lib/localdb';
import { navigate } from '@/lib/hashrouter';
import { KIND_LABEL, zoneCode } from '@/lib/labels';
import type { LocalRecord } from '@/lib/types';

function Summary({ rec }: { rec: LocalRecord }) {
  const { reference } = useApp();
  const zones = reference?.zones ?? [];
  if (rec.kind === 'refus') {
    return <p className="muted">Compteur de refus anonyme. Aucune donnée sur la personne.</p>;
  }
  const def = FORMS[rec.kind];
  const data = (rec.row ?? rec.draft?.answers ?? {}) as Answers;
  return (
    <dl className="recap">
      {def.steps.flatMap((s) => visibleQuestions(s, data)).map((q) => (
        <React.Fragment key={q.key}>
          <dt>{q.label}</dt>
          <dd>{labelFor(q, data[q.key], zones)}</dd>
        </React.Fragment>
      ))}
    </dl>
  );
}

export default function Outbox() {
  const { records, counts, syncNow, retry, syncing, online, reference } = useApp();
  const zones = reference?.zones ?? [];
  const [open, setOpen] = useState<string | null>(null);
  const sorted = [...records].sort((a, b) => b.updatedAt.localeCompare(a.updatedAt));
  const syncedCount = counts.synced;

  const clearSynced = async () => {
    for (const r of records.filter((x) => x.state === 'SYNCED')) await deleteRecord(r.id);
  };

  return (
    <div>
      <h1>Mes envois</h1>
      <div className="grid2" style={{ marginBottom: 14 }}>
        <div className="stat"><b>{counts.drafts}</b><span>Brouillons</span></div>
        <div className={`stat${counts.pending ? ' warn' : ''}`}><b>{counts.pending}</b><span>En attente</span></div>
        <div className="stat"><b>{counts.synced}</b><span>Synchronisées</span></div>
        <div className={`stat${counts.error ? ' err' : ''}`}><b>{counts.error}</b><span>Erreurs</span></div>
      </div>
      <button className="btn" disabled={syncing || !online || counts.pending === 0} onClick={() => void syncNow()}>
        {syncing ? 'Envoi en cours…' : !online ? 'Hors ligne : envoi dès le retour du réseau' : 'Synchroniser maintenant'}
      </button>

      {sorted.length === 0 && (
        <div className="card center" style={{ marginTop: 14 }}>
          <p className="muted">Aucune fiche sur ce téléphone pour l’instant.</p>
        </div>
      )}

      <div style={{ marginTop: 14 }}>
        {sorted.map((r) => (
          <div className="list-item" key={r.id}>
            <div className="row spread wrap">
              <span className="t">{KIND_LABEL[r.kind]} · zone {zoneCode(zones, r.zoneId)}</span>
              <StatePill state={r.state} />
            </div>
            <div className="muted">{fmtDateTime(r.updatedAt)}{r.attempts > 0 && r.state === 'PENDING' ? ` · ${r.attempts} tentative${r.attempts > 1 ? 's' : ''}` : ''}</div>
            {r.state === 'ERROR' && r.error && <div className="errline">{r.error}</div>}
            <div className="row wrap" style={{ marginTop: 10 }}>
              {r.state === 'ERROR' && (
                <button className="btn small" onClick={() => void retry(r.id)}>Réessayer</button>
              )}
              {r.state === 'LOCAL' && r.draft && (
                <button className="btn small" onClick={() => navigate(`#/formulaire/${r.kind}/${r.id}`)}>Reprendre</button>
              )}
              {r.kind !== 'refus' && (
                <button className="btn secondary small" onClick={() => setOpen(open === r.id ? null : r.id)}>
                  {open === r.id ? 'Masquer' : 'Voir'}
                </button>
              )}
              {r.state === 'LOCAL' && (
                <ConfirmButton label="Supprimer le brouillon" confirmLabel="Oui, supprimer" onConfirm={() => void deleteRecord(r.id)} />
              )}
            </div>
            {open === r.id && <Summary rec={r} />}
            {r.state === 'ERROR' && (
              <p className="muted small" style={{ marginTop: 8 }}>
                Une fiche refusée par le serveur reste sur ce téléphone. Contactez l’administrateur si l’erreur persiste.
              </p>
            )}
          </div>
        ))}
      </div>

      {syncedCount > 0 && (
        <div style={{ marginTop: 14 }}>
          <p className="muted small">
            Les fiches « Synchronisé » sont déjà dans la base commune. Vous pouvez libérer de la place sur ce téléphone.
          </p>
          <ConfirmButton
            label={`Retirer de ce téléphone les ${syncedCount} fiche${syncedCount > 1 ? 's' : ''} synchronisée${syncedCount > 1 ? 's' : ''}`}
            confirmLabel="Oui, retirer (elles restent sur le serveur)"
            onConfirm={() => void clearSynced()}
            className="btn secondary small"
          />
        </div>
      )}
    </div>
  );
}
