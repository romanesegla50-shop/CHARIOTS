'use client';
import React, { useState } from 'react';
import { useApp } from '../AppProvider';

export default function Login() {
  const { signIn, online } = useApp();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    setBusy(true);
    setError(null);
    const err = await signIn(email, password);
    if (err) setError(err);
    setBusy(false);
  };

  return (
    <div className="login">
      <div className="logo">
        <b>Cococodji Chariots</b>
        Enquête terrain
      </div>
      <form className="card stack" onSubmit={submit}>
        <h1>Connexion</h1>
        <p className="muted">Utilisez votre compte personnel. Ne partagez jamais votre mot de passe.</p>
        {!online && (
          <div className="notice warn">Pas de réseau : la première connexion sur ce téléphone en demande.</div>
        )}
        <div>
          <label className="help" htmlFor="email">Adresse e-mail</label>
          <input
            id="email" className="input" type="email" autoComplete="username" inputMode="email" required
            value={email} onChange={(e) => setEmail(e.target.value)}
          />
        </div>
        <div>
          <label className="help" htmlFor="password">Mot de passe</label>
          <input
            id="password" className="input" type="password" autoComplete="current-password" required
            value={password} onChange={(e) => setPassword(e.target.value)}
          />
        </div>
        {error && <div className="notice err" role="alert">{error}</div>}
        <button className="btn" type="submit" disabled={busy}>{busy ? 'Connexion…' : 'Se connecter'}</button>
      </form>
      <p className="muted center small">Projet à l’étude. Le service de chariots n’est ni autorisé ni lancé.</p>
    </div>
  );
}
