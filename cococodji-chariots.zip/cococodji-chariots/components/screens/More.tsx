'use client';
import React from 'react';
import { useApp } from '../AppProvider';
import { navigate } from '@/lib/hashrouter';

function Item({ to, title, desc }: { to: string; title: string; desc: string }) {
  return (
    <button className="menu-item" onClick={() => navigate(to)}>
      <div>
        <b>{title}</b>
        <span>{desc}</span>
      </div>
    </button>
  );
}

export default function More() {
  const { profile, signOut, canInstall, install } = useApp();
  const admin = profile?.role === 'ADMINISTRATEUR';
  return (
    <div>
      <h1>Plus</h1>
      <div className="menu">
        <Item to="#/formulaire/observation" title="Observations" desc="Grille d’observation des flux (15 minutes par zone)" />
        <Item to="#/zones" title="Zones" desc={admin ? 'Codes, emplacements candidats, validation' : 'Liste des zones de la mission'} />
      </div>

      {admin ? (
        <>
          <h2>Administration</h2>
          <div className="menu">
            <Item to="#/admin/mission" title="Mission" desc="Dates, statut, objectifs, consignes, participants" />
            <Item to="#/admin/equipe" title="Équipe" desc="Activer les comptes des enquêteurs" />
            <Item to="#/admin/reponses" title="Réponses" desc="Consulter, corriger, exclure, supprimer (avec trace)" />
            <Item to="#/admin/resultats" title="Résultats" desc="Synthèse calculée sur les réponses réelles" />
            <Item to="#/admin/export" title="Export" desc="CSV, Excel (XLSX) et rapport PDF" />
            <Item to="#/admin/journal" title="Journal des modifications" desc="Qui a modifié ou supprimé quoi" />
          </div>
        </>
      ) : (
        <div className="notice">
          Les résultats détaillés, les exports et la gestion de l’équipe sont réservés à l’administrateur. Vous voyez ici les totaux de l’équipe sur le tableau de bord.
        </div>
      )}

      <h2>Compte</h2>
      <div className="card">
        <p style={{ marginBottom: 4 }}><b>{profile?.full_name || profile?.email}</b></p>
        <p className="muted">{profile?.role === 'ADMINISTRATEUR' ? 'Administrateur' : 'Enquêteur'}</p>
        <p className="muted small">Sur un téléphone partagé, déconnectez-vous après usage. Les fiches non envoyées restent conservées sur ce téléphone.</p>
        <div className="btns">
          {canInstall && <button className="btn secondary" onClick={() => void install()}>Installer l’application sur l’écran d’accueil</button>}
          <button className="btn secondary" onClick={() => void signOut()}>Se déconnecter</button>
        </div>
      </div>
    </div>
  );
}
