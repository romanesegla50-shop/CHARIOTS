'use client';
import React, { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { useApp } from './AppProvider';
import QuestionField from './QuestionField';
import { ConfirmButton, ProgressBar, StatePill } from './ui';
import {
  FORMS, buildRow, defaultAnswers, firstInvalidStep, labelFor, validateStep, visibleQuestions,
  type Answers,
} from '@/lib/forms';
import { deleteRecord, getMeta, getRecord, nextCounter, putRecord, setMeta } from '@/lib/localdb';
import { queueForSync } from '@/lib/sync';
import { navigate, rememberDraftInUrl } from '@/lib/hashrouter';
import { uuid } from '@/lib/uuid';
import type { FormType, LocalRecord } from '@/lib/types';

type Phase = 'loading' | 'unavailable' | 'consent' | 'refused' | 'steps' | 'review' | 'done' | 'refusalSaved';

export default function FormWizard({ type, id: routeId }: { type: FormType; id?: string }) {
  const def = FORMS[type];
  const { user, reference, records, syncNow } = useApp();
  const zones = reference?.zones ?? [];
  const mission = reference?.mission ?? null;

  const idRef = useRef<string>(routeId ?? uuid());
  const createdAtRef = useRef(new Date().toISOString());
  const startedAtRef = useRef(new Date().toISOString());
  const orderingRef = useRef<'ASC' | 'DESC'>('ASC');
  const savedRef = useRef(false);
  const submittedRef = useRef(false);
  const dirtyRef = useRef(false);
  const timerRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const answersRef = useRef<Answers>(defaultAnswers(def));
  const stepRef = useRef(0);

  const [phase, setPhase] = useState<Phase>('loading');
  const [answers, setAnswers] = useState<Answers>(answersRef.current);
  const [stepIndex, setStepIndex] = useState(0);
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [refusalZone, setRefusalZone] = useState('');
  const [busy, setBusy] = useState(false);
  const [ordering, setOrdering] = useState<'ASC' | 'DESC'>('ASC');

  // ------------------------------------------------------------ sauvegarde du brouillon sur le téléphone
  const persist = useCallback(async () => {
    if (!user || !mission || submittedRef.current) return;
    dirtyRef.current = false;
    const a = answersRef.current;
    const rec: LocalRecord = {
      id: idRef.current,
      userId: user.id,
      kind: def.type,
      table: def.table,
      state: 'LOCAL',
      clientRev: uuid(),
      attempts: 0,
      draft: {
        answers: a,
        stepIndex: stepRef.current,
        startedAt: startedAtRef.current,
        ordering: orderingRef.current,
        consent: true,
      },
      zoneId: (a.zone_id as string | undefined) ?? null,
      createdAt: createdAtRef.current,
      updatedAt: new Date().toISOString(),
    };
    await putRecord(rec);
    if (!savedRef.current) {
      savedRef.current = true;
      rememberDraftInUrl(def.type, idRef.current);
    }
  }, [def.table, def.type, mission, user]);

  const flush = useCallback(() => {
    if (timerRef.current) {
      clearTimeout(timerRef.current);
      timerRef.current = null;
    }
    if (dirtyRef.current) void persist();
  }, [persist]);

  const scheduleSave = useCallback(() => {
    dirtyRef.current = true;
    if (timerRef.current) clearTimeout(timerRef.current);
    timerRef.current = setTimeout(() => {
      timerRef.current = null;
      void persist();
    }, 300);
  }, [persist]);

  useEffect(() => {
    const onHide = () => flush();
    window.addEventListener('pagehide', onHide);
    document.addEventListener('visibilitychange', onHide);
    return () => {
      window.removeEventListener('pagehide', onHide);
      document.removeEventListener('visibilitychange', onHide);
      flush(); // on quitte l'écran : rien ne se perd
    };
  }, [flush]);

  // ------------------------------------------------------------ chargement initial (reprise d'un brouillon)
  useEffect(() => {
    if (!user) return;
    let cancelled = false;
    (async () => {
      if (routeId) {
        const rec = await getRecord(routeId);
        if (cancelled) return;
        if (rec && rec.userId === user.id && rec.state === 'LOCAL' && rec.draft && rec.kind === type) {
          answersRef.current = rec.draft.answers;
          stepRef.current = rec.draft.stepIndex;
          startedAtRef.current = rec.draft.startedAt;
          orderingRef.current = rec.draft.ordering;
          createdAtRef.current = rec.createdAt;
          savedRef.current = true;
          setAnswers(rec.draft.answers);
          setStepIndex(rec.draft.stepIndex);
          setOrdering(rec.draft.ordering);
          setPhase('steps');
        } else {
          setPhase('unavailable');
        }
        return;
      }
      const last = await getMeta<string>(`lastZone:${user.id}`);
      if (cancelled) return;
      if (last && zones.some((z) => z.id === last)) {
        answersRef.current = { ...answersRef.current, zone_id: last };
        setAnswers(answersRef.current);
        setRefusalZone(last);
      }
      setPhase(def.consent ? 'consent' : 'steps');
    })();
    return () => {
      cancelled = true;
    };
    // exécuté une seule fois à l'ouverture de l'écran
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [user?.id]);

  // ------------------------------------------------------------ actions
  const change = (key: string, value: unknown) => {
    answersRef.current = { ...answersRef.current, [key]: value };
    setAnswers(answersRef.current);
    if (errors[key]) setErrors((e) => {
      const { [key]: _drop, ...rest } = e;
      return rest;
    });
    if (key === 'zone_id' && user && typeof value === 'string') void setMeta(`lastZone:${user.id}`, value);
    scheduleSave();
  };

  const goStep = (i: number) => {
    stepRef.current = i;
    setStepIndex(i);
    setErrors({});
    dirtyRef.current = true;
    void persist();
    window.scrollTo({ top: 0 });
  };

  const accept = async () => {
    const n = await nextCounter('ordering');
    orderingRef.current = n % 2 === 0 ? 'DESC' : 'ASC';
    setOrdering(orderingRef.current);
    startedAtRef.current = new Date().toISOString();
    createdAtRef.current = startedAtRef.current;
    dirtyRef.current = true;
    await persist(); // la fiche existe sur le téléphone dès le consentement
    setPhase('steps');
  };

  const next = () => {
    const step = def.steps[stepIndex];
    const e = validateStep(step, answersRef.current);
    if (Object.keys(e).length) return setErrors(e);
    if (stepIndex === def.steps.length - 1) {
      const cross = firstInvalidStep(def, answersRef.current);
      if (cross.index >= 0) {
        setErrors(cross.errors);
        if (cross.index !== stepIndex) goStep(cross.index);
        return;
      }
      stepRef.current = stepIndex;
      dirtyRef.current = true;
      void persist();
      setPhase('review');
      window.scrollTo({ top: 0 });
    } else goStep(stepIndex + 1);
  };

  const submit = async () => {
    if (!user || !mission || busy) return;
    const v = firstInvalidStep(def, answersRef.current);
    if (v.index >= 0) {
      setErrors(v.errors);
      stepRef.current = v.index;
      setStepIndex(v.index);
      setPhase('steps');
      return;
    }
    setBusy(true);
    if (timerRef.current) clearTimeout(timerRef.current);
    submittedRef.current = true; // plus aucune sauvegarde de brouillon après ce point
    const row = buildRow(def, answersRef.current, {
      id: idRef.current,
      missionId: mission.id,
      userId: user.id,
      startedAt: startedAtRef.current,
      endedAt: new Date().toISOString(),
      createdAt: createdAtRef.current,
      ordering: orderingRef.current,
    });
    const rec: LocalRecord = {
      id: idRef.current,
      userId: user.id,
      kind: def.type,
      table: def.table,
      state: 'PENDING',
      clientRev: uuid(),
      attempts: 0,
      row,
      zoneId: (answersRef.current.zone_id as string | undefined) ?? null,
      createdAt: createdAtRef.current,
      updatedAt: new Date().toISOString(),
    };
    await queueForSync(rec);
    setPhase('done');
    setBusy(false);
    window.scrollTo({ top: 0 });
    void syncNow();
  };

  const abandon = async () => {
    submittedRef.current = true;
    if (timerRef.current) clearTimeout(timerRef.current);
    if (savedRef.current) await deleteRecord(idRef.current);
    navigate('#/');
  };

  const countRefusal = async () => {
    if (!user || !mission) return;
    setBusy(true);
    const id = uuid();
    const now = new Date().toISOString();
    const row: Record<string, unknown> = {
      id,
      mission_id: mission.id,
      surveyor_id: user.id,
      form_type: def.type === 'acheteur' ? 'ACHETEUR' : 'COMMERCANT',
      created_at: now,
    };
    if (refusalZone) row.zone_id = refusalZone;
    await queueForSync({
      id, userId: user.id, kind: 'refus', table: 'refusals', state: 'PENDING', clientRev: uuid(), attempts: 0,
      row, zoneId: refusalZone || null, createdAt: now, updatedAt: now,
    });
    // le brouillon vide créé pour la fiche n'a plus de raison d'être
    if (savedRef.current) await deleteRecord(idRef.current);
    submittedRef.current = true;
    setBusy(false);
    setPhase('refusalSaved');
    void syncNow();
  };

  // faire défiler jusqu'à la première erreur
  useEffect(() => {
    if (Object.keys(errors).length) {
      document.querySelector('[data-error="true"]')?.scrollIntoView({ block: 'center', behavior: 'smooth' });
    }
  }, [errors]);

  const live = useMemo(() => records.find((r) => r.id === idRef.current), [records]);

  // ------------------------------------------------------------ rendu
  if (!mission) {
    return (
      <div className="notice warn">
        Aucune mission n’est disponible sur ce téléphone. Connectez-vous avec du réseau pour la charger, ou demandez à l’administrateur de la créer.
      </div>
    );
  }
  if (zones.length === 0) {
    return (
      <div className="notice warn">
        Aucune zone n’est définie pour cette mission. L’administrateur doit d’abord créer les zones (Z01, Z02…).
      </div>
    );
  }
  if (type === 'evaluation' && !zones.some((z) => z.is_candidate)) {
    return (
      <div className="notice warn">
        Aucune zone candidate n’est définie. L’administrateur doit d’abord marquer jusqu’à 3 zones comme « candidates » (écran Zones).
      </div>
    );
  }
  if (phase === 'loading') return <p className="muted">Chargement…</p>;

  if (phase === 'unavailable') {
    return (
      <div className="card">
        <h2>Fiche introuvable</h2>
        <p>Ce brouillon n’existe plus sur ce téléphone, ou la fiche a déjà été soumise.</p>
        <div className="btns">
          <button className="btn" onClick={() => navigate('#/envois')}>Voir mes envois</button>
          <button className="btn secondary" onClick={() => navigate(`#/formulaire/${type}`)}>Nouvelle fiche</button>
        </div>
      </div>
    );
  }

  if (phase === 'consent') {
    return (
      <div className="stack">
        <h1>{def.title}</h1>
        <div className="card">
          <p style={{ fontSize: 20 }}>{def.intro}</p>
          <p className="muted">Lisez ce texte à la personne avant de commencer.</p>
        </div>
        <div className="btns">
          <button className="btn" onClick={() => void accept()}>Oui, accepte de répondre</button>
          <button className="btn secondary" onClick={() => setPhase('refused')}>Non, refuse de répondre</button>
        </div>
      </div>
    );
  }

  if (phase === 'refused') {
    return (
      <div className="stack">
        <h1>Refus de répondre</h1>
        <div className="notice ok">
          Aucune réponse n’est enregistrée. Remerciez la personne : elle est libre de refuser.
        </div>
        <div className="card">
          <p>
            Si vous le souhaitez, vous pouvez compter ce refus. C’est un simple compteur anonyme, sans aucune donnée sur la personne.
          </p>
          <label className="help" htmlFor="refus-zone">Zone (facultatif)</label>
          <select id="refus-zone" className="input" value={refusalZone} onChange={(e) => setRefusalZone(e.target.value)}>
            <option value="">— Aucune —</option>
            {zones.map((z) => (
              <option key={z.id} value={z.id}>{z.code}{z.label ? ` — ${z.label}` : ''}</option>
            ))}
          </select>
        </div>
        <div className="btns">
          <button className="btn" disabled={busy} onClick={() => void countRefusal()}>Compter ce refus</button>
          <button className="btn secondary" onClick={() => void abandon()}>Ne rien enregistrer</button>
        </div>
      </div>
    );
  }

  if (phase === 'refusalSaved') {
    return (
      <div className="stack center">
        <div className="notice ok">Refus compté (anonyme).</div>
        <div className="btns">
          <button className="btn" onClick={() => navigate(`#/formulaire/${type}`)}>Nouvelle fiche</button>
          <button className="btn secondary" onClick={() => navigate('#/')}>Retour à l’accueil</button>
        </div>
      </div>
    );
  }

  if (phase === 'done') {
    return (
      <div className="stack center">
        <div className="notice ok">
          <b>Fiche enregistrée sur ce téléphone.</b>
        </div>
        {live && (
          <p>
            <StatePill state={live.state} />
          </p>
        )}
        {live?.state === 'ERROR' && <div className="notice err">{live.error}</div>}
        <p className="muted">
          Elle part automatiquement vers la base commune dès que le réseau le permet. Vous pouvez continuer sans attendre.
        </p>
        <div className="btns">
          <button className="btn" onClick={() => navigate(`#/formulaire/${type}`)}>Nouvelle fiche</button>
          <button className="btn secondary" onClick={() => navigate('#/')}>Retour à l’accueil</button>
        </div>
      </div>
    );
  }

  if (phase === 'review') {
    return (
      <div className="stack">
        <h1>Vérifier avant d’envoyer</h1>
        {def.steps.map((s, i) => (
          <div className="card" key={s.title}>
            <div className="row spread">
              <h3>{s.title}</h3>
              <button className="btn secondary small" onClick={() => { setPhase('steps'); goStep(i); }}>Modifier</button>
            </div>
            <dl className="recap">
              {visibleQuestions(s, answers).map((q) => (
                <React.Fragment key={q.key}>
                  <dt>{q.label}</dt>
                  <dd>{labelFor(q, answers[q.key], zones)}</dd>
                </React.Fragment>
              ))}
            </dl>
          </div>
        ))}
        <p className="muted">
          La fiche est d’abord enregistrée sur ce téléphone, puis envoyée dès que le réseau le permet.
        </p>
        <div className="btns">
          <button className="btn" disabled={busy} onClick={() => void submit()}>Enregistrer et envoyer</button>
          <button className="btn secondary" onClick={() => { setPhase('steps'); goStep(def.steps.length - 1); }}>
            Revenir aux questions
          </button>
          <ConfirmButton label="Abandonner cette fiche" confirmLabel="Oui, supprimer le brouillon" onConfirm={() => void abandon()} className="btn danger" />
        </div>
      </div>
    );
  }

  // phase === 'steps'
  const step = def.steps[stepIndex];
  const isLast = stepIndex === def.steps.length - 1;
  return (
    <div>
      {def.note && stepIndex === 0 && <div className="notice">{def.note}</div>}
      <div className="progress">
        <div className="meta">Étape {stepIndex + 1} sur {def.steps.length}</div>
        <ProgressBar value={stepIndex + 1} max={def.steps.length} />
      </div>
      <h2>{step.title}</h2>
      {visibleQuestions(step, answers).map((q) => (
        <QuestionField key={q.key} q={q} answers={answers} error={errors[q.key]} zones={zones} ordering={ordering} onChange={change} />
      ))}
      <div className="footer-actions">
        <div className="btns two">
          {stepIndex > 0 ? (
            <button className="btn secondary" onClick={() => goStep(stepIndex - 1)}>Précédent</button>
          ) : (
            <ConfirmButton label="Abandonner" confirmLabel="Supprimer" onConfirm={() => void abandon()} className="btn danger" />
          )}
          <button className="btn" onClick={next}>{isLast ? 'Récapitulatif' : 'Suivant'}</button>
        </div>
      </div>
      <p className="muted small center">Brouillon enregistré automatiquement sur ce téléphone.</p>
    </div>
  );
}
