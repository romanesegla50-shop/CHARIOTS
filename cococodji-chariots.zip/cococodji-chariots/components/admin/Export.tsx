'use client';
import React, { useState } from 'react';
import { useApp } from '../AppProvider';
import { AdminGate, ErrorBox, Flash, Loading, useLoad, type FlashMsg } from './shared';
import { getClient } from '@/lib/supabase';
import { fetchAll, fetchSummary, listProfiles, listZones, type ServerRow } from '@/lib/admin';
import { buildDatasets, buildSummarySheet, csvBlob, downloadBlob, fmtLocalDate, safeFileName, toXlsxBlob, type Dataset } from '@/lib/export';
import { buildReport, reportFileName } from '@/lib/report';
import { DISCLAIMER } from '@/lib/stats';

interface Bundle {
  buyers: ServerRow[]; vendors: ServerRow[]; observations: ServerRow[]; evaluations: ServerRow[];
  zones: Awaited<ReturnType<typeof listZones>> extends { data: infer D } ? D : any; profiles: { id: string; full_name: string; email: string | null }[];
}

async function loadAll(missionId: string) {
  const c = getClient();
  const [b, v, o, e, z, p] = await Promise.all([
    fetchAll<ServerRow>(c, 'buyer_responses', (q) => q.eq('mission_id', missionId)),
    fetchAll<ServerRow>(c, 'vendor_responses', (q) => q.eq('mission_id', missionId)),
    fetchAll<ServerRow>(c, 'observation_sessions', (q) => q.eq('mission_id', missionId)),
    fetchAll<ServerRow>(c, 'zone_evaluations', (q) => q.eq('mission_id', missionId)),
    listZones(c, missionId),
    listProfiles(c),
  ]);
  for (const r of [b, v, o, e, z, p]) if (!r.ok) return { ok: false as const, error: r.error };
  return {
    ok: true as const,
    data: { buyers: (b as any).data, vendors: (v as any).data, observations: (o as any).data, evaluations: (e as any).data, zones: (z as any).data, profiles: (p as any).data } as Bundle,
  };
}

export default function Export() {
  const { reference } = useApp();
  const mission = reference?.mission ?? null;
  const [includeAll, setIncludeAll] = useState(false);
  const [msg, setMsg] = useState<FlashMsg>(null);
  const [busy, setBusy] = useState<string | null>(null);
  const data = useLoad(async () => loadAll(mission!.id), [mission?.id], Boolean(mission));

  const today = fmtLocalDate(new Date().toISOString());
  const ctx = data.data ? { zones: data.data.zones, profiles: data.data.profiles } : null;
  const sets = data.data && ctx
    ? buildDatasets({ ...data.data, mission, includeAll }, ctx)
    : null;

  const run = async (name: string, fn: () => Promise<void>) => {
    setBusy(name);
    setMsg(null);
    try {
      await fn();
    } catch (e) {
      setMsg({ kind: 'err', text: `Export impossible : ${e instanceof Error ? e.message : String(e)}` });
    }
    setBusy(null);
  };

  const csv = (ds: Dataset, file: string) => run(file, async () => {
    downloadBlob(csvBlob(ds), `${file}_${today}.csv`);
    setMsg({ kind: 'ok', text: `${ds.rows.length} ligne(s) exportée(s) : ${file}_${today}.csv` });
  });

  const summaryNow = async () => {
    const r = await fetchSummary(getClient(), mission!.id, {});
    if (!r.ok) throw new Error(r.error);
    return r.data;
  };

  const xlsx = () => run('xlsx', async () => {
    const s = await summaryNow();
    const d = sets!;
    const blob = await toXlsxBlob([buildSummarySheet(s, mission), d.buyers, d.vendors, d.observations, d.candidates, d.evaluations]);
    downloadBlob(blob, `${safeFileName(mission?.name ?? 'Cococodji_Chariots')}_${today}.xlsx`);
    setMsg({ kind: 'ok', text: 'Classeur Excel exporté (une feuille par questionnaire).' });
  });

  const pdf = () => run('pdf', async () => {
    const s = await summaryNow();
    const { renderReportPdf } = await import('@/lib/pdf');
    const generatedAt = new Date().toISOString();
    const model = buildReport({ mission, summary: s, zones: data.data!.zones, evaluations: data.data!.evaluations, generatedAt });
    downloadBlob(await renderReportPdf(model), reportFileName(generatedAt));
    setMsg({ kind: 'ok', text: 'Rapport PDF exporté.' });
  });

  const n = (ds?: Dataset) => ds?.rows.length ?? 0;

  return (
    <AdminGate title="Export">
      <div className="notice">
        Les fichiers contiennent les réponses anonymes réellement enregistrées. Un tableau par questionnaire, en-têtes en français, encodage UTF-8.
      </div>
      <Flash msg={msg} />
      {!mission && <div className="notice warn">Aucune mission disponible.</div>}
      {data.loading && !data.data && <Loading text="Préparation des données…" />}
      {data.error && <ErrorBox error={data.error} onRetry={data.reload} />}

      {sets && (
        <>
          <label className="choice">
            <input type="checkbox" checked={includeAll} onChange={(e) => setIncludeAll(e.target.checked)} />
            Inclure aussi les brouillons et les fiches exclues (colonne « Statut »)
          </label>

          <h2>Fichiers CSV</h2>
          <p className="muted small">Séparateur « ; », nombres décimaux avec virgule : s’ouvre directement dans Excel (France) et s’importe dans Google Sheets.</p>
          <div className="btns">
            <button className="btn" disabled={busy !== null} data-testid="csv-buyers" onClick={() => void csv(sets.buyers, 'Cococodji_acheteurs')}>Réponses acheteurs ({n(sets.buyers)})</button>
            <button className="btn" disabled={busy !== null} data-testid="csv-vendors" onClick={() => void csv(sets.vendors, 'Cococodji_commercantes')}>Réponses commerçantes ({n(sets.vendors)})</button>
            <button className="btn" disabled={busy !== null} data-testid="csv-obs" onClick={() => void csv(sets.observations, 'Cococodji_observations')}>Sessions d’observation ({n(sets.observations)})</button>
            <button className="btn" disabled={busy !== null} data-testid="csv-zones" onClick={() => void csv(sets.candidates, 'Cococodji_zones_candidates')}>Zones candidates ({n(sets.candidates)})</button>
            <button className="btn secondary" disabled={busy !== null} data-testid="csv-evals" onClick={() => void csv(sets.evaluations, 'Cococodji_evaluations_detaillees')}>Évaluations détaillées ({n(sets.evaluations)})</button>
          </div>

          <h2>Classeur Excel</h2>
          <button className="btn" disabled={busy !== null} data-testid="xlsx" onClick={() => void xlsx()}>
            {busy === 'xlsx' ? 'Préparation…' : 'Télécharger le classeur (XLSX)'}
          </button>
          <p className="muted small">Une feuille par questionnaire, plus une feuille « Synthèse ».</p>

          <h2>Rapport de synthèse</h2>
          <button className="btn" disabled={busy !== null} data-testid="pdf" onClick={() => void pdf()}>
            {busy === 'pdf' ? 'Préparation…' : 'Télécharger le rapport (PDF)'}
          </button>
          <p className="muted small">Chiffres réellement calculés, taille de l’échantillon, dates, zones et horaires couverts, limites de l’enquête. Neutre et utilisable comme annexe au dossier.</p>
          <div className="notice warn">{DISCLAIMER}</div>
        </>
      )}
    </AdminGate>
  );
}
