'use client';
import React, { useState } from 'react';
import { AdminGate, ErrorBox, Loading, useLoad } from './shared';
import { fmtDateTime } from '../ui';
import { getClient } from '@/lib/supabase';
import { TABLE_LABEL, auditChanges, fetchAudit, listProfiles, type AuditEntry } from '@/lib/admin';

const ACTION: Record<AuditEntry['action'], string> = { INSERT: 'Création', UPDATE: 'Modification', DELETE: 'Suppression' };
const show = (v: unknown) => {
  if (v === undefined || v === null) return '—';
  const s = typeof v === 'string' ? v : JSON.stringify(v);
  return s.length > 90 ? s.slice(0, 90) + '…' : s;
};

export default function Audit() {
  const log = useLoad(() => fetchAudit(getClient(), 100), []);
  const profiles = useLoad(() => listProfiles(getClient()), []);
  const [open, setOpen] = useState<number | null>(null);
  const name = (id: string | null) => {
    if (!id) return 'Système';
    const p = profiles.data?.find((x) => x.id === id);
    return p ? p.full_name || p.email || id.slice(0, 8) : id.slice(0, 8);
  };
  return (
    <AdminGate title="Journal des modifications">
      <p className="muted">Les 100 dernières actions. Le journal ne peut être ni modifié ni effacé depuis l’application.</p>
      {log.loading && !log.data && <Loading />}
      {log.error && <ErrorBox error={log.error} onRetry={log.reload} />}
      {log.data?.length === 0 && <div className="card center"><p className="muted">Aucune entrée pour l’instant.</p></div>}
      {log.data?.map((e) => {
        const changes = auditChanges(e);
        return (
          <div className="list-item" key={e.id} data-testid="audit-row">
            <div className="row spread wrap">
              <span className="t">{ACTION[e.action]} · {TABLE_LABEL[e.table_name] ?? e.table_name}</span>
              <span className="muted small">{fmtDateTime(e.at)}</span>
            </div>
            <div className="muted">Par {name(e.actor_id)}{e.actor_role === 'ADMINISTRATEUR' ? ' (administrateur)' : ''}{e.record_id ? ` · fiche ${e.record_id.slice(0, 8)}` : ''}</div>
            {(changes.length > 0 || e.action === 'DELETE') && (
              <>
                <button className="btn secondary small" style={{ marginTop: 8 }} onClick={() => setOpen(open === e.id ? null : e.id)}>
                  {open === e.id ? 'Masquer le détail' : 'Voir le détail'}
                </button>
                {open === e.id && (
                  <div style={{ marginTop: 8 }}>
                    {e.action === 'DELETE' && <p className="muted small">Contenu de la fiche au moment de la suppression :</p>}
                    {changes.map((c) => (
                      <p className="diff" key={c.field}>
                        <b>{c.field}</b> : {e.action !== 'DELETE' && <><s>{show(c.before)}</s> → </>}
                        <ins>{show(e.action === 'DELETE' ? c.before : c.after)}</ins>
                      </p>
                    ))}
                  </div>
                )}
              </>
            )}
          </div>
        );
      })}
    </AdminGate>
  );
}
