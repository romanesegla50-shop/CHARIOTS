'use client';
import React, { useCallback, useEffect, useRef, useState } from 'react';
import { useApp } from '../AppProvider';
import { navigate } from '@/lib/hashrouter';
import type { Result } from '@/lib/admin';

/** Charge des données du serveur et gère chargement / erreur / rechargement. */
export function useLoad<T>(fn: () => Promise<Result<T>>, deps: unknown[], enabled = true) {
  const [state, setState] = useState<{ loading: boolean; data: T | null; error: string | null }>({ loading: enabled, data: null, error: null });
  const seq = useRef(0);
  const fnRef = useRef(fn);
  fnRef.current = fn;
  const run = useCallback(async () => {
    const my = ++seq.current;
    setState((s) => ({ ...s, loading: true, error: null }));
    let r: Result<T>;
    try {
      r = await fnRef.current();
    } catch (e) {
      r = { ok: false, error: e instanceof Error ? e.message : String(e) };
    }
    if (my !== seq.current) return;
    setState(r.ok ? { loading: false, data: r.data, error: null } : { loading: false, data: null, error: r.error });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, deps);
  useEffect(() => {
    if (enabled) void run();
  }, [run, enabled]);
  return { ...state, reload: run };
}

export type FlashMsg = { kind: 'ok' | 'err'; text: string } | null;

export function Flash({ msg }: { msg: FlashMsg }) {
  if (!msg) return null;
  return (
    <div className={`notice ${msg.kind === 'ok' ? 'ok' : 'err'}`} role={msg.kind === 'err' ? 'alert' : 'status'}>
      {msg.text}
    </div>
  );
}

export function BackToMenu() {
  return (
    <button className="back" onClick={() => navigate('#/plus')}>
      ‹ Plus
    </button>
  );
}

/** Réservé à l'administrateur (la base applique de toute façon les mêmes règles) et nécessite le réseau. */
export function AdminGate({ title, children }: { title: string; children: React.ReactNode }) {
  const { profile, online } = useApp();
  if (profile?.role !== 'ADMINISTRATEUR') {
    return (
      <div className="stack">
        <BackToMenu />
        <h1>{title}</h1>
        <div className="notice warn">Cet écran est réservé à l’administrateur.</div>
      </div>
    );
  }
  return (
    <div>
      <BackToMenu />
      <h1>{title}</h1>
      {!online && <div className="notice warn">Cet écran a besoin du réseau. Reconnectez-vous pour continuer.</div>}
      {children}
    </div>
  );
}

export function Loading({ text = 'Chargement…' }: { text?: string }) {
  return <p className="muted">{text}</p>;
}
export function ErrorBox({ error, onRetry }: { error: string; onRetry?: () => void }) {
  return (
    <div className="notice err" role="alert">
      {error}
      {onRetry && (
        <div style={{ marginTop: 8 }}>
          <button className="btn secondary small" onClick={onRetry}>Réessayer</button>
        </div>
      )}
    </div>
  );
}
