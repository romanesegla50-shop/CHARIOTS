'use client';
import React, { useEffect, useState } from 'react';
import { useApp } from '../AppProvider';
import { AdminGate, ErrorBox, Flash, Loading, useLoad, type FlashMsg } from './shared';
import { getClient } from '@/lib/supabase';
import { listMembers, listMissions, listProfiles, saveMission, setMember, validateMission, type MissionInput } from '@/lib/admin';
import { MISSION_STATUS_LABEL, type ReferenceMission } from '@/lib/types';

const EMPTY: MissionInput = {
  name: 'Mission pilote Cococodji', start_date: null, end_date: null, status: 'PREPARATION', instructions: null,
  target_buyers: 30, target_vendors: 15, target_observations: 6,
};

export default function Mission() {
  const { reference, refreshAll } = useApp();
  const missions = useLoad(() => listMissions(getClient()), []);
  const profiles = useLoad(() => listProfiles(getClient()), []);
  const current = reference?.mission ?? null;
  const row = missions.data?.find((m) => m.id === current?.id) ?? missions.data?.[0] ?? null;

  const [form, setForm] = useState<MissionInput>(EMPTY);
  const [members, setMembers] = useState<string[]>([]);
  const [msg, setMsg] = useState<FlashMsg>(null);
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    if (row) {
      setForm({
        name: row.name, start_date: row.start_date, end_date: row.end_date, status: row.status, instructions: row.instructions,
        target_buyers: row.target_buyers, target_vendors: row.target_vendors, target_observations: row.target_observations,
      });
      void listMembers(getClient(), row.id).then((r) => r.ok && setMembers(r.data));
    }
  }, [row?.id, missions.data]); // eslint-disable-line react-hooks/exhaustive-deps

  const set = <K extends keyof MissionInput>(k: K, v: MissionInput[K]) => setForm((f) => ({ ...f, [k]: v }));
  const num = (v: string) => (v === '' ? NaN : Number(v));

  const save = async () => {
    const problem = validateMission(form);
    if (problem) return setMsg({ kind: 'err', text: problem });
    setBusy(true);
    const r = await saveMission(getClient(), row?.id ?? null, form);
    setBusy(false);
    if (!r.ok) return setMsg({ kind: 'err', text: r.error });
    setMsg({ kind: 'ok', text: row ? 'Mission enregistrée.' : 'Mission créée. Ajoutez maintenant les zones (écran Zones).' });
    await missions.reload();
    await refreshAll();
  };

  const toggleMember = async (userId: string, on: boolean) => {
    if (!row) return;
    const r = await setMember(getClient(), row.id, userId, on);
    if (!r.ok) return setMsg({ kind: 'err', text: r.error });
    setMembers((m) => (on ? [...m, userId] : m.filter((x) => x !== userId)));
  };

  return (
    <AdminGate title="Mission">
      {missions.loading && !missions.data && <Loading />}
      {missions.error && <ErrorBox error={missions.error} onRetry={missions.reload} />}
      {!missions.loading && !missions.error && (
        <>
          {!row && <div className="notice">Aucune mission pour l’instant : remplissez le formulaire pour la créer.</div>}
          <Flash msg={msg} />
          <div className="card">
            <div className="field">
              <label className="lead" htmlFor="m-name">Nom de la mission</label>
              <input id="m-name" className="input" value={form.name} onChange={(e) => set('name', e.target.value)} maxLength={200} />
            </div>
            <div className="filters">
              <div className="field">
                <label htmlFor="m-start">Début prévu</label>
                <input id="m-start" type="date" className="input" value={form.start_date ?? ''} onChange={(e) => set('start_date', e.target.value || null)} />
              </div>
              <div className="field">
                <label htmlFor="m-end">Fin prévue</label>
                <input id="m-end" type="date" className="input" value={form.end_date ?? ''} onChange={(e) => set('end_date', e.target.value || null)} />
              </div>
            </div>
            <div className="field">
              <label className="lead" htmlFor="m-status">Statut</label>
              <select id="m-status" className="input" value={form.status} onChange={(e) => set('status', e.target.value as ReferenceMission['status'])}>
                {(Object.keys(MISSION_STATUS_LABEL) as ReferenceMission['status'][]).map((k) => (
                  <option key={k} value={k}>{MISSION_STATUS_LABEL[k]}</option>
                ))}
              </select>
            </div>
            <h3>Objectifs exploratoires</h3>
            <p className="help">Ce sont des objectifs, pas des quotas obligatoires ni une garantie de représentativité statistique.</p>
            <div className="filters">
              <div className="field">
                <label htmlFor="m-tb">Acheteurs</label>
                <input id="m-tb" className="input" inputMode="numeric" value={Number.isNaN(form.target_buyers) ? '' : form.target_buyers} onChange={(e) => set('target_buyers', num(e.target.value))} />
              </div>
              <div className="field">
                <label htmlFor="m-tv">Commerçantes</label>
                <input id="m-tv" className="input" inputMode="numeric" value={Number.isNaN(form.target_vendors) ? '' : form.target_vendors} onChange={(e) => set('target_vendors', num(e.target.value))} />
              </div>
              <div className="field wide">
                <label htmlFor="m-to">Sessions d’observation</label>
                <input id="m-to" className="input" inputMode="numeric" value={Number.isNaN(form.target_observations) ? '' : form.target_observations} onChange={(e) => set('target_observations', num(e.target.value))} />
              </div>
            </div>
            <div className="field">
              <label className="lead" htmlFor="m-instr">Consignes communes</label>
              <p className="help">Affichées à tous les enquêteurs sur leur tableau de bord.</p>
              <textarea id="m-instr" className="input" value={form.instructions ?? ''} onChange={(e) => set('instructions', e.target.value || null)} maxLength={5000} />
            </div>
            <button className="btn" disabled={busy} onClick={() => void save()}>{row ? 'Enregistrer la mission' : 'Créer la mission'}</button>
          </div>

          {row && (
            <>
              <h2>Enquêteurs participants</h2>
              <p className="muted">Information pour le suivi de l’équipe. Un compte activé peut saisir des réponses pour la mission.</p>
              {profiles.data?.filter((p) => p.active && p.role === 'ENQUETEUR').length === 0 && (
                <div className="notice">Aucun enquêteur activé. Activez les comptes dans l’écran Équipe.</div>
              )}
              {profiles.data?.filter((p) => p.active && p.role === 'ENQUETEUR').map((p) => (
                <label key={p.id} className="choice">
                  <input type="checkbox" checked={members.includes(p.id)} onChange={(e) => void toggleMember(p.id, e.target.checked)} />
                  {p.full_name || p.email}
                </label>
              ))}
            </>
          )}
        </>
      )}
    </AdminGate>
  );
}
