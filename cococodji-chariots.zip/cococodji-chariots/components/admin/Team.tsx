'use client';
import React, { useState } from 'react';
import { useApp } from '../AppProvider';
import { AdminGate, ErrorBox, Flash, Loading, useLoad, type FlashMsg } from './shared';
import { ConfirmButton } from '../ui';
import { getClient } from '@/lib/supabase';
import { listProfiles, updateProfile } from '@/lib/admin';
import type { Profile } from '@/lib/types';

function Row({ p, me, onDone, setMsg }: { p: Profile; me: boolean; onDone: () => Promise<void>; setMsg: (m: FlashMsg) => void }) {
  const [name, setName] = useState(p.full_name);
  const [busy, setBusy] = useState(false);
  const run = async (patch: Partial<Pick<Profile, 'active' | 'role' | 'full_name'>>, ok: string) => {
    setBusy(true);
    const r = await updateProfile(getClient(), p.id, patch);
    setBusy(false);
    if (!r.ok) return setMsg({ kind: 'err', text: r.error });
    setMsg({ kind: 'ok', text: ok });
    await onDone();
  };
  return (
    <div className="list-item" data-testid={`member-${p.email}`}>
      <div className="row spread wrap">
        <span className="t">{p.full_name || p.email}{me ? ' (vous)' : ''}</span>
        <span className="row wrap">
          <span className={`pill ${p.role === 'ADMINISTRATEUR' ? 'blue' : 'gray'}`}>{p.role === 'ADMINISTRATEUR' ? 'Administrateur' : 'Enquêteur'}</span>
          <span className={`pill ${p.active ? 'green' : 'amber'}`}>{p.active ? 'Activé' : 'À activer'}</span>
        </span>
      </div>
      <div className="muted">{p.email}</div>
      <div className="field" style={{ marginTop: 10, marginBottom: 10 }}>
        <label className="help" htmlFor={`n-${p.id}`}>Nom affiché</label>
        <div className="row">
          <input id={`n-${p.id}`} className="input" style={{ minHeight: 48 }} value={name} maxLength={120} onChange={(e) => setName(e.target.value)} />
          <button className="btn secondary small" disabled={busy || name === p.full_name} onClick={() => void run({ full_name: name.trim() }, 'Nom enregistré.')}>OK</button>
        </div>
      </div>
      {!me && (
        <div className="row wrap">
          {p.active ? (
            <ConfirmButton label="Désactiver" confirmLabel="Oui, désactiver ce compte" onConfirm={() => void run({ active: false }, `${p.full_name || p.email} désactivé.`)} />
          ) : (
            <button className="btn small" disabled={busy} onClick={() => void run({ active: true }, `${p.full_name || p.email} activé.`)}>Activer ce compte</button>
          )}
          {p.role === 'ENQUETEUR' ? (
            <ConfirmButton label="Passer administrateur" confirmLabel="Oui, donner les droits d’administrateur" className="btn secondary small" onConfirm={() => void run({ role: 'ADMINISTRATEUR' }, 'Rôle modifié.')} />
          ) : (
            <ConfirmButton label="Repasser enquêteur" confirmLabel="Oui, retirer les droits d’administrateur" className="btn secondary small" onConfirm={() => void run({ role: 'ENQUETEUR' }, 'Rôle modifié.')} />
          )}
        </div>
      )}
    </div>
  );
}

export default function Team() {
  const { user } = useApp();
  const list = useLoad(() => listProfiles(getClient()), []);
  const [msg, setMsg] = useState<FlashMsg>(null);
  const toActivate = list.data?.filter((p) => !p.active) ?? [];
  const others = list.data?.filter((p) => p.active) ?? [];

  return (
    <AdminGate title="Équipe">
      <div className="notice">
        <b>Créer le compte d’un ami :</b> dans Supabase, menu Authentication, Users, « Add user » (cochez « Auto Confirm User »). Il apparaît ensuite ici, « À activer ». Chaque enquêteur a son propre compte : ne partagez jamais un compte administrateur.
      </div>
      <Flash msg={msg} />
      {list.loading && !list.data && <Loading />}
      {list.error && <ErrorBox error={list.error} onRetry={list.reload} />}
      {toActivate.length > 0 && (
        <>
          <h2>Comptes à activer ({toActivate.length})</h2>
          {toActivate.map((p) => <Row key={p.id} p={p} me={p.id === user?.id} onDone={list.reload} setMsg={setMsg} />)}
        </>
      )}
      <h2>Comptes activés ({others.length})</h2>
      {others.map((p) => <Row key={p.id} p={p} me={p.id === user?.id} onDone={list.reload} setMsg={setMsg} />)}
    </AdminGate>
  );
}
