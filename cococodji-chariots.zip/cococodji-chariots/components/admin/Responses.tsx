'use client';
import React, { useMemo, useState } from 'react';
import { useApp } from '../AppProvider';
import QuestionField from '../QuestionField';
import { AdminGate, ErrorBox, Flash, Loading, useLoad, type FlashMsg } from './shared';
import { ConfirmButton, fmtDateTime } from '../ui';
import { getClient } from '@/lib/supabase';
import {
  RESPONSE_TABLES, STATUS_LABEL, deleteResponse, fetchAll, listProfiles, setResponseStatus, updateResponse,
  type ResponseStatus, type ResponseTable, type ServerRow,
} from '@/lib/admin';
import { FORMS, buildPatch, firstInvalidStep, labelFor, rowToAnswers, visibleQuestions, type Answers } from '@/lib/forms';
import type { ReferenceZone } from '@/lib/types';

const STATUS_PILL: Record<ResponseStatus, string> = { SOUMIS: 'green', EXCLU: 'amber', BROUILLON: 'gray' };

function Recap({ table, row, zones }: { table: ResponseTable; row: ServerRow; zones: ReferenceZone[] }) {
  const def = FORMS[RESPONSE_TABLES.find((t) => t.table === table)!.kind];
  const answers = rowToAnswers(def, row);
  return (
    <dl className="recap">
      {def.steps.flatMap((s) => visibleQuestions(s, answers)).map((q) => (
        <React.Fragment key={q.key}>
          <dt>{q.label}</dt>
          <dd>{labelFor(q, answers[q.key], zones)}</dd>
        </React.Fragment>
      ))}
    </dl>
  );
}

function Editor({ table, row, zones, onSaved, onCancel, setMsg }: {
  table: ResponseTable; row: ServerRow; zones: ReferenceZone[]; onSaved: () => Promise<void>; onCancel: () => void; setMsg: (m: FlashMsg) => void;
}) {
  const def = FORMS[RESPONSE_TABLES.find((t) => t.table === table)!.kind];
  const [answers, setAnswers] = useState<Answers>(() => rowToAnswers(def, row));
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [busy, setBusy] = useState(false);

  const change = (key: string, value: unknown) => {
    setAnswers((a) => ({ ...a, [key]: value }));
    setErrors((e) => {
      const { [key]: _x, ...rest } = e;
      return rest;
    });
  };

  const save = async () => {
    const v = firstInvalidStep(def, answers);
    if (v.index >= 0) {
      setErrors(v.errors);
      return setMsg({ kind: 'err', text: 'Certains champs sont à corriger (en rouge).' });
    }
    const patch = buildPatch(def, row, answers);
    if (Object.keys(patch).length === 0) return setMsg({ kind: 'err', text: 'Aucun changement à enregistrer.' });
    setBusy(true);
    const r = await updateResponse(getClient(), table, row.id, row.version, patch);
    setBusy(false);
    if (!r.ok) {
      setMsg({ kind: 'err', text: r.error });
      if (r.conflict) await onSaved(); // recharge la version actuelle du serveur
      return;
    }
    setMsg({ kind: 'ok', text: 'Correction enregistrée et tracée dans le journal.' });
    await onSaved();
    onCancel();
  };

  return (
    <div style={{ marginTop: 12 }}>
      <div className="notice">Correction par l’administrateur : chaque modification est enregistrée dans le journal (valeur avant et après).</div>
      {def.steps.map((s) => (
        <div key={s.title}>
          <h3>{s.title}</h3>
          {visibleQuestions(s, answers).map((q) => (
            <QuestionField key={q.key} q={q} answers={answers} error={errors[q.key]} zones={zones} ordering="ASC" onChange={change} />
          ))}
        </div>
      ))}
      <div className="btns two">
        <button className="btn" disabled={busy} onClick={() => void save()}>Enregistrer la correction</button>
        <button className="btn secondary" onClick={onCancel}>Annuler</button>
      </div>
    </div>
  );
}

export default function Responses() {
  const { reference, online } = useApp();
  const mission = reference?.mission ?? null;
  const zones = reference?.zones ?? [];
  const [table, setTable] = useState<ResponseTable>('buyer_responses');
  const [status, setStatus] = useState<'ALL' | ResponseStatus>('ALL');
  const [surveyor, setSurveyor] = useState('');
  const [zone, setZone] = useState('');
  const [shown, setShown] = useState(30);
  const [open, setOpen] = useState<string | null>(null);
  const [editing, setEditing] = useState<string | null>(null);
  const [msg, setMsg] = useState<FlashMsg>(null);

  const profiles = useLoad(() => listProfiles(getClient()), []);
  const rows = useLoad(
    () => fetchAll<ServerRow>(getClient(), table, (q) => q.eq('mission_id', mission!.id)),
    [table, mission?.id],
    Boolean(mission && online),
  );
  const nameOf = (id: string) => {
    const p = profiles.data?.find((x) => x.id === id);
    return p ? p.full_name || p.email || id.slice(0, 8) : id.slice(0, 8);
  };
  const codeOf = (id: string | null) => zones.find((z) => z.id === id)?.code ?? '—';

  const list = useMemo(() => {
    const all = rows.data ?? [];
    return all
      .filter((r) => (status === 'ALL' ? true : r.status === status) && (!surveyor || r.surveyor_id === surveyor) && (!zone || r.zone_id === zone))
      .sort((a, b) => String(b.created_at).localeCompare(String(a.created_at)));
  }, [rows.data, status, surveyor, zone]);

  const act = async (p: Promise<{ ok: boolean; error?: string; conflict?: boolean }>, ok: string) => {
    const r = await p;
    if (!r.ok) setMsg({ kind: 'err', text: (r as { error: string }).error });
    else setMsg({ kind: 'ok', text: ok });
    await rows.reload();
  };

  return (
    <AdminGate title="Réponses">
      <Flash msg={msg} />
      <div className="filters">
        <div className="field wide">
          <label htmlFor="r-table">Type de fiche</label>
          <select id="r-table" className="input" value={table} onChange={(e) => { setTable(e.target.value as ResponseTable); setOpen(null); setEditing(null); setShown(30); }}>
            {RESPONSE_TABLES.map((t) => <option key={t.table} value={t.table}>{t.label}</option>)}
          </select>
        </div>
        <div className="field">
          <label htmlFor="r-status">Statut</label>
          <select id="r-status" className="input" value={status} onChange={(e) => setStatus(e.target.value as 'ALL' | ResponseStatus)}>
            <option value="ALL">Tous</option>
            {(Object.keys(STATUS_LABEL) as ResponseStatus[]).map((s) => <option key={s} value={s}>{STATUS_LABEL[s]}</option>)}
          </select>
        </div>
        <div className="field">
          <label htmlFor="r-zone">Zone</label>
          <select id="r-zone" className="input" value={zone} onChange={(e) => setZone(e.target.value)}>
            <option value="">Toutes</option>
            {zones.map((z) => <option key={z.id} value={z.id}>{z.code}</option>)}
          </select>
        </div>
        <div className="field wide">
          <label htmlFor="r-surv">Enquêteur</label>
          <select id="r-surv" className="input" value={surveyor} onChange={(e) => setSurveyor(e.target.value)}>
            <option value="">Tous</option>
            {profiles.data?.map((p) => <option key={p.id} value={p.id}>{p.full_name || p.email}</option>)}
          </select>
        </div>
      </div>

      {rows.loading && !rows.data && <Loading />}
      {rows.error && <ErrorBox error={rows.error} onRetry={rows.reload} />}
      {rows.data && <p className="muted">{list.length} fiche{list.length > 1 ? 's' : ''} sur {rows.data.length}.</p>}
      {rows.data && rows.data.length === 0 && (
        <div className="card center"><p className="muted">Aucune fiche de ce type enregistrée pour l’instant.</p></div>
      )}

      {list.slice(0, shown).map((r) => (
        <div className="list-item" key={r.id} data-testid="response-row" data-id={r.id}>
          <div className="row spread wrap">
            <span className="t">{nameOf(r.surveyor_id)} · zone {codeOf(r.zone_id)}</span>
            <span className={`pill ${STATUS_PILL[r.status]}`}>{STATUS_LABEL[r.status]}</span>
          </div>
          <div className="muted">{fmtDateTime(r.submitted_at ?? r.created_at)} · version {r.version}</div>
          <div className="row wrap" style={{ marginTop: 10 }}>
            <button className="btn secondary small" onClick={() => setOpen(open === r.id ? null : r.id)}>{open === r.id ? 'Masquer' : 'Voir'}</button>
            {r.status !== 'BROUILLON' && (
              <button className="btn secondary small" onClick={() => { setEditing(editing === r.id ? null : r.id); setOpen(r.id); }}>Corriger</button>
            )}
            {r.status === 'SOUMIS' && (
              <ConfirmButton label="Exclure" confirmLabel="Oui, exclure des résultats" className="btn secondary small"
                onConfirm={() => void act(setResponseStatus(getClient(), table, r.id, r.version, 'EXCLU'), 'Fiche exclue des résultats (tracé dans le journal).')} />
            )}
            {r.status === 'EXCLU' && (
              <button className="btn secondary small" onClick={() => void act(setResponseStatus(getClient(), table, r.id, r.version, 'SOUMIS'), 'Fiche réintégrée dans les résultats.')}>Réintégrer</button>
            )}
            <ConfirmButton label="Supprimer" confirmLabel="Oui, supprimer définitivement"
              onConfirm={() => void act(deleteResponse(getClient(), table, r.id), 'Fiche supprimée (le contenu reste dans le journal).')} />
          </div>
          {open === r.id && editing !== r.id && <Recap table={table} row={r} zones={zones} />}
          {editing === r.id && (
            <Editor table={table} row={r} zones={zones} setMsg={setMsg} onSaved={async () => { await rows.reload(); }} onCancel={() => setEditing(null)} />
          )}
        </div>
      ))}
      {list.length > shown && <button className="btn secondary" onClick={() => setShown((n) => n + 30)}>Voir plus</button>}
    </AdminGate>
  );
}
