'use client';
import React, { useMemo, useState } from 'react';
import { useApp } from '../AppProvider';
import { AdminGate, ErrorBox, Loading, useLoad } from './shared';
import { ProgressBar, fmtDate } from '../ui';
import { getClient } from '@/lib/supabase';
import { fetchAll, fetchSummary, listProfiles, listZones, type Ratio, type ServerRow, type Summary } from '@/lib/admin';
import {
  CONFUSION_WARNING, DISCLAIMER, EVAL_CRITERIA, NOT_AUTHORIZED, distribution, optionLabel, pct, ratioText, summarizeEvaluations, willingToPay,
} from '@/lib/stats';
import type { FormType } from '@/lib/types';

type Section = 'all' | FormType;

function Kpi({ label, r, hint }: { label: string; r: Ratio; hint?: string }) {
  return (
    <div className="kpi" data-testid="kpi">
      <div className="big">{pct(r)}</div>
      <div className="lbl">{label}</div>
      <div className="base">{ratioText(r)}</div>
      {hint && <div className="base">{hint}</div>}
    </div>
  );
}

function Dist({ title, note, obj, form, qkey, base }: { title: string; note?: string; obj: Record<string, number>; form: FormType; qkey: string; base: number }) {
  const rows = distribution(obj, (k) => optionLabel(form, qkey, k), base);
  if (rows.length === 0) return null;
  return (
    <div className="card">
      <h3>{title}</h3>
      {note && <p className="help">{note}</p>}
      <div className="dist">
        {rows.map((r) => (
          <div className="r" key={r.key}>
            <span>{r.label}</span>
            <b>{r.count} sur {base} · {r.pct}</b>
            <div className="bar"><i style={{ width: `${Math.round(r.share * 100)}%` }} /></div>
          </div>
        ))}
      </div>
    </div>
  );
}

export default function Results() {
  const { reference, counts } = useApp();
  const mission = reference?.mission ?? null;
  const zones = reference?.zones ?? [];
  const [from, setFrom] = useState('');
  const [to, setTo] = useState('');
  const [surveyor, setSurveyor] = useState('');
  const [zone, setZone] = useState('');
  const [section, setSection] = useState<Section>('all');

  const profiles = useLoad(() => listProfiles(getClient()), []);
  const summary = useLoad(
    () => fetchSummary(getClient(), mission!.id, { from: from || null, to: to || null, surveyor: surveyor || null, zone: zone || null }),
    [mission?.id, from, to, surveyor, zone],
    Boolean(mission),
  );
  const evals = useLoad(() => fetchAll<ServerRow>(getClient(), 'zone_evaluations', (q) => q.eq('mission_id', mission!.id)), [mission?.id], Boolean(mission));
  const fullZones = useLoad(() => listZones(getClient(), mission!.id), [mission?.id], Boolean(mission));

  const s: Summary | null = summary.data;
  const noData = s ? s.buyers_total + s.vendors_total + s.observations_total === 0 : false;
  const evalSummary = useMemo(() => summarizeEvaluations(evals.data ?? []), [evals.data]);
  const candidates = (fullZones.data ?? []).filter((z) => z.is_candidate);
  const show = (x: FormType) => section === 'all' || section === x;
  const pay = s ? willingToPay(s.price_distribution) : { n: 0, d: 0 };

  return (
    <AdminGate title="Résultats">
      <div className="notice">{NOT_AUTHORIZED}</div>
      <div className="notice warn" data-testid="disclaimer"><b>{DISCLAIMER}</b></div>
      {!mission && <div className="notice warn">Aucune mission disponible.</div>}

      <div className="card">
        <div className="filters">
          <div className="field">
            <label htmlFor="f-from">Du</label>
            <input id="f-from" type="date" className="input" value={from} onChange={(e) => setFrom(e.target.value)} />
          </div>
          <div className="field">
            <label htmlFor="f-to">Au</label>
            <input id="f-to" type="date" className="input" value={to} onChange={(e) => setTo(e.target.value)} />
          </div>
          <div className="field">
            <label htmlFor="f-surv">Enquêteur</label>
            <select id="f-surv" className="input" value={surveyor} onChange={(e) => setSurveyor(e.target.value)}>
              <option value="">Tous</option>
              {profiles.data?.map((p) => <option key={p.id} value={p.id}>{p.full_name || p.email}</option>)}
            </select>
          </div>
          <div className="field">
            <label htmlFor="f-zone">Zone</label>
            <select id="f-zone" className="input" value={zone} onChange={(e) => setZone(e.target.value)}>
              <option value="">Toutes</option>
              {zones.map((z) => <option key={z.id} value={z.id}>{z.code}</option>)}
            </select>
          </div>
          <div className="field wide">
            <label htmlFor="f-type">Type de formulaire</label>
            <select id="f-type" className="input" value={section} onChange={(e) => setSection(e.target.value as Section)}>
              <option value="all">Tous</option>
              <option value="acheteur">Acheteurs</option>
              <option value="commercante">Commerçantes</option>
              <option value="observation">Observations</option>
              <option value="evaluation">Emplacements candidats</option>
            </select>
          </div>
        </div>
        {(from || to || surveyor || zone || section !== 'all') && (
          <button className="btn secondary small" onClick={() => { setFrom(''); setTo(''); setSurveyor(''); setZone(''); setSection('all'); }}>Effacer les filtres</button>
        )}
      </div>

      {summary.loading && !s && <Loading text="Calcul en cours…" />}
      {summary.error && <ErrorBox error={summary.error} onRetry={summary.reload} />}

      {s && (
        <>
          {noData && (
            <div className="card center" data-testid="empty-state">
              <h3>Aucune réponse valide pour l’instant</h3>
              <p className="muted">
                Aucune fiche soumise ne correspond à ces filtres. Les résultats s’afficheront dès que des réponses auront été envoyées par les enquêteurs.
              </p>
            </div>
          )}

          <h2>Échantillon</h2>
          <div className="grid2" style={{ marginBottom: 10 }}>
            <div className="stat"><b data-testid="n-buyers">{s.buyers_total}</b><span>Acheteurs interrogés</span></div>
            <div className="stat"><b data-testid="n-vendors">{s.vendors_total}</b><span>Commerçantes interrogées</span></div>
            <div className="stat"><b data-testid="n-obs">{s.observations_total}</b><span>Sessions d’observation</span></div>
            <div className="stat"><b>{s.zones_studied}</b><span>Zones étudiées</span></div>
          </div>
          {mission && (
            <div className="card">
              <div className="row spread"><b>Acheteurs</b><span>{s.buyers_total} sur {mission.target_buyers}</span></div>
              <ProgressBar value={s.buyers_total} max={mission.target_buyers} />
              <div className="row spread" style={{ marginTop: 10 }}><b>Commerçantes</b><span>{s.vendors_total} sur {mission.target_vendors}</span></div>
              <ProgressBar value={s.vendors_total} max={mission.target_vendors} />
              <p className="muted small" style={{ marginTop: 10 }}>
                Objectifs exploratoires, pas des quotas. {s.first_date ? `Réponses du ${fmtDate(s.first_date)} au ${fmtDate(s.last_date)}.` : ''}
              </p>
            </div>
          )}
          <div className="card">
            <h3>Qualité des données</h3>
            <p className="muted" style={{ marginBottom: 4 }}>Calculs sur les fiches <b>soumises</b> uniquement. Non comptées :</p>
            <ul style={{ margin: '0 0 0 18px', padding: 0 }}>
              <li>{s.drafts.buyers + s.drafts.vendors + s.drafts.observations} brouillon(s) sur le serveur</li>
              <li>{s.excluded.buyers + s.excluded.vendors + s.excluded.observations} fiche(s) exclue(s)</li>
              <li>{s.refusals} refus comptés (anonymes)</li>
              <li>{counts.pending} fiche(s) en attente de synchronisation sur ce téléphone</li>
            </ul>
          </div>

          {!noData && show('acheteur') && s.buyers_total > 0 && (
            <>
              <h2>Acheteurs</h2>
              <div className="stack" style={{ marginBottom: 14 }}>
                <Kpi label="Difficultés souvent ou presque à chaque visite" r={s.buyers_often_difficulty} />
                <Kpi label="Intérêt déclaré (certainement ou probablement)" r={s.buyers_interested} />
                <Kpi label="Volonté déclarée de payer (un prix choisi)" r={pay} />
                <Kpi label="Deux trajets ou plus pour une visite typique" r={s.buyers_two_trips_or_more} />
              </div>
              <div className="notice warn">{CONFUSION_WARNING}</div>
              <Dist title="Prix jugé acceptable (déclaratif)" obj={s.price_distribution} form="acheteur" qkey="q10_prix" base={s.buyers_total} />
              {s.price_other_amounts_fcfa.length > 0 && <p className="muted">Autres montants proposés : {s.price_other_amounts_fcfa.join(', ')} FCFA.</p>}
              <Dist title="Difficultés principales" note="Plusieurs réponses possibles : le total peut dépasser 100 %." obj={s.difficulties} form="acheteur" qkey="q3_difficultes" base={s.buyers_total} />
              <Dist title="Principale inquiétude" obj={s.concerns} form="acheteur" qkey="q12_inquietude" base={s.buyers_total} />
              <Dist title="Une caution remboursable découragerait-elle ?" obj={s.deposit_reaction} form="acheteur" qkey="q11_caution" base={s.buyers_total} />
            </>
          )}

          {!noData && show('commercante') && s.vendors_total > 0 && (
            <>
              <h2>Commerçantes</h2>
              <div className="stack" style={{ marginBottom: 14 }}>
                <Kpi label="Clients en difficulté souvent ou très souvent" r={s.vendors_clients_often_difficulty} />
                <Kpi label="Pensent que leurs clients utiliseraient le service" r={s.vendors_clients_would_use} />
              </div>
              <Dist title="Risques ou difficultés anticipés" note="Plusieurs réponses possibles." obj={s.vendor_risks} form="commercante" qkey="q6_risques" base={s.vendors_total} />
            </>
          )}

          {!noData && (show('observation') || section === 'all') && s.zones.length > 0 && (
            <>
              <h2>Par zone</h2>
              <div className="tablewrap">
                <table className="t" data-testid="zone-table">
                  <thead>
                    <tr>
                      <th>Zone</th><th className="num">Acheteurs</th><th className="num">Difficultés fréquentes</th><th className="num">Intéressés</th>
                      <th className="num">Commerçantes</th><th className="num">Obs.</th><th className="num">Personnes observées</th><th className="num">Charges lourdes</th><th className="num">Flux fort</th>
                    </tr>
                  </thead>
                  <tbody>
                    {s.zones.map((z) => (
                      <tr key={z.zone_id}>
                        <td><b>{z.zone_code}</b></td><td className="num">{z.buyers}</td>
                        <td className="num">{z.buyers_often_difficulty} sur {z.buyers}</td><td className="num">{z.buyers_interested} sur {z.buyers}</td>
                        <td className="num">{z.vendors}</td><td className="num">{z.observations}</td><td className="num">{z.observed_people_total}</td>
                        <td className="num">{z.observed_heavy_loads_total}</td><td className="num">{z.observed_strong_flow_sessions}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
              <p className="muted small">
                Effectifs par zone très petits : comparaisons indicatives seulement. Les observations sont ponctuelles : ce n’est pas un comptage complet de la fréquentation du marché.
              </p>
            </>
          )}

          {(section === 'all' || section === 'evaluation') && (
            <>
              <h2>Emplacements candidats</h2>
              {candidates.length === 0 ? (
                <div className="card center"><p className="muted">Aucune zone candidate définie (écran Zones).</p></div>
              ) : (
                <>
                  <div className="tablewrap">
                    <table className="t" data-testid="eval-table">
                      <thead>
                        <tr>
                          <th>Zone</th><th className="num">Éval.</th>
                          {EVAL_CRITERIA.map((c) => <th key={c.key} className="num" title={c.label}>{c.short}</th>)}
                          <th className="num">Total /35</th><th>Validation</th>
                        </tr>
                      </thead>
                      <tbody>
                        {candidates.map((z) => {
                          const e = evalSummary.get(z.id);
                          return (
                            <tr key={z.id}>
                              <td><b>{z.code}</b></td><td className="num">{e?.n ?? 0}</td>
                              {EVAL_CRITERIA.map((c) => <td key={c.key} className="num">{e && e.averages[c.key] !== null ? String(e.averages[c.key]).replace('.', ',') : '—'}</td>)}
                              <td className="num"><b>{e?.total != null ? String(e.total).replace('.', ',') : '—'}</b></td>
                              <td>{z.approval_status === 'VALIDE' ? 'Validé par l’administrateur' : 'Non validé'}</td>
                            </tr>
                          );
                        })}
                      </tbody>
                    </table>
                  </div>
                  <div className="notice">Score de comparaison interne (moyennes de 1 à 5) : il ne vaut pas autorisation d’occupation.</div>
                </>
              )}
            </>
          )}
        </>
      )}
    </AdminGate>
  );
}
