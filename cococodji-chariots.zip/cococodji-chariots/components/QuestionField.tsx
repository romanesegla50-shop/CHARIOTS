'use client';
import React from 'react';
import { orderedOptions, zonesForQuestion, type Answers, type Question } from '@/lib/forms';
import type { ReferenceZone } from '@/lib/types';

interface Props {
  q: Question;
  answers: Answers;
  error?: string;
  zones: ReferenceZone[];
  ordering: 'ASC' | 'DESC';
  onChange: (key: string, value: unknown) => void;
}

export default function QuestionField({ q, answers, error, zones, ordering, onChange }: Props) {
  const value = answers[q.key];
  const common = { 'data-q': q.key, 'data-error': error ? 'true' : undefined } as const;
  const help = q.help ? <p className="help">{q.help}</p> : null;
  const err = error ? <div className="err-text" role="alert">{error}</div> : null;
  const otherChosen = q.otherTextKey
    ? Array.isArray(value)
      ? value.includes(q.otherValue ?? 'AUTRE')
      : value === (q.otherValue ?? 'AUTRE')
    : false;
  const other =
    q.otherTextKey && otherChosen ? (
      <div className="sub">
        <label className="help" htmlFor={`f-${q.otherTextKey}`}>Précisez</label>
        <input
          id={`f-${q.otherTextKey}`}
          className="input"
          type="text"
          maxLength={200}
          value={(answers[q.otherTextKey] as string) ?? ''}
          onChange={(e) => onChange(q.otherTextKey!, e.target.value)}
        />
      </div>
    ) : null;

  if (q.type === 'single') {
    const opts = orderedOptions(q, ordering);
    return (
      <fieldset className="field" {...common}>
        <legend>{q.label}</legend>
        {help}
        {opts.map((o) => (
          <label key={o.value} className={`choice${value === o.value ? ' on' : ''}${error ? ' bad' : ''}`}>
            <input type="radio" name={q.key} checked={value === o.value} onChange={() => onChange(q.key, o.value)} />
            {o.label}
          </label>
        ))}
        {other}
        {err}
      </fieldset>
    );
  }

  if (q.type === 'multi') {
    const selected = Array.isArray(value) ? (value as string[]) : [];
    const toggle = (v: string) => {
      let next: string[];
      if (selected.includes(v)) next = selected.filter((x) => x !== v);
      else if (q.exclusive && v === q.exclusive) next = [v];
      else next = [...selected.filter((x) => x !== q.exclusive), v];
      onChange(q.key, next);
    };
    return (
      <fieldset className="field" {...common}>
        <legend>{q.label}</legend>
        {help}
        {(q.options ?? []).map((o) => (
          <label key={o.value} className={`choice${selected.includes(o.value) ? ' on' : ''}${error ? ' bad' : ''}`}>
            <input type="checkbox" checked={selected.includes(o.value)} onChange={() => toggle(o.value)} />
            {o.label}
          </label>
        ))}
        {other}
        {err}
      </fieldset>
    );
  }

  if (q.type === 'rating') {
    const n = value === undefined || value === null || value === '' ? 0 : Number(value);
    return (
      <fieldset className="field" {...common}>
        <legend>{q.label}</legend>
        {help}
        <div className="rating" role="radiogroup" aria-label={q.label}>
          {[1, 2, 3, 4, 5].map((i) => (
            <label key={i} className={`rate${n === i ? ' on' : ''}${error ? ' bad' : ''}`}>
              <input type="radio" name={q.key} checked={n === i} onChange={() => onChange(q.key, i)} aria-label={`${i} sur 5`} />
              {i}
            </label>
          ))}
        </div>
        <div className="rating-ends"><span>Très défavorable</span><span>Très favorable</span></div>
        {err}
      </fieldset>
    );
  }

  if (q.type === 'zone') {
    return (
      <div className="field" {...common}>
        <label className="lead" htmlFor={`f-${q.key}`}>{q.label}</label>
        {help}
        <select
          id={`f-${q.key}`}
          className={`input${error ? ' bad' : ''}`}
          value={(value as string) ?? ''}
          onChange={(e) => onChange(q.key, e.target.value || undefined)}
        >
          <option value="">{q.required ? 'Choisir une zone…' : '— Aucune —'}</option>
          {zonesForQuestion(q, zones).map((z) => (
            <option key={z.id} value={z.id}>
              {z.code}{z.label ? ` — ${z.label}` : ''}
            </option>
          ))}
        </select>
        {err}
      </div>
    );
  }

  const label = (
    <label className="lead" htmlFor={`f-${q.key}`}>
      {q.label}{q.unit ? ` (${q.unit})` : ''}
    </label>
  );

  if (q.type === 'longtext') {
    return (
      <div className="field" {...common}>
        {label}
        {help}
        <textarea
          id={`f-${q.key}`}
          className={`input${error ? ' bad' : ''}`}
          maxLength={1000}
          value={(value as string) ?? ''}
          onChange={(e) => onChange(q.key, e.target.value)}
        />
        {err}
      </div>
    );
  }

  const inputType = q.type === 'date' ? 'date' : q.type === 'time' ? 'time' : 'text';
  return (
    <div className="field" {...common}>
      {label}
      {help}
      <input
        id={`f-${q.key}`}
        className={`input${error ? ' bad' : ''}`}
        type={inputType}
        {...(q.type === 'number' ? { inputMode: 'numeric' as const, pattern: '[0-9]*', autoComplete: 'off' } : {})}
        maxLength={q.type === 'text' ? 200 : undefined}
        value={value === undefined || value === null ? '' : String(value)}
        onChange={(e) => onChange(q.key, e.target.value)}
      />
      {err}
    </div>
  );
}
