'use client';
import React, { createContext, useCallback, useContext, useEffect, useMemo, useRef, useState } from 'react';
import { getClient, isConfigured, supabaseTransport } from '@/lib/supabase';
import { countRecords, getMeta, listRecords, onLocalChange, setMeta, type Counts } from '@/lib/localdb';
import { syncAll, retryRecord, type SyncReport } from '@/lib/sync';
import {
  getCachedProfile, getCachedReference, getCachedStats, refreshProfile, refreshReference, refreshStats,
  type ServerStats,
} from '@/lib/refdata';
import type { LocalRecord, Profile, Reference } from '@/lib/types';

export type Phase = 'boot' | 'unconfigured' | 'signedOut' | 'notActive' | 'ready';

interface AppUser {
  id: string;
  email: string | null;
}

interface Ctx {
  phase: Phase;
  user: AppUser | null;
  profile: Profile | null;
  reference: Reference | null;
  stats: ServerStats | null;
  records: LocalRecord[];
  counts: Counts;
  online: boolean;
  syncing: boolean;
  lastSyncAt: string | null;
  unstableNetwork: boolean;
  canInstall: boolean;
  signIn: (email: string, password: string) => Promise<string | null>;
  signOut: () => Promise<void>;
  syncNow: () => Promise<SyncReport | null>;
  retry: (id: string) => Promise<void>;
  refreshAll: () => Promise<void>;
  install: () => Promise<void>;
}

const AppCtx = createContext<Ctx | null>(null);

export function useApp(): Ctx {
  const v = useContext(AppCtx);
  if (!v) throw new Error('useApp hors AppProvider');
  return v;
}

function translateAuthError(message: string): string {
  if (/invalid login credentials/i.test(message)) return 'E-mail ou mot de passe incorrect.';
  if (/email not confirmed/i.test(message)) return 'Ce compte n’est pas confirmé. Demandez à l’administrateur de le recréer avec « Auto Confirm User ».';
  if (/fetch|network|load failed/i.test(message)) return 'Pas de connexion : la première connexion nécessite du réseau.';
  return 'Connexion impossible : ' + message;
}

export default function AppProvider({ children }: { children: React.ReactNode }) {
  const [phase, setPhase] = useState<Phase>('boot');
  const [user, setUser] = useState<AppUser | null>(null);
  const [profile, setProfile] = useState<Profile | null>(null);
  const [reference, setReference] = useState<Reference | null>(null);
  const [stats, setStats] = useState<ServerStats | null>(null);
  const [records, setRecords] = useState<LocalRecord[]>([]);
  const [online, setOnline] = useState(true);
  const [syncing, setSyncing] = useState(false);
  const [lastSyncAt, setLastSyncAt] = useState<string | null>(null);
  const [unstableNetwork, setUnstableNetwork] = useState(false);
  const [installEvent, setInstallEvent] = useState<any>(null);
  const userRef = useRef<AppUser | null>(null);
  userRef.current = user;

  const counts = useMemo(() => countRecords(records), [records]);

  // ------------------------------------------------------------ service worker (hors ligne) + installation
  useEffect(() => {
    if (process.env.NODE_ENV === 'production' && 'serviceWorker' in navigator) {
      navigator.serviceWorker.register('/sw.js').catch(() => {});
    }
    const onPrompt = (e: Event) => {
      e.preventDefault();
      setInstallEvent(e);
    };
    window.addEventListener('beforeinstallprompt', onPrompt);
    return () => window.removeEventListener('beforeinstallprompt', onPrompt);
  }, []);

  // ------------------------------------------------------------ état du réseau
  useEffect(() => {
    setOnline(navigator.onLine);
    const on = () => setOnline(true);
    const off = () => setOnline(false);
    window.addEventListener('online', on);
    window.addEventListener('offline', off);
    return () => {
      window.removeEventListener('online', on);
      window.removeEventListener('offline', off);
    };
  }, []);

  // ------------------------------------------------------------ fiches locales
  const reloadRecords = useCallback(async () => {
    const u = userRef.current;
    if (!u) return setRecords([]);
    setRecords(await listRecords(u.id));
  }, []);
  useEffect(() => onLocalChange(() => void reloadRecords()), [reloadRecords]);
  useEffect(() => {
    void reloadRecords();
  }, [user, reloadRecords]);

  // ------------------------------------------------------------ données de référence et statistiques
  const refreshServerData = useCallback(async (u: AppUser) => {
    const c = getClient();
    const ref = await refreshReference(c);
    if (ref) {
      setReference(ref);
      if (ref.mission) {
        const st = await refreshStats(c, ref.mission.id);
        if (st) setStats(st);
      }
    }
    const p = await refreshProfile(c, u.id);
    if (p) {
      setProfile(p);
      setPhase(p.active ? 'ready' : 'notActive');
    }
  }, []);

  // ------------------------------------------------------------ synchronisation
  const syncNow = useCallback(async (): Promise<SyncReport | null> => {
    const u = userRef.current;
    if (!u || !isConfigured()) return null;
    setSyncing(true);
    try {
      const report = await syncAll(supabaseTransport(getClient()), u.id);
      setUnstableNetwork(report.stoppedBy === 'network');
      if (report.sent > 0 || report.rejected > 0) {
        setLastSyncAt(new Date().toISOString());
        // les compteurs d'équipe changent dès qu'une fiche arrive sur le serveur
        void refreshServerData(u);
      }
      await reloadRecords();
      return report;
    } finally {
      setSyncing(false);
    }
  }, [refreshServerData, reloadRecords]);

  const retry = useCallback(
    async (id: string) => {
      await retryRecord(id);
      await syncNow();
    },
    [syncNow],
  );

  // ------------------------------------------------------------ démarrage / session
  const enterSession = useCallback(
    async (u: AppUser) => {
      setUser(u);
      userRef.current = u;
      await setMeta('lastUser', u);
      const [cachedProfile, cachedRef, cachedStats] = await Promise.all([
        getCachedProfile(u.id),
        getCachedReference(),
        getCachedStats(),
      ]);
      if (cachedProfile) setProfile(cachedProfile);
      if (cachedRef) setReference(cachedRef);
      if (cachedStats) setStats(cachedStats);
      setPhase(cachedProfile && !cachedProfile.active ? 'notActive' : 'ready');
      if (navigator.onLine) await refreshServerData(u);
    },
    [refreshServerData],
  );

  useEffect(() => {
    let cancelled = false;
    (async () => {
      if (!isConfigured()) return setPhase('unconfigured');
      const c = getClient();
      const { data } = await c.auth.getSession();
      if (cancelled) return;
      if (data.session) {
        await enterSession({ id: data.session.user.id, email: data.session.user.email ?? null });
        return;
      }
      // Pas de session lisible : hors ligne, on laisse l'enquêteur continuer sur ce téléphone avec son dernier compte.
      const last = await getMeta<AppUser>('lastUser');
      if (last && !navigator.onLine) await enterSession(last);
      else setPhase('signedOut');
    })();

    const { data: sub } = getClientSafe()?.auth.onAuthStateChange((event) => {
      if (event === 'SIGNED_OUT') {
        setUser(null);
        setProfile(null);
        setPhase('signedOut');
      }
    }) ?? { data: null };
    return () => {
      cancelled = true;
      sub?.subscription.unsubscribe();
    };
  }, [enterSession]);

  // ------------------------------------------------------------ envois automatiques
  const pendingCount = counts.pending;
  useEffect(() => {
    if (phase !== 'ready') return;
    if (online) void syncNow();
  }, [phase, online, syncNow]);
  useEffect(() => {
    if (phase !== 'ready' || pendingCount === 0 || !online) return;
    const t = setInterval(() => void syncNow(), 20000);
    return () => clearInterval(t);
  }, [phase, pendingCount, online, syncNow]);
  // Dès qu'une fiche entre dans la file, on tente un envoi immédiat
  useEffect(() => {
    if (phase === 'ready' && online && pendingCount > 0) void syncNow();
  }, [pendingCount, phase, online, syncNow]);
  useEffect(() => {
    const onVisible = () => {
      if (document.visibilityState === 'visible' && userRef.current && navigator.onLine) {
        void syncNow();
        void refreshServerData(userRef.current);
      }
    };
    document.addEventListener('visibilitychange', onVisible);
    return () => document.removeEventListener('visibilitychange', onVisible);
  }, [syncNow, refreshServerData]);

  // ------------------------------------------------------------ actions
  const signIn = useCallback(
    async (email: string, password: string): Promise<string | null> => {
      try {
        const { data, error } = await getClient().auth.signInWithPassword({ email: email.trim(), password });
        if (error) return translateAuthError(error.message);
        if (!data.session) return 'Connexion impossible.';
        await enterSession({ id: data.session.user.id, email: data.session.user.email ?? null });
        return null;
      } catch (e) {
        return translateAuthError(e instanceof Error ? e.message : String(e));
      }
    },
    [enterSession],
  );

  const signOut = useCallback(async () => {
    try {
      await getClient().auth.signOut();
    } catch {
      /* hors ligne : on ferme quand même la session locale */
    }
    await setMeta('lastUser', null);
    window.location.hash = '#/'; // le prochain compte repart du tableau de bord
    setUser(null);
    setProfile(null);
    setRecords([]);
    setPhase('signedOut');
  }, []);

  const refreshAll = useCallback(async () => {
    const u = userRef.current;
    if (u && navigator.onLine) await refreshServerData(u);
  }, [refreshServerData]);

  const install = useCallback(async () => {
    if (!installEvent) return;
    installEvent.prompt();
    await installEvent.userChoice.catch(() => {});
    setInstallEvent(null);
  }, [installEvent]);

  const value: Ctx = {
    phase, user, profile, reference, stats, records, counts, online, syncing, lastSyncAt, unstableNetwork,
    canInstall: Boolean(installEvent), signIn, signOut, syncNow, retry, refreshAll, install,
  };
  return <AppCtx.Provider value={value}>{children}</AppCtx.Provider>;
}

function getClientSafe() {
  try {
    return isConfigured() ? getClient() : null;
  } catch {
    return null;
  }
}
