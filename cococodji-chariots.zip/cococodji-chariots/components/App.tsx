'use client';
import React, { useEffect, useState } from 'react';
import AppProvider, { useApp } from './AppProvider';
import FormWizard from './FormWizard';
import Login from './screens/Login';
import Home from './screens/Home';
import NewEntry from './screens/NewEntry';
import Outbox from './screens/Outbox';
import More from './screens/More';
import Zones from './screens/Zones';
import Mission from './admin/Mission';
import Team from './admin/Team';
import Responses from './admin/Responses';
import Results from './admin/Results';
import Export from './admin/Export';
import Audit from './admin/Audit';
import { navigate, useRoute } from '@/lib/hashrouter';

function Splash({ text = 'Cococodji Chariots' }: { text?: string }) {
  return <div className="splash">{text}</div>;
}

function NetPill() {
  const { online, counts, syncing, unstableNetwork } = useApp();
  let cls = 'ok';
  let text = 'Synchronisé';
  if (counts.error > 0) {
    cls = 'err';
    text = `Erreur de synchronisation (${counts.error})`;
  } else if (!online) {
    cls = 'off';
    text = counts.pending > 0 ? `Hors ligne · ${counts.pending} en attente` : 'Hors ligne';
  } else if (counts.pending > 0) {
    cls = 'off';
    text = syncing ? 'Envoi en cours…' : unstableNetwork ? `Réseau instable · ${counts.pending} en attente` : `En attente de synchronisation (${counts.pending})`;
  }
  return (
    <button className={`netpill ${cls}`} onClick={() => navigate('#/envois')} aria-label={`État : ${text}`} data-testid="netpill">
      {text}
    </button>
  );
}

function Shell() {
  const { phase, profile, user, signOut, refreshAll, counts, online } = useApp();
  const { route, nonce } = useRoute();

  if (phase === 'boot') return <Splash text="Chargement…" />;

  if (phase === 'unconfigured') {
    return (
      <div className="login">
        <div className="card stack">
          <h1>Configuration manquante</h1>
          <p>
            L’application n’est pas reliée à sa base de données. Il faut renseigner les variables{' '}
            <code>NEXT_PUBLIC_SUPABASE_URL</code> et <code>NEXT_PUBLIC_SUPABASE_ANON_KEY</code> (voir le guide d’installation).
          </p>
        </div>
      </div>
    );
  }
  if (phase === 'signedOut') return <Login />;

  if (phase === 'notActive') {
    return (
      <div className="login">
        <div className="card stack">
          <h1>Compte en attente d’activation</h1>
          <p>
            Votre compte ({user?.email}) existe mais n’est pas encore activé. Demandez à l’administrateur de l’activer, puis appuyez sur « Vérifier ».
          </p>
          <div className="btns">
            <button className="btn" onClick={() => void refreshAll()} disabled={!online}>Vérifier à nouveau</button>
            <button className="btn secondary" onClick={() => void signOut()}>Se déconnecter</button>
          </div>
        </div>
      </div>
    );
  }

  const active = route.name === 'formulaire' ? 'nouvelle' : route.name === 'zones' || route.name === 'admin' ? 'plus' : route.name;
  const needsAttention = counts.pending + counts.error;

  return (
    <div className="shell">
      <header className="head">
        <div className="topbar">
          <div className="brand">
            Cococodji Chariots
            <small>Enquête terrain{profile?.full_name ? ` · ${profile.full_name}` : ''}</small>
          </div>
        </div>
        <NetPill />
      </header>
      <main className="content">
        {route.name === 'home' && <Home />}
        {route.name === 'nouvelle' && <NewEntry />}
        {route.name === 'envois' && (
          <>
            <Outbox />
            <div style={{ marginTop: 22 }}>
              <button className="btn secondary small" onClick={() => void signOut()}>Se déconnecter</button>
              <p className="muted small">Sur un téléphone partagé, déconnectez-vous après usage. Les fiches non envoyées restent conservées sur ce téléphone.</p>
            </div>
          </>
        )}
        {route.name === 'plus' && <More />}
        {route.name === 'zones' && <Zones />}
        {route.name === 'admin' && route.page === 'mission' && <Mission />}
        {route.name === 'admin' && route.page === 'equipe' && <Team />}
        {route.name === 'admin' && route.page === 'reponses' && <Responses />}
        {route.name === 'admin' && route.page === 'resultats' && <Results />}
        {route.name === 'admin' && route.page === 'export' && <Export />}
        {route.name === 'admin' && route.page === 'journal' && <Audit />}
        {route.name === 'formulaire' && <FormWizard key={`${route.type}:${route.id ?? 'new'}:${nonce}`} type={route.type} id={route.id} />}
      </main>
      <nav className="tabbar" aria-label="Navigation principale">
        <button className={`tab${active === 'home' ? ' active' : ''}`} onClick={() => navigate('#/')}>
          <span className="ico" aria-hidden>▦</span>Tableau de bord
        </button>
        <button className={`tab main${active === 'nouvelle' ? ' active' : ''}`} onClick={() => navigate('#/nouvelle')}>
          <span className="ico plus" aria-hidden>＋</span>Nouvelle réponse
        </button>
        <button className={`tab${active === 'envois' ? ' active' : ''}`} onClick={() => navigate('#/envois')}>
          <span className="ico" aria-hidden>⇅</span>Mes envois
          {needsAttention > 0 && <span className={`badge${counts.error ? '' : ' warn'}`}>{needsAttention}</span>}
        </button>
        <button className={`tab${active === 'plus' ? ' active' : ''}`} onClick={() => navigate('#/plus')}>
          <span className="ico" aria-hidden>☰</span>Plus
        </button>
      </nav>
    </div>
  );
}

export default function App() {
  const [mounted, setMounted] = useState(false);
  useEffect(() => setMounted(true), []);
  if (!mounted) return <Splash />;
  return (
    <AppProvider>
      <Shell />
    </AppProvider>
  );
}
