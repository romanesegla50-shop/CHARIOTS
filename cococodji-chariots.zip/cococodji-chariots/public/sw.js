/* Service worker — permet d'ouvrir l'application SANS réseau.
 * L'application est une seule page : on garde en cache cette page et ses fichiers.
 * Jamais mis en cache : les appels à la base de données (autre domaine) et toute requête non GET. */
const STATIC_CACHE = 'cc-static-v1';
const PAGE_CACHE = 'cc-page-v1';

self.addEventListener('install', (e) => {
  e.waitUntil(
    caches.open(PAGE_CACHE).then((c) => c.add('/')).catch(() => {}).then(() => self.skipWaiting()),
  );
});

self.addEventListener('activate', (e) => {
  e.waitUntil(
    caches.keys()
      .then((keys) => Promise.all(keys.filter((k) => k.startsWith('cc-') && k !== STATIC_CACHE && k !== PAGE_CACHE).map((k) => caches.delete(k))))
      .then(() => self.clients.claim()),
  );
});

self.addEventListener('fetch', (e) => {
  const req = e.request;
  if (req.method !== 'GET') return;
  const url = new URL(req.url);
  if (url.origin !== self.location.origin) return; // base de données : jamais en cache

  // Fichiers de l'application (noms uniques par version) : cache d'abord
  if (url.pathname.startsWith('/_next/static/') || /\.(png|svg|ico|webmanifest|woff2?)$/.test(url.pathname)) {
    e.respondWith(
      caches.open(STATIC_CACHE).then(async (cache) => {
        const hit = await cache.match(req);
        if (hit) return hit;
        const res = await fetch(req);
        if (res.ok) cache.put(req, res.clone());
        return res;
      }),
    );
    return;
  }

  // La page : on sert tout de suite la version gardée, et on la met à jour en arrière-plan
  if (req.mode === 'navigate') {
    e.respondWith(
      caches.open(PAGE_CACHE).then(async (cache) => {
        const cached = await cache.match('/');
        const refresh = fetch('/', { cache: 'no-store' })
          .then((res) => {
            if (res.ok) cache.put('/', res.clone());
            return res;
          })
          .catch(() => null);
        if (cached) {
          e.waitUntil(refresh);
          return cached;
        }
        const res = await refresh;
        return res || new Response('<meta charset="utf-8"><meta name="viewport" content="width=device-width"><p style="font:18px system-ui;padding:24px">Ouvrez une première fois l’application avec du réseau pour pouvoir l’utiliser hors ligne.</p>', { headers: { 'Content-Type': 'text/html; charset=utf-8' } });
      }),
    );
  }
});
